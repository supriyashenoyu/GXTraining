// Fetch the JSON file
fetch('data.json')
.then(response => response.json())
.then(datares=> {
  var data=datares;
  document.getElementById("ct").innerText=data.personal_info.title;
  document.getElementById("ctxt").innerText=data.personal_info.caption;
  document.getElementById("nm").innerText=data.personal_info.name;
  document.getElementById("obj").innerText=data.Career_Objective;
  document.getElementById("p2").innerText=data.educational_qualifications[3].degree;
  document.getElementById("p4").innerText=data.personal_info.Exp;
  var sk=data.personal_info.skills;
  var sl='';
  for(var i=0;i<sk.length;i++){
    sl+=sk[i]+" ";
  }
  document.getElementById("p6").innerText=sl;
  document.getElementById("p8").innerText=data.personal_info.address;
  document.getElementById("p10").innerText=data.personal_info.phone;
  document.getElementById("p12").innerText=data.personal_info.email;
  var eq=data.educational_qualifications;
  var cola='';
  var colb='';
  var colc='';
  var cold='';
  for(var i=0;i<eq.length;i++){
        cola+="<p class='bd'>"+eq[i].degree+"</p>";
        colb+="<p class='bd'>"+eq[i].year_of_passing+"</p>";
        colc+="<p class='bd'>"+eq[i].grade+"</p>";
        cold+="<p class='bd'>"+eq[i].institute+"</p>";
  }
  document.getElementById("cola").innerHTML=cola;
  document.getElementById("colb").innerHTML=colb;
  document.getElementById("colc").innerHTML=colc;
  document.getElementById("cold").innerHTML=cold;
  const obj=data.professional_skills;
  const arr = []; 
         for(let i in obj) { 
            arr.push([i,obj[i]]); 
         }; 
  document.getElementById("p33").style.width=arr[0][1];
  document.getElementById("p34").style.width=arr[1][1];
  document.getElementById("p35").style.width=arr[2][1];
  document.getElementById("p36").style.width=arr[3][1];
  document.getElementById("p29").innerHTML=arr[0][0];
  document.getElementById("p30").innerHTML=arr[1][0];
  document.getElementById("p31").innerHTML=arr[2][0];
  document.getElementById("p32").innerHTML=arr[3][0];
  document.getElementById("p37").innerHTML=arr[0][1];
  document.getElementById("p38").innerHTML=arr[1][1];
  document.getElementById("p39").innerHTML=arr[2][1];
  document.getElementById("p40").innerHTML=arr[3][1];




  

  document.getElementById('jsonDataDisplay').innerHTML = "<pre>"+JSON.stringify(data, null, 2)+"</pre>";
})
.catch(error => console.error('Error fetching JSON:', error));