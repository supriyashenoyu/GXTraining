import React from 'react'
import trashCan from "../../assets/Images/trash-can-icon.png"
import "../../assets/Css/Wishlist.css"
import axios from "axios";
import Swal from "sweetalert2";
import { useNavigate } from 'react-router-dom';
export const WishlistCard = (props) => {
  const navigate = useNavigate();

  const removeLike = () => {
    const url = `http://localhost:8080/nveda/resetFlag/` + props.obj.customerRegistrationDTO.customerId;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
        }
      })
      .catch((error) => console.log(error));
  };
  const refresh = () => {
    window.location.reload()
  }
  const deleteWishlist = () => {
    const url = `http://localhost:8080/nveda/deleteFromWishlist/${props.obj.customerRegistrationDTO.customerId}/${props.obj.productDTO.productId}`;
    axios
      .delete(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            text: "Removed from wishlist",
            timer: 1000,
            icon: "success",
            showConfirmButton: false,
          });
          removeLike();
          props.load();
          refresh();
        }
      }).catch((error) => console.log(error));
  }

  return (
    <div>
      <div className='d-flex' style={{ border: "solid", borderColor: "grey", height: "10rem", width: "60rem", margin: "0rem 10rem" }}><img src={trashCan} onClick={deleteWishlist} className="trashCan" height="50rem" style={{ margin: "3rem" }} />
        <p onClick={() => navigate("/product", { state: props.obj.productDTO })} className='d-flex cardd trans'>
          <img src={props.obj.productDTO.productImagesDTOs[0].imgSrc} height="150rem" width="150rem" />
          <p style={{ margin: "1rem", paddingTop: "2rem", width: "20rem" }}>{props.obj.productDTO.productName}</p>
          <p style={{ marginLeft: "9.5rem", paddingTop: "3rem" }}>Rs. {props.obj.productDTO.productPrice}</p>
        </p>
      </div>
      <br />
    </div>
  )
}
