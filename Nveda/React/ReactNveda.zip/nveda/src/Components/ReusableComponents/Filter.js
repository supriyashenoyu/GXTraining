import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { CardComp } from "./Card";
import Slider from "react-slider";
import { Col, Container, Row } from "react-bootstrap";

export const Filter = () => {
  const { name } = useParams();
  const { state } = useLocation();
  const [productName, setProductName] = useState(false);
  const [id, setId] = useState();
  const [filtered, setFilter] = useState([]);
  const [highestPrice, setHighestPrice] = useState(0);
  const [inStockProducts, setInStockProducts] = useState();
  const [outOfStockProducts, setOutOfStockProducts] = useState();

  /*
    To get maximum price of product
   */
  function maxProductPrice(productItem) {
    if (productItem.productPrice > highestPrice) {
      setHighestPrice(productItem.productPrice);
    }
  }

  const [currentItems, setCurrentItems] = useState([]);
  const [dropdownButton, setDropDownButton] = useState({
    collectionDropdown: true,
    availabilityDropdown: true,
    priceDropdown: true,
  });
  const toggleCollection = () => {
    setDropDownButton({
      ...dropdownButton,
      collectionDropdown: !dropdownButton.collectionDropdown,
    });
  };
  const toggleAvailability = () => {
    setDropDownButton({
      ...dropdownButton,
      availabilityDropdown: !dropdownButton.availabilityDropdown,
    });
  };
  const togglePrice = () => {
    setDropDownButton({
      ...dropdownButton,
      priceDropdown: !dropdownButton.priceDropdown,
    });
  };
  useEffect(
    () => {
      if (name == "Combo Offer" || name == "Pack of 2 Offer") {
        setId(7);
        setProductName(true);
      } else if (name === "Ayurvedic Products") {
        setId(1);
        setProductName(true);
      } else if (state === "Calcium Complex") {
        setId(2);
        setProductName(false);
      } else if (state === "Immunity Boost") {
        setId(3);
        setProductName(false);
      } else if (state === "Joint Support") {
        setProductName(false);
        setId(4);
      } else if (state === "Sleep Aid") {
        setId(5);
        setProductName(false);
      } else if (state === "Omega 3 Fish Oil") {
        setId(6);
        setProductName(false);
      } else if (state === "Ayurvedic Products") {
        setId(1);
        setProductName(false);
      }
    },
    [name],
    [state],
    [productName]
  );


  const [MIN, setMIN] = useState(0);
  const [MAX, setMAX] = useState(965);
  const [values, setValues] = useState([MIN, MAX]);
  useEffect(
    () => {
      let url = `http://localhost:8080/nveda/getProductByCategory/` + id;
      axios
        .get(url)
        .then((resData) => {
          if (resData.status === 200) {
            setHighestPrice(0);
            resData.data.map(maxProductPrice);
            setMAX(highestPrice);
            setFilter(resData.data);
            setCurrentItems(resData.data);
          }
        })
        .catch((error) => console.log(error));
    },
    [id],
    [filtered],
    [currentItems],
    [name],
    []
  );

  useEffect(() => {
    currentItems.map(maxProductPrice);
    setValues([0, highestPrice]);
  }, [highestPrice]);

  /*
    To get the count of products in stock and out of stock
    */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/stock`;
    axios
      .get(url)
      .then((stock) => {
        if (stock.status == "200") {
          setInStockProducts(stock.data);
        }
      })
      .catch((error) => console.log(error));
    const outOfStockUrl = `http://localhost:8080/nveda/outOfStock`;
    axios
      .get(outOfStockUrl)
      .then((stock) => {
        if (stock.status == "200") {
          setOutOfStockProducts(stock.data);
        }
      })
      .catch((error) => console.log(error));
  }, []);

  useEffect(() => {
    const filterByPrice = filtered.filter(
      (item) => item.productPrice >= values[0] && item.productPrice <= values[1]
    );
    setCurrentItems(filterByPrice);
    currentItems.map(maxProductPrice);
    setMAX(highestPrice);
  }, [values]); //,[filtered],[currentItems],[]

  const navCombo = () => {
    window.location.href = "/category/Combo Offer";
  };
  const navNveda = () => {
    window.location.href = "/shop";
  };
  return (
    <div>
      <Container>
        <Row>
          <Col xs={3}>
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <h6>Collection</h6>
              {dropdownButton.collectionDropdown ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleCollection}
                >
                  <path d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleCollection}
                >
                  <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              )}
            </div>
            {dropdownButton.collectionDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links" onClick={navCombo}>
                  Combo Offer
                </p>
                <p className="circle">05</p>
              </div>
            )}
            {dropdownButton.collectionDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links" onClick={navNveda}>
                  Nveda
                </p>
                <p className="circle">{inStockProducts}</p>
              </div>
            )}

            <br />
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <h6>Availability</h6>
              {dropdownButton.availabilityDropdown ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleAvailability}
                >
                  <path d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleAvailability}
                >
                  <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              )}
            </div>
            {dropdownButton.availabilityDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links">In Stock</p>
                <p className="circle">{inStockProducts}</p>
              </div>
            )}
            {dropdownButton.availabilityDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links">Out of Stock</p>
                <p className="circle">{outOfStockProducts}</p>
              </div>
            )}
            <br />
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <h6>Price</h6>
              {dropdownButton.priceDropdown ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={togglePrice}
                >
                  <path d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={togglePrice}
                >
                  <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              )}
            </div>
            {dropdownButton.priceDropdown && (
              <>
                <Slider
                  className={"slider"}
                  onChange={setValues}
                  value={values}
                  min={MIN}
                  max={MAX}
                />
                <div className="values">
                  Rs {values[0]} - Rs {values[1]}
                </div>
              </>
            )}
          </Col>
          <Col xs={9}>
            {productName ? (
              <h3 style={{ marginLeft: "2rem" }}>{name}</h3>
            ) : (
              <h3 style={{ marginLeft: "2rem" }}>{state}</h3>
            )}
            <br />
            <Container>
              <Row>
                {currentItems?.map((items) => {
                  return (
                    <Col>
                      <CardComp
                        style={{ width: "23rem", margin: "0.5rem" }}
                        obj={items}
                      />
                    </Col>
                  );
                })}
              </Row>
            </Container>
          </Col>
        </Row>
        <br />
      </Container>
    </div>
  );
};
