import React, { useEffect, useState } from "react";
import Card from "react-bootstrap/Card";
import { Product } from "../Product";
import { useNavigate } from "react-router-dom";
import "../../assets/Css/Card.css";
import trashCan from "../../assets/Images/trash-can-icon.png";
import "../../assets/Css/Wishlist.css";
import Swal from "sweetalert2";
import axios from "axios";
import { NumericFormat } from "react-number-format";
import ReactStars from 'react-stars'

export const CardComp = (props) => {
  const navigate = useNavigate();
  const [ratingVisiblity, setRatingVisiblity] = useState(false);
  const [stars, setStars] = useState(0);
  const [reviewCount, setReviewCount] = useState(0);


  useEffect(() => {
    let url = `http://localhost:8080/nveda/updateRating/${stars}/${props.obj.productId}`
    axios.get(url).catch((error) => console.log(error));
  }, [stars])

  useEffect(() => {
    setRatingVisiblity(false);
    setStars(0)
    let url = 'http://localhost:8080/nveda/rating/' + props.obj.productId;
    axios
      .get(url)
      .then((rating) => {
        if (rating.status === 200) {
          setReviewCount(rating.data.reviewCount);
          setStars(rating.data.avgRating);
          if (rating.data.avgRating > 0) {
            setRatingVisiblity(true);
          }
          else {
            setRatingVisiblity(false);
          }
        }
      })
      .catch((error) => console.log(error));
  }, [props.obj.productId])



  return (
    <div>
      <Card
        style={props.style}
        onClick={() => navigate("/product", { state: props.obj })}
      >
        <p className="trans">
          <Card.Img variant="top" src={props.obj.productImagesDTOs[0].imgSrc} />
        </p>
        <Card.Body>
          <Card.Title className="cardd">{props.obj.productName}
          </Card.Title>
          {ratingVisiblity && <div className="d-flex">
            <ReactStars
              count={5}
              value={stars}
              edit={false}
              size={25}
              isHalf={true}
              quiet={false}
              emptyIcon={<i className="far fa-star"></i>}
              halfIcon={<i className="fa fa-star-half-alt"></i>}
              fullIcon={<i className="fa fa-star"></i>}
              activeColor="#ffd700"
            />
            <p style={{ position: "relative", top: "0.5rem", left: "0.2rem", fontSize: "1rem" }}>{reviewCount} reviews</p></div>}
          <Card.Text> <NumericFormat
            value={props.obj.productPrice}
            decimalScale={2}
            displayType={"text"}
            thousandSeparator=","
            prefix={"Rs. "}

          />
          </Card.Text>


        </Card.Body>
      </Card>
    </div>
  );
};
export const SmallCard = (props) => {
  const navigate = useNavigate();

  return (
    <div>
      <Card
        style={props.obj.style}
        onClick={() =>
          navigate("/category/props.obj.categoryName", {
            state: props.obj.categoryName,
          })
        }
      >
        <p className="trans">
          <Card.Img variant="top" src={props.obj.categoryImgSrc} />
        </p>
        <Card.Body>
          <Card.Text style={{fontWeight: "bold",width:"9.5rem",position:"relative",left:"-0.5rem" }}>
            {props.obj.categoryName}
          </Card.Text>
        </Card.Body>
      </Card>
    </div>
  );
};

export const SearchCard = (props) => {
  const navigate = useNavigate();

  const close = () => {
    navigate("/product", { state: props.obj });
    props.close();
  };
  return (
    <div
      className="d-flex cardd trans"
      style={{ height: "7rem", width: "30rem", margin: "0.5rem" }}
      onClick={() => {
        navigate("/product", { state: props.obj });
        close();
      }}
    >
      <img src={props.obj.productImagesDTOs[0].imgSrc} />
      <p style={{ width: "15rem", marginTop: "1rem", marginLeft: "0.5rem" }}>
        {props.obj.productName}
      </p>

      <NumericFormat
        value={props.obj.productPrice}
        decimalScale={2}
        displayType={"text"}
        thousandSeparator=","
        prefix={"Rs. "}
        suffix={".00"}
        style={{ marginLeft: "5rem", marginTop: "2rem" }}
      />

    </div>
  );
};

export const CartCard = (props) => {
  const navigate = useNavigate();

  const [quantity, setQuantity] = useState(props.obj.quantity);

  /*
    IncrementProductQuantityements quantity based on product's stock
   */
  const IncrementProductQuantity = () => {
    if (quantity < props.obj.productDTO.stock) {
      setQuantity(quantity + 1);
      addToCart();
    } else {
      Swal.fire({
        text: "item out of stock",
        timer: 1000,
        icon: "error",
        showConfirmButton: false,
      });
    }
  };

  const addToCart = () => {
    if (props.obj.productDTO.stock < 1) {
      Swal.fire({
        text: "item out of stock",
        timer: 1000,
        icon: "error",
        showConfirmButton: false,
      });
    } else {
      let url = `http://localhost:8080/nveda/addToCart`;
      const reqBody = {
        productDTO: props.obj.productDTO,
        quantity: 1,
        customerRegistrationDTO: props.obj.customerRegistrationDTO,
        totalAmount: props.obj.productDTO.productPrice,
      };
      axios
        .post(url, reqBody, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((resData) => {
          if (resData.status === 200) {
            props.load();
          }
        })
        .catch((error) => {
          console.log(error);
          Swal.fire({
            icon: "error",
            title: error.response.data,
            timer: 1000,
            showConfirmButton: false,
          });
        });

    }
  };

  const refresh = () => {

    window.location.reload()
  }

  /*
    delete product in cart
   */
  const deleteCartItem = () => {
    
    let url = `http://localhost:8080/nveda/deleteCart/${props.obj.customerRegistrationDTO.customerId}/${props.obj.productDTO.productId}`;
    axios
      .delete(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            text: "Removed from cart",
            timer: 1000,
            icon: "success",
            showConfirmButton: false,
          });
          props.load();
          refresh();
        

        }
      }).catch((error) => console.log(error));

  }


  /*
    Updating the cart items
   */
  const updateCart = () => {
    let url = `http://localhost:8080/nveda/updateCart`
    const reqBody = {
      "customerId": props.obj.customerRegistrationDTO.customerId,
      "productId": props.obj.productDTO.productId,
      "quantity": quantity - 1,
      "totalAmount": (quantity - 1) * props.obj.productDTO.productPrice
    }
    axios.post(url, reqBody, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Origin": "*",
      },
    })
      .then((resData) => {
        if (resData.status === 200) {
          props.load();
        }
      })
      .catch((error) => console.log(error));


  }

  /*
      decrementProductQuantityement quantity based on product's stock
     */
  const decrementProductQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
      updateCart();
    }
    if (quantity === 1) {
      deleteCartItem();

    }
  };
  return (
    <div>
      <div
        className="d-flex"
        style={{
          border: "solid",
          borderColor: "grey",
          height: "8rem",
          width: "50rem",
        }}
      >
        <img
          src={trashCan}
          className="trashCan"
          height="40rem"
          style={{ margin: "2rem 1.2rem" }}
          onClick={deleteCartItem}
        />
        <p

          className="d-flex  trans"
        >
          <div className="d-flex cardd trans" onClick={() => navigate("/product", { state: props.obj.productDTO })}>
            <img
              className="cardd"
              src={props.obj.productDTO.productImagesDTOs[0].imgSrc}
              height="120rem"
              width="100rem"
            />
            <p style={{ margin: "1rem", marginTop: "-1rem", paddingTop: "2rem", width: "15rem" }}>
              {props.obj.productDTO.productName}
            </p>
            <p style={{ marginLeft: "0.5rem", marginTop: "3rem" }}>
              <NumericFormat
                value={props.obj.productDTO.productPrice}
                decimalScale={2}
                displayType={"text"}
                thousandSeparator=","
                prefix={"Rs. "}
                suffix={".00"}

              />
            </p>
          </div>
          <div
            className="d-flex"
            style={{ marginTop: "3rem", marginLeft: "2rem" }}
          >
            <p>Qty :</p>
            <p
              style={{
                backgroundColor: "#f6f6f6",
                borderRadius: "20%",
                height: "2rem",
                marginLeft: "0.5rem",
              }}
            >
              <a
                onClick={decrementProductQuantity}
                style={{ marginLeft: "1rem", marginRight: "1rem" }}
              >
                -
              </a>

              {quantity}
              <a
                onClick={IncrementProductQuantity}
                style={{ marginLeft: "1rem", marginRight: "1rem" }}
              >
                +
              </a>
            </p>
          </div>
          <p style={{ marginLeft: "1rem", marginTop: "3rem" }}>
            <NumericFormat
              value={props.obj.totalAmount}
              decimalScale={2}
              displayType={"text"}
              thousandSeparator=","
              prefix={"Rs. "}
              suffix={".00"}

            />
          </p>
        </p>
      </div>
      <br />
    </div>
  );
};

export const PaymentCard = (props) => {
  return (
    <>
      <div className="d-flex">
        <img

          src={props.obj.productDTO.productImagesDTOs[0].imgSrc}
          height="60rem"
          width="60rem"
          style={{ border: "solid 0.03rem grey", margin: "0.5rem" }}
        />
        <p style={{ width: "15rem", textOverflow: "ellipsis", whiteSpace: "nowrap", overflow: "hidden", margin: " 0 0.5rem" }}>{props.obj.productDTO.productName}</p>
        <p>₹{props.obj.productDTO.productPrice}</p>
        <p style={{ marginLeft: "-17.7rem", marginTop: "1.5rem" }}>Qty:{props.obj.quantity}</p>
      </div>

    </>
  );
};

export const OrderCard = (props) => {
  const navigate = useNavigate();
  return (
    <div>
      <div className='d-flex' style={{ border: "solid", borderColor: "grey", height: "7rem", width: "40rem" }}><p onClick={() => navigate("/product", { state: props.obj.productDTO })} className='d-flex cardd '>
        <img src={props.obj.productDTO.productImagesDTOs[0].imgSrc} height="100rem" width="100rem" /><p style={{ margin: "0,5rem", paddingTop: "0.5rem", width: "15rem" }}>{props.obj.productDTO.productName}</p>
        <p style={{ marginLeft: "4rem", paddingTop: "2rem" }}>Qty. {props.obj.quantity}</p><p style={{ marginLeft: "4rem", paddingTop: "2rem" }}>Rs. {props.obj.productDTO.productPrice}</p></p>
      </div>
      <br />
    </div>
  )
};
