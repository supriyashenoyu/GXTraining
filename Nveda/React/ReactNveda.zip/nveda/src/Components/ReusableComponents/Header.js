import React, { useEffect, useRef, useState } from "react";
import logo from "../../assets/Images/logo.png";
import "bootstrap/dist/css/bootstrap.min.css";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import "../../assets/Css/Header.css";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { Offcanvas } from "react-bootstrap";
import axios from "axios";
import { SearchCard } from "./Card";
import Badge from 'react-bootstrap/Badge';

export const Header = () => {
  const navigate = useNavigate();
  const [product, setProduct] = useState();
  const [wishlistCount, setWishlistCount] = useState(0);
  const [cartCount, setCartCount] = useState(0);
  const [filteredItems, setFilteredItems] = useState([]);
  const [match, setMatch] = useState(false);
  const [currentItems, setCurrentItems] = useState([]);
  const [vis, setVis] = useState(false);
  const [search, setSearch] = useState("");


  const searchWord = useRef();
  const status = sessionStorage.getItem("status");
  const logIn = sessionStorage.getItem("email");
  const activeStyles = ({ isActive }) => {
    return {
      color: isActive ? "black" : "rgb(0 0 0 / 65%)",

      textDecoration: isActive ? "underline !important" : "none !important",
    };
  };



  useEffect(() => {
    if (status) {
      const profileUrl = `http://localhost:8080/nveda/profile/` + logIn;
      axios
        .get(profileUrl)
        .then((resData) => {
          if (resData.status === 200) {
            const url = `http://localhost:8080/nveda/getCart/` + resData.data.customerId;
            axios
              .get(url)
              .then((cartItems) => {
                if (cartItems.status === 200) {
                  setCartCount(cartItems.data.length);
                }
              })
              .catch((error) => console.log(error));

            const wishListUrl = `http://localhost:8080/nveda/getWishlist/` + resData.data.customerId;
            axios
              .get(wishListUrl)
              .then((wishlistData) => {
                if (wishlistData.status === 200) {
                  setWishlistCount(wishlistData.data.length);
                }
              })
              .catch((error) => console.log(error));
          }
        })
        .catch((error) => console.log(error));
    }

  }, []);

  /*
    Navigates to profile based on logIn status
   */
  const handleProfile = () => {
    if (status == "true") {
      window.location.href = "/profile";
    } else {
      window.location.href = "/login";
    }
  };
  const [show, setShow] = useState(false);
  const NavigateToSearch = () => {
    if (filteredItems.length > 0 && match == true) {
      setShow(false);
      navigate("/search", {
        state: { result: filteredItems, word: searchWord.current.value },
      });
      setCurrentItems([]);
    }
  };
  const handleClose = () => {
    setShow(false);
    setVis(false);
  };
  const handleShow = () => {
    setShow(true);
  };

  /*
    Loads all the products
   */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/products`;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) setProduct(resData.data);
      })
      .catch((error) => console.log(error));
  }, []);

  /*
    Navigates to wishlist based on logIn status
   */
  const NavigateToWishlist = () => {
    if (status == "true") {
      window.location.href = "/wishlist";
    } else {
      window.location.href = "/login";
    }
  };

  /*
    Navigates to cart based on logIn status
   */
  const NavigateToCart = () => {
    if (status == "true") {
      window.location.href = "/cart";
    } else {
      window.location.href = "/login";
    };

  }

  /*
    Filters products based input fileds data
   */
  useEffect(() => {
    const filtered = product?.filter((item) =>
      item.productName
        .toLowerCase()
        .includes(searchWord.current.value.toLowerCase())
    );
    setFilteredItems(filtered);
    setCurrentItems(filtered);
    if (search.length > 0 && currentItems?.length > 0) {
      setMatch(true);
    } else {
      setMatch(false);
    }
  }, [search]);


  function handleInputChange() {
    setVis(true);
    setSearch(searchWord.current.value.toLowerCase());
    const filtered = product?.filter((item) =>
      item.productName
        .toLowerCase()
        .includes(searchWord.current.value.toLowerCase())
    );
    setFilteredItems(filtered);
    setCurrentItems(filtered);
  }

  return (
    <div style={{ position: "sticky", top: "0rem", zIndex: "1" }}>
      <p
        class="banner"
        style={{
          height: "2rem",
          textAlign: "center",
          backgroundColor: "#5b7553",
          color: "#fafdff",
          marginBottom: "0 !important",
        }}
      >
        10% off on all purchases (Code: ofr10) | Create New Account / Reset the
        Password.
        <a
          href="https://wa.me/919008652145"
          target="_blank"
          title="https://wa.me/919008652145"
          rel="noreferrer noopener"
          style={{ color: "#fafdff" }}
        >
          Click Here
        </a>
        <a
          style={{ color: "#fafdff" }}
          href="https://nveda-main.myshopify.com/account/login#recover"
          target="_blank"
          title="https://nveda-main.myshopify.com/account/login#recover"
          rel="noreferrer noopener"
        >
          Click Here
        </a>{" "}
        | Take a free consultation with our health expert :{" "}
      </p>
      <Navbar
        expand="lg"
        className="navbar navbar-expand-lg bg-body-tertiary head"
      >
        <Container fluid>
          <Navbar.Brand href="#">
            <a class="navbar-brand" href="/HTML/homepage.html">
              <img src={logo} alt="Logo" width="100%" height="100rem" />
            </a>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: "100px", fontWeight: "bold", color: "black" }}
              navbarScroll
            >
              <NavLink to="/" style={activeStyles} className="navItemz">
                Home
              </NavLink>
              <NavLink style={activeStyles} className="navItemz" to="/shop">
                Shop
              </NavLink>
              <NavLink
                style={activeStyles}
                className="navItemz"
                to="/category/Combo Offer"
              >
                Combo Offer
              </NavLink>

              <NavLink
                style={activeStyles}
                className="navItemz"
                to="/category/Pack of 2 Offer"
              >
                Pack of 2 Offer
              </NavLink>
              <NavLink
                style={activeStyles}
                className="navItemz"
                to="/category/Ayurvedic Products"
              >
                Ayurvedic
              </NavLink>
              <NavDropdown
                title="Contact"
                id="navbarScrollingDropdown"
                class="navlink"
              >
                <NavDropdown.Item href="#action4">
                  Reset password
                </NavDropdown.Item>
              </NavDropdown>

              <NavDropdown
                title="About"
                id="navbarScrollingDropdown"
                class="navlink"
              >
                <div class="about">
                  <div style={{ textDecoration: "none" }}>
                    <a href="#action4">
                      <h4>POLICY</h4>
                    </a>
                    <li
                      style={{
                        listStyle: "none",
                        marginLeft: "4.5rem",
                        marginBottom: "0.5rem",
                      }}
                    >
                      <a class="linkglow">Shipping Policy</a>
                    </li>
                    <li
                      style={{
                        listStyle: "none",
                        marginLeft: "4.5rem",
                        marginBottom: "0.5rem",
                      }}
                    >
                      <a class="linkglow">Privacy Policy</a>
                    </li>
                    <li
                      style={{
                        listStyle: "none",
                        marginLeft: "4.5rem",
                        marginBottom: "0.5rem",
                      }}
                    >
                      <a class="linkglow">Refund Policy</a>
                    </li>
                    <li
                      style={{
                        listStyle: "none",
                        marginLeft: "4.5rem",
                        marginBottom: "0.5rem",
                      }}
                    >
                      <a class="linkglow">Terms & Conditions</a>
                    </li>
                  </div>
                  <a href="#action4">
                    <h4>Blogs</h4>
                  </a>
                </div>
              </NavDropdown>

              <NavLink
                id="navlink"
                to="/track"
                style={activeStyles}
                className="navItemz track"
              >
                Track Order
              </NavLink>
            </Nav>
            <div className="symbols">
              <li>
                <a>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="16"
                    width="16"
                    viewBox="0 0 512 512"
                    onClick={handleShow}
                  >
                    <path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
                  </svg>
                </a>
              </li>
              <Offcanvas show={show} onHide={handleClose} placement="top">
                <Offcanvas.Body>
                  <div
                    className="d-flex"
                    style={{ position: "sticky", top: "-3rem", zIndex: "1" }}
                  >
                    <input
                      type="text"
                      ref={searchWord}
                      onChange={handleInputChange}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") NavigateToSearch();
                      }}
                      style={{
                        width: "50rem",
                        margin: "2rem",
                        marginLeft: "12rem",
                        border: "0.1rem solid grey",
                      }}
                    />
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="20"
                      width="16"
                      viewBox="0 0 512 512"
                      style={{ marginTop: "2.5rem" }}
                      onClick={NavigateToSearch}
                    >
                      <path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
                    </svg>
                  </div>
                  {vis && (
                    <div
                      style={{
                        height: "auto",
                        width: "auto",
                        zIndex: "3",
                        position: "fixed",
                        left: "20rem",
                        backgroundColor: "white",
                      }}
                    >
                      {match ? (
                        <>
                          {currentItems?.slice(1, 4).map((items) => {
                            return (
                              <SearchCard obj={items} close={handleClose} />
                            );
                          })}
                        </>
                      ) : (
                        <p style={{ margin: "3rem" }}>No product found</p>
                      )}
                    </div>
                  )}
                </Offcanvas.Body>
              </Offcanvas>
              <li>
                <a>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="1em"
                    viewBox="0 0 512 512"
                    onClick={NavigateToWishlist}
                  >

                    <path d="M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z" />

                  </svg>

                </a>
                <Badge pill bg="secondary"  >{wishlistCount}</Badge>
              </li>
              <li>
                {/* <Badge  pill bg="secondary"  >9</Badge> */}
                <a >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="16"
                    width="14"
                    viewBox="0 0 448 512"
                    onClick={NavigateToCart}
                  >
                    <path d="M160 112c0-35.3 28.7-64 64-64s64 28.7 64 64v48H160V112zm-48 48H48c-26.5 0-48 21.5-48 48V416c0 53 43 96 96 96H352c53 0 96-43 96-96V208c0-26.5-21.5-48-48-48H336V112C336 50.1 285.9 0 224 0S112 50.1 112 112v48zm24 48a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm152 24a24 24 0 1 1 48 0 24 24 0 1 1 -48 0z" />

                  </svg>


                </a>
                <Badge pill bg="secondary"  >{cartCount}</Badge>
              </li>
              <li>
                <Link to="/profile">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="1em"
                    viewBox="0 0 448 512"
                    onClick={handleProfile}
                  >
                    <path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z" />
                  </svg>
                </Link>
              </li>
            </div>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
};
