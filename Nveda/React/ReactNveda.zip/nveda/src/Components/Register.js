import React, { useRef, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import "../assets/Css/Register.css";
import Breadcrumb from "react-bootstrap/Breadcrumb";

import { Link } from "react-router-dom";

export const Register = () => {
  const fname = useRef();
  const lname = useRef();
  const mail = useRef();
  const pass = useRef();

  const initialState = {
    firstname: null,
    lastname: null,
    email: null,
    password: null,
  };
  const [flag, setFlag] = useState({
    fnameFlag: false,
    lnameFlag: false,
    emailFlag: false,
    passFlag: false,
  });

  const [input, setInput] = useState(initialState);
  const [error, setError] = useState({
    firstName: "",
    lastName: "",
    email: "",
    pass: "",
  });

  /*
  Validate Fisrt Name
  */
  const ValidFirstName = () => {
    setInput({ ...input, firstname: fname.current.value });
    const FirstnameRegex = /^[a-zA-Z\. ]+$/i;
    if (!FirstnameRegex.test(fname.current.value)) {
      setError({ ...error, firstName: "Please enter a valid first name" });
      setFlag({ ...flag, fnameFlag: false });
    } else {
      setFlag({ ...flag, fnameFlag: true });
      setError({ ...error, firstName: "" });
    }
  };

  /*
  Validate Last Name
  */
  const ValidLastName = () => {
    setInput({ ...input, lastname: lname.current.value });
    const LastnameRegex = /^[a-zA-Z\. ]+$/i;
    if (!LastnameRegex.test(lname.current.value)) {
      setError({ ...error, lastName: "Please enter a valid last name" });
      setFlag({ ...flag, lnameFlag: false });
    } else {
      setFlag({ ...flag, lnameFlag: true });
      setError({ ...error, lastName: "" });
    }
  };

  /*
  Validate Email address
  */
  const ValidEmail = () => {
    setInput({ ...input, email: mail.current.value });
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/i;
    if (!emailRegex.test(input.email)) {
      setError({ ...error, email: "Please enter a valid email" });
      setFlag({ ...flag, emailFlag: false });
    } else {
      setFlag({ ...flag, emailFlag: true });
      setError({ ...error, email: "" });
    }
  };

  /*
  Validate Password
  */
  const ValidPass = () => {
    setInput({ ...input, password: pass.current.value });
    const passRegex =
      /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/i;
    if (!passRegex.test(input.password)) {
      setError({ ...error, pass: "Please enter a valid password" });
      setFlag({ ...flag, passFlag: false });
    } else {
      setFlag({ ...flag, passFlag: true });
      setError({ ...error, pass: "" });
    }
  };
  const handleLogin = () => {
    window.location.href = "/login";


  };

  const handleRegister = () => {
    if (flag.fnameFlag && flag.lnameFlag && flag.emailFlag && flag.passFlag) {
      addUser(); //Adding customers
      clear(); //clearing input fields
    }
  };

  /*
  Clears the input fields
  */
  const clear = () => {
    fname.current.value = "";
    lname.current.value = "";
    mail.current.value = "";
    pass.current.value = "";
  };

  /*
  Register Customer
  */
  const addUser = () => {
    let url = "http://localhost:8080/nveda/register";
    const reqBody = {
      firstName: input.firstname,
      lastName: input.lastname,
      email: input.email,
      password: input.password,
      addressDTO: [
        {
          firstName: input.firstname,
          lastName: input.lastname,
          email: null,
          phone: null,
          address1: null,
          address2: null,
          province: null,
          zip: null,
          city: null,
          country: null,
        },
      ],
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "Registration Successful!",
            text: "You can now login",
            icon: "success",
          });
        }
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Registration Failed",
          text: error.response.data,
        });
      });
  };
  return (
    <>
      <div style={{ background: "lightgray", height: "4rem" }}>
        <Breadcrumb style={{ padding: "1rem" }}>
          <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
          <Breadcrumb.Item href="#">Create Account</Breadcrumb.Item>
        </Breadcrumb>
      </div>
      <br />
      <h2 class="center">Register</h2>
      <form>
        <input
          type="text"
          placeholder="First name"
          ref={fname}
          value={input.firstname}
          className="inputTag"
          style={{ top: "30%" }}
          onChange={ValidFirstName.bind(this, fname)}
          required
        />
        <p
          style={{
            position: "relative",
            left: "40%",
            height: "0.5em",
            color: "red",
            width: "60%",
          }}
        >
          {error.firstName}
        </p>
        <input
          type="text"
          placeholder="Last name"
          ref={lname}
          value={input.lastname}
          className="inputTag"
          style={{ top: "35%" }}
          onChange={ValidLastName.bind(this, lname)}
          required
        />
        <p
          style={{
            position: "relative",
            left: "40%",
            height: "0.5em",
            color: "red",
            width: "60%",
          }}
        >
          {error.lastName}
        </p>

        <input
          type="email"
          placeholder="Email"
          ref={mail}
          value={input.email}
          className="inputTag"
          style={{ top: "40%" }}
          onChange={ValidEmail.bind(this, mail)}
          required
        />
        <p
          style={{
            position: "relative",
            left: "40%",
            height: "0.5em",
            color: "red",
            width: "60%",
          }}
        >
          {error.email}
        </p>

        <input
          type="password"
          placeholder="Password"
          ref={pass}
          value={input.password}
          className="inputTag"
          style={{ top: "45%" }}
          onChange={ValidPass.bind(this, pass)}
          required
        />
        <p
          style={{
            position: "relative",
            left: "40%",
            height: "0.5em",
            color: "red",
            width: "60%",
          }}
        >
          {error.pass}
        </p>

        <p
          style={{
            position: "relative",
            top: "5o%",
            left: "32%",
            width: "60%",
          }}
        >
          Sign up for early Sale access plus tailored new arrivals, trends and{" "}
          <br /> promotions. To opt out, click unsubscribe in our emails.
        </p>
        <br />
        <button
          type="submit"
          className="btnTag"
          style={{
            position: "relative",
            top: "42%",
            left: "40%",
            marginBottom: "1rem",
          }}
          onClick={handleRegister}
        >
          Register
        </button>
        <button
          type="submit"
          className="btnTag"
          style={{
            position: "relative",
            top: "42%",
            left: "46%",
            marginBottom: "1rem",
          }}
          onClick={handleLogin}
        >
          Login
        </button>
      </form>
    </>
  );
};
