import React, { createContext, useRef, useState } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Swal from "sweetalert2";
import axios from "axios";
import "../assets/Css/Register.css";
import { Link } from "react-router-dom";
import Breadcrumb from "react-bootstrap/Breadcrumb";

import "../assets/Css/Login.css";

export const Login = () => {


  const [input, setInput] = useState({
    email: null,
    password: null,
  });

  const mail = useRef();
  const pass = useRef();

  /*
    Naviagtes to Login page
    */
  const handleLogin = () => {
    const url = `http://localhost:8080/nveda/clearCompare`
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
          window.location.href = "/";
        }
      })
      .catch((error) => console.log(error));

  };

  /*
  Saves Email
  */
  const handleEmail = () => {
    setInput({ ...input, email: mail.current.value });
  };

  /*
  Saves Pssword
  */
  const handlePassword = () => {
    setInput({ ...input, password: pass.current.value });
  };

  /*
Authenticates customer by validating inputs
  */
  const authenticateUser = (e) => {
    e.preventDefault();
    let url = "http://localhost:8080/nveda/login";
    const reqBody = {
      email: input.email,
      password: input.password,
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "login Successful!",
            text: "You can use nveda",
            icon: "success",
            confirmButtonText: "Ok",
          }).then((result) => {
            if (result.value) {
              sessionStorage.setItem("status", true);
              sessionStorage.setItem("email", input.email);
              handleLogin();
            }
          });
        }
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          icon: "error",
          title: "Login Failed",
          text: error.response.data,
        });
      });
  };
  return (
    <>
      <div style={{ background: "lightgray", height: "4rem" }}>
        <Breadcrumb style={{ padding: "1rem" }}>
          <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
          <Breadcrumb.Item href="#">Account</Breadcrumb.Item>
        </Breadcrumb>
      </div>
      <br />
      <h2 class="center">Account</h2>
      <br />
      <Container>
        <Row>
          <Col>
            <form>
              <h4>Login</h4>
              <input
                type="email"
                ref={mail}
                placeholder="Email"
                onChange={handleEmail}
                className="input"
                required
              />
              <input
                type="password"
                ref={pass}
                placeholder="Password"
                onChange={handlePassword}
                className="input"
                required
              />
              <p>Forgot your password?</p>
              <button type="submit" class="btnTag" onClick={authenticateUser}>
                Sign in
              </button>
            </form>
          </Col>
          <Col xs={1}>
            <p className="vl"></p>
          </Col>
          <Col>
            <h4>New Customer</h4>
            <p>
              Sign up for early Sale access plus tailored new arrivals, trends
              and promotions. To opt out, click unsubscribe in our emails.
            </p>
            <button class="btnTag">
              <Link to="/register">Register</Link>
            </button>
          </Col>
        </Row>
      </Container>
    </>
  );
};
