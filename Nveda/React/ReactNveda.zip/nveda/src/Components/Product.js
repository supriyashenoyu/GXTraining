import React, { useEffect, useRef, useState } from "react";
import { Breadcrumb, Col, Container, Row } from "react-bootstrap";
import Swal from "sweetalert2";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import "../assets/Css/Product.css";
import "../assets/Css/courosel.css";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import ReactPlayer from "react-player";
import { Review } from "./Review";
export const Product = () => {
  const [currentUser, setCurrentUser] = useState([]);
  const [quantity, setQuantity] = useState(1);
  const [review, setReview] = useState(true);
  const status = sessionStorage.getItem("status");
  const logIn = sessionStorage.getItem("email");
  const [compare, setCompare] = useState(false);
  const { state } = useLocation();
  const [like, setLike] = useState();
  const [isIntersecting, setIsIntersecting] = useState(false);
  const addToCartRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsIntersecting(entry.isIntersecting);
      },
    );
    observer.observe(addToCartRef.current);

    return () => observer.disconnect();
  }, [isIntersecting]);



  /*
   Toggles like button
   */
  const toggleLike = () => {
    if (status == "true") {
      setLike(!like);
      if (!like) {
        addWishlist();
      } else {
        removeFromWishlist();
      }

    } else {
      window.location.href = "/login";
    }
  };
  useEffect(() => {
    const url = `http://localhost:8080/nveda/checkCompare/` + state.productId;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
          if (resData.data === 1) {
            setCompare(true);
          } else {
            setCompare(false);
          }
        }
      })
      .catch((error) => console.log(error));
  }, [])

  /*
 Toggles Compare button
 */
  const toggleCompare = () => {

    setCompare(!compare);
    if (!compare) {
      countCompare();
    } else {
      removeFromCompare();
    }


  };

  /*
    Adds Items to cart
   */
  const addToCart = () => {
    if (state.stock < 1) {
      Swal.fire({
        text: "item out of stock",
        timer: 1000,
        icon: "error",
        showConfirmButton: false,
      });
    } else {
      if (status == "true") {
        let url = `http://localhost:8080/nveda/addToCart`;
        const reqBody = {
          productDTO: state,
          quantity: quantity,
          customerRegistrationDTO: currentUser,
          totalAmount: state.productPrice * quantity,
        };
        axios
          .post(url, reqBody, {
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Headers": "Content-Type",
              "Access-Control-Allow-Origin": "*",
            },
          })
          .then((resData) => {
            if (resData.status === 200) {
              Swal.fire({
                title: "Added to Cart",
                icon: "success",
                timer: 1000,
                showConfirmButton: false,
              });
              setTimeout(refresh, 1100);
            }
          })
          .catch((error) => {
            console.log(error);
            Swal.fire({
              icon: "error",
              title: error.response.data,
              timer: 1000,
              showConfirmButton: false,
            });

          });
      } else {
        window.location.href = "/login";
      }
    }
  };

  const buy=()=>{
    if (state.stock < 1) {
      Swal.fire({
        text: "item out of stock",
        timer: 1000,
        icon: "error",
        showConfirmButton: false,
      });
    } else {
      if (status == "true") {
        let url = `http://localhost:8080/nveda/addToCart`;
        const reqBody = {
          productDTO: state,
          quantity: quantity,
          customerRegistrationDTO: currentUser,
          totalAmount: state.productPrice * quantity,
        };
        axios
          .post(url, reqBody, {
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Headers": "Content-Type",
              "Access-Control-Allow-Origin": "*",
            },
          })
          .then((resData) => {
            if (resData.status === 200) {
              window.location.href = "/cart";
            }
          })
          .catch((error) => {
            console.log(error);
            Swal.fire({
              icon: "error",
              title: error.response.data,
              timer: 1000,
              showConfirmButton: false,
            });

          });
      } else {
        window.location.href = "/login";
      }
    }
    
  }

  /*
    Loads current user details
   */
  useEffect(
    () => {
      setLike(false);
      const url = `http://localhost:8080/nveda/profile/` + logIn;
      axios
        .get(url)
        .then((resData) => {
          if (resData.status === 200) {
            setCurrentUser(resData.data);
            const likeUrl =
              `http://localhost:8080/nveda/setFlag/` + resData.data.customerId;
            axios
              .get(likeUrl)
              .catch((error) => console.log(error));
            const ResetUrl =
              `http://localhost:8080/nveda/resetFlag/` + resData.data.customerId;
            axios
              .get(ResetUrl)
              .catch((error) => console.log(error));
          }
        })
        .catch((error) => console.log(error));
    },
    []
  );

  useEffect(() => {
    const url =
      `http://localhost:8080/nveda/getProductById/` + state.productId;
    axios
      .get(url).then((resData) => {
        if (resData.status == 200) {
          setLike(resData.data.wishlistflag);
        }

      })
      .catch((error) => console.log(error));
  }, [])
  const refresh = () => {

    window.location.reload()
  }


  /*
    Adds product to wishlist
   */
  const addWishlist = () => {
    let url = "http://localhost:8080/nveda/addToWishlist";
    const reqBody = {
      customerRegistrationDTO: currentUser,
      productDTO: state,
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            text: "Added to wishlist",
            timer: 1000,
            icon: "success",
            showConfirmButton: false,
          });
          addLike();
          setTimeout(refresh, 1100);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  /*
    Removes product to wishlist
   */
  const removeFromWishlist = () => {
    if (status == "true") {
      const url = `http://localhost:8080/nveda/deleteFromWishlist/${currentUser.customerId}/${state.productId}`;
      axios
        .delete(url)
        .then((resData) => {
          if (resData.status === 200) {
            Swal.fire({
              text: "Product is Removed from Wishlist",
              timer: 1000,
              icon: "error",
              showConfirmButton: false,
            });
            removeLike();
            setTimeout(refresh, 1100);
          }
        })
        .catch((error) => console.log(error));
    }
  };

  /*
    counts product in compare
   */
  const countCompare = () => {
    let url = "http://localhost:8080/nveda/countCompare";
    axios
      .get(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((count) => {
        if (count.status === 200) {
          addCompare();
        }
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          text: error.response.data,
          timer: 800,
          icon: "error",
          showConfirmButton: false,
        });
        setCompare(false);
      });
  };

  /*
    Adds product to compare
   */
  const addCompare = () => {
    let url = "http://localhost:8080/nveda/setCompare/" + state.productId;
    axios
      .get(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            text: "Added to compare",
            timer: 800,
            icon: "success",
            showConfirmButton: false,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  /*
    Removes product from compare
   */
  const removeFromCompare = () => {
    let url = "http://localhost:8080/nveda/resetCompare/" + state.productId;
    axios
      .get(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            text: "Removed product from compare",
            timer: 800,
            icon: "success",
            showConfirmButton: false,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  /*
    Loads like buuton  based on customers wishlist
   */
  const removeLike = () => {
    if (status == "true") {
      const url =
        `http://localhost:8080/nveda/resetFlag/` + currentUser.customerId;
      axios
        .get(url)
        .then((resData) => {
          if (resData.status === 200) {
            console.log("like flag", like, state.wishlistflag);
          }
        })
        .catch((error) => console.log(error));
    }
  };

  /*
    Loads like buuton  based on customers wishlist
   */
  const addLike = () => {
    if (status == "true") {
      const url =
        `http://localhost:8080/nveda/setFlag/` + currentUser.customerId;
      axios
        .get(url)
        .catch((error) => console.log(error));
    }
  };

  /*
    IncrementProductQuantityements quantity based on product's stock
   */
  const IncrementProductQuantity = () => {
    if (quantity < state.stock) {
      setQuantity(quantity + 1);
    } else {
      Swal.fire({
        text: "item out of stock",
        timer: 1000,
        icon: "error",
        showConfirmButton: false,
      });
    }
  };

  const openReview = () => {
    setReview(false);


  }

  const openDescription = () => {
    setReview(true);


  }

  /*
    decrementProductQuantityement quantity based on product's stock
   */
  const decrementProductQuantity = () => {
    if (quantity > 1) setQuantity(quantity - 1);
  };
  return (
    <div>
      <div style={{ background: "#f3f3f3", height: "4rem" }}>
        <Breadcrumb style={{ padding: "1.5rem" }}>
          <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
          <Breadcrumb.Item href="#">
            {state.categoryDTO.categoryName}
          </Breadcrumb.Item>
          <Breadcrumb.Item active>{state.productName}</Breadcrumb.Item>
        </Breadcrumb>
      </div>
      <br />
      <br />
      <Container>
        <Row>
          <Col
            lg={6}
            xm={8}
            xs={10}
            style={{ padding: "1rem" }}
            className="d-flex"
          >
            <Carousel axis="vertical" swipeable="false">
              {state.productImagesDTOs.map((items) => {
                if (items.imgSrc[9] == "w") {
                  return (
                    <div className="res">
                      <ReactPlayer
                        style={{ marginLeft: "-3rem" }}
                        url={items.imgSrc}
                        height="20rem"
                        width="35rem"
                      />
                      <img src={items.thumbnail} height="70rem" width="70rem" />
                    </div>
                  );
                } else {
                  return (
                    <div className="res">
                      <img src={items.imgSrc} />
                    </div>
                  );
                }
              })}
            </Carousel>
          </Col>
          <Col
            lg={6}
            xm={4}
            sx={2}
            style={{ backgroundColor: "#f8f4e3", padding: "1rem" }}
          >
            <h2>{state.productName}</h2>
            <br />
            <h6>Rs. {state.productPrice}</h6>
            <br />
            <p>Tax and Shipping included.</p>
            <div>
              <br />
              <div className="d-flex">
                <p>Qty :</p>
                <p style={{ backgroundColor: "#f6f6f6", borderRadius: "20%", marginLeft: "1rem" }}>
                  <a
                    onClick={decrementProductQuantity}
                    style={{ marginLeft: "1rem", marginRight: "1rem" }}
                  >
                    -
                  </a>
                  {quantity}
                  <a
                    onClick={IncrementProductQuantity}
                    style={{ marginLeft: "1rem", marginRight: "1rem" }}
                  >
                    +
                  </a>
                </p>
              </div>
              <br />
              <button className="btnTagBig" ref={addToCartRef} onClick={addToCart}>
                Add to Cart
              </button>
              <br />
              <br />
              <div className="d-flex">
                <a
                  onClick={toggleLike}
                  className="logoutLink"
                  style={{ marginRight: "3rem" }}
                >
                  Wishlist
                  <svg
                    style={{
                      position: "relative",
                      top: "0.2rem",
                      fill: like ? "red" : "black",
                    }}
                    xmlns="http://www.w3.org/2000/svg"
                    height="16"
                    width="16"
                    viewBox="0 0 512 512"
                  >
                    <path d="M225.8 468.2l-2.5-2.3L48.1 303.2C17.4 274.7 0 234.7 0 192.8v-3.3c0-70.4 50-130.8 119.2-144C158.6 37.9 198.9 47 231 69.6c9 6.4 17.4 13.8 25 22.3c4.2-4.8 8.7-9.2 13.5-13.3c3.7-3.2 7.5-6.2 11.5-9c0 0 0 0 0 0C313.1 47 353.4 37.9 392.8 45.4C462 58.6 512 119.1 512 189.5v3.3c0 41.9-17.4 81.9-48.1 110.4L288.7 465.9l-2.5 2.3c-8.2 7.6-19 11.9-30.2 11.9s-22-4.2-30.2-11.9zM239.1 145c-.4-.3-.7-.7-1-1.1l-17.8-20c0 0-.1-.1-.1-.1c0 0 0 0 0 0c-23.1-25.9-58-37.7-92-31.2C81.6 101.5 48 142.1 48 189.5v3.3c0 28.5 11.9 55.8 32.8 75.2L256 430.7 431.2 268c20.9-19.4 32.8-46.7 32.8-75.2v-3.3c0-47.3-33.6-88-80.1-96.9c-34-6.5-69 5.4-92 31.2c0 0 0 0-.1 .1s0 0-.1 .1l-17.8 20c-.3 .4-.7 .7-1 1.1c-4.5 4.5-10.6 7-16.9 7s-12.4-2.5-16.9-7z" />
                  </svg>
                </a>
                <a onClick={toggleCompare}
                  className="logoutLink">
                  <svg
                    style={{ position: "relative", top: "0.2rem", fill: compare ? "red" : "black", }}
                    xmlns="http://www.w3.org/2000/svg"
                    height="16"
                    width="16"
                    viewBox="0 0 512 512"
                  >
                    <path d="M345 39.1L472.8 168.4c52.4 53 52.4 138.2 0 191.2L360.8 472.9c-9.3 9.4-24.5 9.5-33.9 .2s-9.5-24.5-.2-33.9L438.6 325.9c33.9-34.3 33.9-89.4 0-123.7L310.9 72.9c-9.3-9.4-9.2-24.6 .2-33.9s24.6-9.2 33.9 .2zM0 229.5V80C0 53.5 21.5 32 48 32H197.5c17 0 33.3 6.7 45.3 18.7l168 168c25 25 25 65.5 0 90.5L277.3 442.7c-25 25-65.5 25-90.5 0l-168-168C6.7 262.7 0 246.5 0 229.5zM144 144a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z" />
                  </svg>
                  Compare
                </a>
              </div>
              <br />
              <button className="classicBtn" onClick={buy}>BUY IT NOW</button>
              <br />
              <br />
              <div className="d-flex">
                <p>share: </p>
                <svg
                  style={{ margin: "0.3rem" }}
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="16"
                  viewBox="0 0 512 512"
                >
                  <path d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z" />
                </svg>
                <svg
                  style={{ margin: "0.3rem" }}
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="16"
                  viewBox="0 0 512 512"
                >
                  <path d="M459.4 151.7c.3 4.5 .3 9.1 .3 13.6 0 138.7-105.6 298.6-298.6 298.6-59.5 0-114.7-17.2-161.1-47.1 8.4 1 16.6 1.3 25.3 1.3 49.1 0 94.2-16.6 130.3-44.8-46.1-1-84.8-31.2-98.1-72.8 6.5 1 13 1.6 19.8 1.6 9.4 0 18.8-1.3 27.6-3.6-48.1-9.7-84.1-52-84.1-103v-1.3c14 7.8 30.2 12.7 47.4 13.3-28.3-18.8-46.8-51-46.8-87.4 0-19.5 5.2-37.4 14.3-53 51.7 63.7 129.3 105.3 216.4 109.8-1.6-7.8-2.6-15.9-2.6-24 0-57.8 46.8-104.9 104.9-104.9 30.2 0 57.5 12.7 76.7 33.1 23.7-4.5 46.5-13.3 66.6-25.3-7.8 24.4-24.4 44.8-46.1 57.8 21.1-2.3 41.6-8.1 60.4-16.2-14.3 20.8-32.2 39.3-52.6 54.3z" />
                </svg>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      {isIntersecting ? <p></p> : <div style={{ position: "fixed", top: "32rem", height: "5rem", width: "100%", backgroundColor: "white", zIndex: "1" }} className='d-flex'>
        <img src={state.productImagesDTOs[0].imgSrc} style={{ marginLeft: "3rem" }} />
        <p style={{ marginTop: "0.5rem", position: "fixed", top: "32rem", left: "10rem", color: "black", fontWeight: "500", fontSize: "0.8rem" }}>{state.productName}</p>
        <p style={{ position: "fixed", top: "34rem", left: "10rem", color: "black", fontWeight: "500", fontSize: "0.8rem" }}>Rs. {state.productPrice}</p>
        <div className="d-flex" style={{ position: "fixed", top: "33rem", left: "58rem" }}>
          <p style={{ backgroundColor: "#f6f6f6", borderRadius: "20%", height: "2rem" }}>
            <a
              onClick={decrementProductQuantity}
              style={{ marginLeft: "1rem", marginRight: "1rem" }}
            >
              -
            </a>
            {quantity}
            <a
              onClick={IncrementProductQuantity}
              style={{ marginLeft: "1rem", marginRight: "1rem" }}
            >
              +
            </a>
          </p>
        </div>  <button className="btnTagBig" onClick={addToCart} style={{ position: "fixed", top: "33rem", left: "65rem" }}>
          Add to Cart
        </button></div>}
      <div>
        <br />
        <div style={{ margin: "2rem" }}>
          <div className="d-flex">
            <h4 onClick={openDescription}>Description</h4>
            <h4 style={{ marginLeft: "1rem" }}>Composition</h4>
            <h4 style={{ marginLeft: "2rem" }} onClick={openReview}>Reviews</h4>
            <h4 style={{ marginLeft: "2rem" }}>FAQ</h4>
            <h4 style={{ marginLeft: "2rem" }}>Additional Info</h4>
            <h4 style={{ marginLeft: "2rem" }}>Nutrition</h4>
          </div>

          {review ? <div style={{ backgroundColor: "#f8f4e3" }}>
            <h4 style={{ paddingTop: "2rem", paddingLeft: "2rem" }}>
              {state.productName}
            </h4><div style={{ padding: "2rem" }}>{state.productDesc}</div></div> : <Review product={state} />}

        </div>
      </div>
      <br />
    </div>
  );
};
