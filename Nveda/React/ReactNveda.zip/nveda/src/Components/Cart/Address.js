import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react'
import Select from "react-select";
import "../../assets/Css/Cart.css";
import Swal from 'sweetalert2';

export const Address = (props) => {

  const [indianStates, setIndianStates] = useState([]);
  const logIn = sessionStorage.getItem("email");
  const [selProvince, setSelProvince] = useState("");
  const [validAddress, setValidAddresss] = useState(false);
  const initialState = {
    fullName: null,
    phone: props.contact,
    zip: null,
    province: null,
    address1: null,
    address2: null,
    city: null,

  };
  const [input, setInput] = useState(initialState);
  const [flag, setFlag] = useState({
    fullNameFlag: "",
    phoneFlag: true,
    zipFlag: "",
    provinceFlag: "",
    cityFlag: "",
    address1Flag: "",
    address2Flag: "",
  });
  const [error, setError] = useState({
    fullName: "",
    email: "",
    zip: "",
    city: "",
  });
  const fullName = useRef();
  const phone = useRef({});
  const address1 = useRef();
  const address2 = useRef();
  const zip = useRef();
  const city = useRef();
  const checkboxRef = useRef();
  phone.current.value = props.contact;

  useEffect(() => {

    handleAddress();
  }, [input])

  const addAddress = () => {
    let url = "http://localhost:8080/nveda/add";
    const reqBody = {
      firstName: input.fullName,
      lastName: "",
      email: logIn,
      phone: input.phone,
      address1: input.address1,
      address2: input.address2,
      province: input.province,
      zip: input.zip,
      city: input.city,
      country: "",
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      }).then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: " Successfully!",
            icon: "success",
          })
        }
      })

      .catch((error) => {
        console.log(error);
        Swal.fire({
          title: " failed!",
          icon: "error",
        })
      });
  };
  /*
   Validate First Name
  */
  const ValidFullName = () => {
    setInput({ ...input, fullName: fullName.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (fullName.current.value != "" && !nameRegex.test(fullName.current.value)) {
      setError({ ...error, fullName: "Please enter a valid full name" });
      setFlag({ ...flag, fullNameFlag: false });
    } else {
      setFlag({ ...flag, fullNameFlag: true });
      setError({ ...error, fullName: "" });
    }
  };



  /*
    Validate Phone Number
   */
  const ValidPhone = () => {
    setInput({ ...input, phone: phone.current.value });
    const phoneRegex = /^[7-9]\d{9}$/;
    if (phone.current.value != "" && !phoneRegex.test(phone.current.value)) {
      setError({ ...error, phone: "Please enter a valid phone number" });
      setFlag({ ...flag, phoneFlag: false });
    } else {
      setFlag({ ...flag, phoneFlag: true });
      setError({ ...error, phone: "" });
    }
  };

  /*
    Validate Zip code
   */
  const ValidZip = () => {
    const inputValue = zip.current.value;
    const zipRegex = /^[1-9][0-9]{5}$/;
    if (!zipRegex.test(inputValue)) {
      setError({ ...error, zip: "Please enter a valid zip code" });
      setFlag({ ...flag, zipFlag: false });
    } else {
      setInput({ ...input, zip: inputValue });
      setFlag({ ...flag, zipFlag: true });
      setError({ ...error, zip: null });
    }
  };

  /*
    Validate City
   */
  const ValidCity = () => {
    setInput({ ...input, city: city.current.value });
    const cityRegex = /^[a-zA-Z\. ]+$/i;
    if (city.current.value != null) {
      if (city.current.value != "" && !cityRegex.test(input.city)) {
        setError({ ...error, city: "Please enter a valid city name" });
        setFlag({ ...flag, cityFlag: false });
      } else {
        setFlag({ ...flag, cityFlag: true });
        setError({ ...error, city: "" });
      }
    }
  };
  const states = indianStates.map((state) => ({ value: state, label: state }));
  /*
    Stores Province
   */
  const saveProvince = (value) => {

    setFlag({ ...flag, provinceFlag: true });
    setSelProvince(value);
    setInput({ ...input, province: value.label });
  };

  /*
   Loads states based on country
 */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/states`;
    axios
      .get(url)
      .then((resData) => {
        setIndianStates(resData.data);
      })
      .catch((error) => console.log(error));
  }, []);

  const setAddr = () => {
    if (address1.current.value != "") {
      setFlag({ ...flag, address1Flag: true });
    }
    if (address2.current.value != "") {
      setFlag({ ...flag, address2Flag: true });
    }
    setInput({
      ...input,
      address1: address1.current.value,
      address2: address2.current.value,
    });

  };


  const handleAddress = () => {
    if (
      flag.fullNameFlag &&
      flag.cityFlag &&
      flag.phoneFlag &&
      flag.zipFlag &&
      flag.provinceFlag &&
      flag.address1Flag &&
      flag.address2Flag
    ) {

      props.nextSection();
      if (checkboxRef.current.checked) {
        addAddress();
      }
    }
  };

  return (
    <>
      <div> <div className="d-flex">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 448 512"
          style={{
            height: "1rem",
            width: "1rem",
            marginTop: "0.3rem",
            marginRight: "0.5rem",
          }}
        >

          <path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z" />
        </svg>
        <p>Delivery Address</p>



      </div>
        <input placeholder="Full Name*" ref={fullName} onChange={ValidFullName.bind(this, fullName)} style={{ border: "solid grey 0.1rem", width: "21rem" }} /> {error.fullName}
        <input placeholder="Enter phone number*" ref={phone} onChange={ValidPhone.bind(this, phone)} style={{ border: "solid grey 0.1rem", width: "21rem" }} /> {error.phone}
        <input placeholder="Enter pin code*" ref={zip} onChange={ValidZip.bind(this, zip)} style={{ border: "solid grey 0.1rem", width: "21rem" }} />{error.zip}
        <div className='d-flex'> <Select
          placeholder="States"
          className='stateSelect'
          options={states}
          value={selProvince}
          onChange={saveProvince}
        /> <input placeholder="City*" ref={city} onChange={ValidCity.bind(this, city)} style={{ border: "solid grey 0.1rem", width: "10.5rem" }} />{error.city}</div>
        <input placeholder="House Number, Apartment *" ref={address1} onChange={setAddr} style={{ border: "solid grey 0.1rem", width: "21rem" }} />
        <input placeholder="Area, Colony, Street, Sector*" ref={address2} onChange={setAddr} style={{ border: "solid grey 0.1rem", width: "21rem" }} />
        <p className='d-flex'><input type="checkbox" ref={checkboxRef} style={{ height: "1rem", width: "1rem" }} /><p>Save Address</p></p>
      </div>

    </>
  )
}
