import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { Col, Container, Row } from "react-bootstrap";
import { CartCard, PaymentCard } from "../ReusableComponents/Card";
import { NumericFormat } from "react-number-format";
import "../../assets/Css/Cart.css";

import Modal from "react-bootstrap/Modal";
import { Address } from "./Address";
import Swal from "sweetalert2";
export const Cart = () => {
  const logIn = sessionStorage.getItem("email");
  const [currentUser, setCurrentUser] = useState({});
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0.0);
  const [showPayment, setShowPayment] = useState(false);
  const [summaryStyle, setSummaryStyle] = useState(true);
  const [addressStyle, setAddressStyle] = useState(false);
  const [paymentStyle, setPaymentStyle] = useState(false);
  const [phone, setPhone] = useState("");
  const [showCoupon, setShowCoupon] = useState(false);
  const [phoneError, setPhoneError] = useState(null);
  const [isPhoneFlag, setIsPhoneFlag] = useState(false);
  const mobile = useRef({});
  const [loadPhone, setLoadPhone] = useState();
  const [validAddress, setValidAddresss] = useState(false);
  const handlePaymentClose = () => setShowPayment(false);
  const handleShowPayment = () => {
    setShowPayment(true);
    setShowCoupon(false);
    setSummaryStyle(true);
    setAddressStyle(false);
    setPaymentStyle(false);

  }
  const processPayment = () => {
    if (isPhoneFlag && phoneError != null) {
      setSummaryStyle(false);
      setAddressStyle(true);
      if (validAddress) {
        setSummaryStyle(false);
        setAddressStyle(false);
        setPaymentStyle(true);
      }
    }
  }
  const showPaymentSection = () => {
    setValidAddresss(true);

  }
  useEffect(() => {
    mobile.current.value = phone;
  }, [loadPhone])
  const handleCoupon = () => setShowCoupon(true);
  const handleBack = () => {
    if (addressStyle == true) {
      setLoadPhone(!loadPhone);
      setSummaryStyle(true);
      setAddressStyle(false);
      setPaymentStyle(false);
    } else {
      setSummaryStyle(false);
      setAddressStyle(true);
      setPaymentStyle(false);
    }
  }



  /*
       Loads current user
     */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/profile/` + logIn;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
          setCurrentUser(resData.data);
        }
      })
      .catch((error) => console.log(error));
  }, []);

  /*
       Calculates Total amount of products in cart
     */
  let sumOfPrice = 0.0;
  const CartTotal = (cartItem) => {
    sumOfPrice += cartItem.totalAmount;
  };

  /*
     Loads Cart Items
   */
  const loadCart = () => {
    const url = `http://localhost:8080/nveda/getCart/` + currentUser.customerId;
    axios
      .get(url)
      .then((cartItems) => {
        if (cartItems.status === 200) {
          setCart(cartItems.data);
        }
      })
      .catch((error) => console.log(error));
  };

  /*
     Calculates total cart amount
   */
  useEffect(() => {
    cart.map(CartTotal);
    setTotal(sumOfPrice);
  }, [cart]);

  /*
       Loads cart
     */
  useEffect(
    () => {
      loadCart();
    },
    [currentUser],
    [cart],
    []
  );

  const navigateToShop = () => {
    window.location.href = "/shop";
  };

  const ValidPhone = () => {
    const phoneRegex = /^[7-9]\d{9}$/;
    if (!phoneRegex.test(mobile.current.value)) {
      setPhoneError("Please enter a valid phone number");
      setIsPhoneFlag(false);
    } else {
      setPhone(mobile.current.value);
      setPhoneError("");
      setIsPhoneFlag(true);
    }
  };
  const orderingProduct = () => {
    cart.map((items) => orderProduct(items.productDTO, items.quantity, items.productDTO.productPrice));

  }

  const orderProduct = (productDTO, quant, price) => {
    let url = "http://localhost:8080/nveda/addToOrder";
    const reqBody = {
      customerRegistrationDTO: currentUser,
      productDTO: productDTO,
      quantity: quant,
      totalAmount: price
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "Payment Successfully!",
            text: "Oder Placed",
            icon: "success",
          }).then((result) => {
            if (result.value) {
              handlePaymentClose();
              loadCart();


            }
          });
        }
      })
      .catch((error) => {

      });
  }

  return (
    <div>
      <br />
      <span className="d-flex" style={{ justifyContent: "space-between" }}>
        <h3 style={{ marginLeft: "3rem" }}>My Cart</h3>
        <button
          style={{
            margin: "1rem",
            marginRight: "4rem",
            fontSize: "medium",
            fontWeight: "bold",
          }}
          className="btnTag"
          onClick={navigateToShop}
        >
          Go Back
        </button>
      </span>
      <br />
      <Container>
        <Row>
          <Col xs={9}>
            <div className="d-flex">
              <h6 style={{ marginLeft: "15rem" }}>Product</h6>
              <h6 style={{ marginLeft: "11rem" }}>Price</h6>
              <h6 style={{ marginLeft: "5rem" }}>Quantity</h6>
              <h6 style={{ marginLeft: "4.5rem" }}>Total</h6>
            </div>
            <br />
            {cart.map((items) => {
              return <CartCard obj={items} load={loadCart} />;
            })}
          </Col>
          <Col xs={3} style={{ marginLeft: "-2rem" }}>
            <h6>ORDER SUMMARY</h6>
            <hr
              style={{
                border: "solid 0.3 rem black",
                width: "20rem",
                height: "1rem",
              }}
            />

            <p>Order special instructions</p>
            <textarea
              rows="4"
              cols="40"
              name="comment"
              placeholder="Order special instructions"
            ></textarea>
            <div
              className="d-flex"
              style={{ justifyContent: "space-between", height: "2rem" }}
            >
              <h6 style={{ marginTop: "1rem" }}>Sub Total</h6>
              <p style={{ marginRight: "-3.5rem", marginTop: "1rem" }}>
                <NumericFormat
                  value={total}
                  decimalScale={2}
                  displayType={"text"}
                  thousandSeparator=","
                  prefix={"Rs. "}
                  suffix={".00"}
                  style={{ fontWeight: "bold" }}
                />
              </p>
            </div>
            <hr style={{ border: "solid 0.3 rem grey", width: "20rem" }} />
            <p>Tax and Shipping Included</p>
            <button
              className="classicBtn"
              style={{ width: "20rem" }}
              onClick={handleShowPayment}
            >
              Check Out
            </button>
            <Modal
              show={showPayment}
              onHide={handlePaymentClose}
              size="lg"
              style={{ height: "100rem" }}
            >
              <Modal.Header closeButton style={{ backgroundColor: "#005bf2" }}>
                <Modal.Title>
                  <strong style={{ color: "white" }}>Nveda</strong>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Container>
                  <Row style={{ height: "100 rem !important" }}>
                    <Col xs={6} style={{ borderRight: "0.05rem solid grey", height: "27rem" }}>
                      <div
                        className="d-flex"
                        style={{
                          justifyContent: "space-around",

                        }}
                      >
                        {summaryStyle ? <></> : <a className="cardd" onClick={handleBack}>{"<-"}</a>}
                        <p style={summaryStyle ? { color: "blue", fontWeight: "600" } : { color: "black" }}>
                          Summary
                        </p>
                        <p>{">>"}</p>
                        <p style={addressStyle ? { color: "blue", fontWeight: "600" } : { color: "black" }}>
                          Address
                        </p>{" "}
                        <p>{">>"}</p>
                        <p style={paymentStyle ? { color: "blue", fontWeight: "600" } : { color: "black" }}>
                          Payments
                        </p>
                      </div>
                      <hr style={{ position: "relative", top: "-1rem", margin: "0.1rem" }} />
                      {summaryStyle && (
                        <>
                          <div className="d-flex">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 448 512"
                              style={{
                                height: "1rem",
                                width: "1rem",
                                marginTop: "0.3rem",
                                marginRight: "0.5rem",
                              }}
                            >
                              <path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z" />
                            </svg>
                            <p>Contact Details</p>
                          </div>
                          <input placeholder="Enter phone number" ref={mobile} onChange={ValidPhone.bind(this, mobile)} style={{ border: "solid grey 0.1rem", width: "21rem" }} />
                          {phoneError}
                          <hr />
                          {showCoupon ? <><input placeholder="Enter Coupon code" style={{ border: "solid grey 0.1rem", width: "21rem" }} /><p style={{ color: "blue", position: "relative", left: "18rem", top: "-2.2rem", fontWeight: "500" }} className="cardd" >Apply</p></> : <div className="d-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style={{
                            height: "1rem",
                            width: "1rem",
                            marginTop: "0.3rem",
                            marginRight: "0.5rem",
                          }}><path d="M14 2.2C22.5-1.7 32.5-.3 39.6 5.8L80 40.4 120.4 5.8c9-7.7 22.3-7.7 31.2 0L192 40.4 232.4 5.8c9-7.7 22.3-7.7 31.2 0L304 40.4 344.4 5.8c7.1-6.1 17.1-7.5 25.6-3.6s14 12.4 14 21.8V488c0 9.4-5.5 17.9-14 21.8s-18.5 2.5-25.6-3.6L304 471.6l-40.4 34.6c-9 7.7-22.3 7.7-31.2 0L192 471.6l-40.4 34.6c-9 7.7-22.3 7.7-31.2 0L80 471.6 39.6 506.2c-7.1 6.1-17.1 7.5-25.6 3.6S0 497.4 0 488V24C0 14.6 5.5 6.1 14 2.2zM96 144c-8.8 0-16 7.2-16 16s7.2 16 16 16H288c8.8 0 16-7.2 16-16s-7.2-16-16-16H96zM80 352c0 8.8 7.2 16 16 16H288c8.8 0 16-7.2 16-16s-7.2-16-16-16H96c-8.8 0-16 7.2-16 16zM96 240c-8.8 0-16 7.2-16 16s7.2 16 16 16H288c8.8 0 16-7.2 16-16s-7.2-16-16-16H96z" /></svg>
                            <p>Have a Coupon ?</p><a style={{ fontWeight: "bold", position: "relative", left: "11rem", fontSize: "larger" }} onClick={handleCoupon}>{">"}</a>
                          </div>}
                          <hr style={{ position: "relative", top: "-1rem" }} />
                        </>
                      )}
                      {addressStyle && <Address contact={phone} nextSection={showPaymentSection} />}
                      {paymentStyle && <><div className="d-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style={{
                        height: "1rem",
                        width: "1rem",
                        marginTop: "0.3rem",
                        marginRight: "0.5rem",
                      }}><path d="M14 2.2C22.5-1.7 32.5-.3 39.6 5.8L80 40.4 120.4 5.8c9-7.7 22.3-7.7 31.2 0L192 40.4 232.4 5.8c9-7.7 22.3-7.7 31.2 0L304 40.4 344.4 5.8c7.1-6.1 17.1-7.5 25.6-3.6s14 12.4 14 21.8V488c0 9.4-5.5 17.9-14 21.8s-18.5 2.5-25.6-3.6L304 471.6l-40.4 34.6c-9 7.7-22.3 7.7-31.2 0L192 471.6l-40.4 34.6c-9 7.7-22.3 7.7-31.2 0L80 471.6 39.6 506.2c-7.1 6.1-17.1 7.5-25.6 3.6S0 497.4 0 488V24C0 14.6 5.5 6.1 14 2.2zM96 144c-8.8 0-16 7.2-16 16s7.2 16 16 16H288c8.8 0 16-7.2 16-16s-7.2-16-16-16H96zM80 352c0 8.8 7.2 16 16 16H288c8.8 0 16-7.2 16-16s-7.2-16-16-16H96c-8.8 0-16 7.2-16 16zM96 240c-8.8 0-16 7.2-16 16s7.2 16 16 16H288c8.8 0 16-7.2 16-16s-7.2-16-16-16H96z" /></svg>
                        <p>Payment</p></div><button className="cartBtnTag" onClick={orderingProduct} >Complete payment</button></>}
                      <div className="d-flex" style={{ position: "fixed", top: "31rem", backgroundColor: "white" }}><NumericFormat
                        value={total}
                        decimalScale={2}
                        displayType={"text"}
                        thousandSeparator=","
                        prefix={"₹ "}
                        suffix={".00"}
                        style={{ marginTop: "0.4rem" }}
                      /><button className="btnTag" style={{ backgroundColor: "#005bf2", color: "white", marginLeft: "2rem", width: "15rem", height: "3rem", fontWeight: "600" }} onClick={processPayment}>Continue</button></div>
                    </Col>
                    <Col xs={6}>
                      <p style={{ textAlign: "center", fontWeight: "bold" }}>
                        Order Summary
                      </p>
                      {cart.map((items) => {
                        return <PaymentCard obj={items} />;
                      })}
                      <hr style={{ borderTop: "dashed" }} />
                      <p
                        className="d-flex"
                        style={{ justifyContent: "space-between" }}
                      >
                        <p>Price (incl. taxes)</p>
                        <NumericFormat
                          value={total}
                          decimalScale={2}
                          displayType={"text"}
                          thousandSeparator=","
                          prefix={"₹ "}
                          suffix={".00"}
                        />
                      </p>
                    </Col>
                  </Row>
                </Container>
              </Modal.Body>

            </Modal>
            <br />
            <br />
          </Col>
        </Row>
      </Container>
    </div>
  );
};
