import React from 'react'

export const Payment = () => {
  return (
    <div>Payment</div>
  )
}
