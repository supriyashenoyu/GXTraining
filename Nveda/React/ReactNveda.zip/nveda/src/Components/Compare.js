import React, { useEffect, useState } from 'react'
import '../assets/Css/Compare.css'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import ReactStars from 'react-stars';

export const Compare = () => {
  const [compare, setCompare] = useState([]);
  const [compareVisiblity, setCompareVisiblity] = useState(false)
  const [ratingVisiblityProduct1,setRatingVisiblityProduct1]=useState(false); 
  const [ratingVisiblityProduct2,setRatingVisiblityProduct2]=useState(false); 
   const navigate = useNavigate();
  useEffect(() => {
    let url = 'http://localhost:8080/nveda/getCompare';
    axios
      .get(url)
      .then((compareData) => {
        if (compareData.status === 200) {
          setCompare(compareData.data);
          if (compareData.data.length > 0) {
            setCompareVisiblity(true);
          }
         if(compareData.data[0].rating>0){
          setRatingVisiblityProduct1(true);
         }
         if(compareData.data[1].rating>0){
          setRatingVisiblityProduct2(true);
         }
        }
      })
      .catch((error) => console.log(error));

  }, [])


  const navigateToShop = () => {
    window.location.href = "/shop";
  }
  
  return (
    <div>
      <div className='d-flex' >
        <h4 style={{ position: "relative", left: "3rem", margin: "1rem" }}>Compare with similar items</h4>
        <button className='btnTag' style={{ position: "relative", left: "50rem", margin: "1rem" }} onClick={navigateToShop}>Go back</button>
      </div>
      {compareVisiblity ? <table style={{ position: "relative", left: "30%", margin: "2rem" }}>
        <tr>
          <th style={{ padding: "1rem" }}>Product</th>
          <td style={{ padding: "1rem" }} className="trans"><img src={compare[0].productImagesDTOs[0].imgSrc} height="200rem" width="150rem" onClick={() => navigate("/product", { state: compare[0] })} /></td>
          {compare[1] ? <td style={{ padding: "1rem" }} className="trans"><img src={compare[1].productImagesDTOs[0].imgSrc} height="200rem" width="150rem" onClick={() => navigate("/product", { state: compare[1] })} /></td> : <></>}
        </tr>
        <tr>
          <th style={{ padding: "1rem" }}>Price</th>
          <td style={{ padding: "1rem" }}>₹ {compare[0].productPrice}</td>
          {compare[1] ? <td style={{ padding: "1rem" }}>₹ {compare[1].productPrice}</td> : <></>}
        </tr>
        <tr>
          <th style={{ padding: "1rem" }}>Rating</th>
          <td style={{ padding: "1rem" }} >{ratingVisiblityProduct1?<><p>{compare[0].rating}.0</p>
           <ReactStars
              count={5}
              value={compare[0].rating}
              edit={false}
              size={25}
              isHalf={true}
              quiet={false}
              emptyIcon={<i className="far fa-star"></i>}
              halfIcon={<i className="fa fa-star-half-alt"></i>}
              fullIcon={<i className="fa fa-star"></i>}
              activeColor="#ffd700"
            /></>:<p>No Rating Available</p>}
            </td>
          {compare[1] ?  
            <td style={{ padding: "1rem" }} >{ratingVisiblityProduct2?<><p>{compare[1].rating}</p>
           <ReactStars
              count={5}
              value={compare[1].rating}
              edit={false}
              size={25}
              isHalf={true}
              quiet={false}
              emptyIcon={<i className="far fa-star"></i>}
              halfIcon={<i className="fa fa-star-half-alt"></i>}
              fullIcon={<i className="fa fa-star"></i>}
              activeColor="#ffd700"
            /></>:<p>No Rating Available</p>}
            </td>: <></>}
        </tr>
      </table> : <div style={{ position: "relative", left: "20rem", top: "15%", backgroundColor: "lightgray", width: "40rem", height: "10rem", lineHeight: "10rem", margin: "2rem", textAlign: "center", fontWeight: "600", fontSize: "1.5rem" }}>No products to Compare</div>
      }
    </div>
  )
}
