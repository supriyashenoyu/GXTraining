import React, { useEffect, useState } from "react";
import Banner1 from "../assets/Images/Banner1.png";
import Banner2 from "../assets/Images/Banner2.png";
import Carousel from "react-bootstrap/Carousel";
import cleanIngredients from "../assets/Images/cleanIngredients.avif";
import Researched from "../assets/Images/Researched formulas.png";
import delivery from "../assets/Images/delivery.webp";
import "../assets/Css/Home.css";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import axios from "axios";
import { CardComp, SmallCard } from "./ReusableComponents/Card";

export const Home = () => {
  const [cat, setCat] = useState([]);
  const [product, setProduct] = useState([]);
  const [banner, setBanner] = useState([]);

  /*
    Loads all the category
  */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/getBanner`;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status == 200) {
          setBanner(resData.data);
        }
      })
      .catch((error) => console.log(error));
  }, []);

  /*
    Loads all the category
  */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/category`;
    axios
      .get(url)
      .then((resData) => {
        setCat(resData.data);
      })
      .catch((error) => console.log(error));
  }, []);

  /*
    Loads all the products
  */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/products`;
    axios
      .get(url)
      .then((resData) => {
        setProduct(resData.data);
      })
      .catch((error) => console.log(error));
  }, []);
  const currentItems = product.slice(1, 9);
  const currentCategory = cat.slice(0, 6)

  return (
    <div>
      <div
        id="carouselExampleControls"
        class="carousel slide"
        data-ride="carousel"
      >
        <Carousel>
          <Carousel.Item>
            {console.log("banner", banner[1])}
            {banner[0] != null && banner[0].bannerImgSrc ? <img src={banner[0].bannerImgSrc} style={{ width: "100%" }} /> : <></>}
          </Carousel.Item>
          <Carousel.Item>
            {banner[1] != null && banner[1].bannerImgSrc ? <img src={banner[1].bannerImgSrc} style={{ width: "100%" }} /> : <></>}
          </Carousel.Item>
          <Carousel.Item>
            {banner[2] != null && banner[2].bannerImgSrc ? <img src={banner[2].bannerImgSrc} style={{ width: "100%" }} /> : <></>}
          </Carousel.Item>
        </Carousel>
      </div>
      <p
        style={{
          position: "relative",
          top: "auto",
          textAlign: "center",
          margin: "1rem",
        }}
      >
        <h1>Elevate your well-being with our Supplements</h1>
      </p>
      <div className="d-flex" style={{ justifyContent: "space-around" }}>
        <img src={cleanIngredients} height="60" width="60" className="zoom" />
        <p style={{ marginTop: "1rem", marginLeft: "-4rem" }}>
          Clinically Researched Ingredients
        </p>
        <img src={Researched} height="60" width="60" className="zoom" />
        <p style={{ marginTop: "1rem", marginLeft: "-4rem" }}>
          Well Researched Formulations
        </p>
        <img src={delivery} height="60" width="60" className="zoom" />
        <p style={{ marginTop: "1rem", marginLeft: "-4rem" }}>
          Free Home Delivery
        </p>
      </div>
      <p
        style={{
          position: "relative",
          top: "auto",
          textAlign: "center",
          margin: "1rem",
        }}
      >
        <h1>Shop by Category</h1>
      </p>
      <br />
      <br />
      <Container>
        <Row>
          {currentCategory.map((items) => {
            return (
              <Col xs={2}>
                <SmallCard style={{ width: "10rem", border: "none" }}
                  obj={items}
                />
              </Col>
            )
          })}
        </Row>
      </Container>
      <br />
      <br />
      <br />
      <Container>
        <Row>
          <Col xs={6}>
         {banner[3] != null && banner[3].bannerImgSrc ?   <img
              src={banner[3].bannerImgSrc}
              width="90%"
              height="100%/"
            />:<></> }
          </Col>

          <Col xs={6}>
          { banner[3] != null && banner[3].bannerImgSrc ? <p>
               <h3>{banner[3].bannerTitle}</h3>
              {banner[3].description}
            </p>:<></>}
            <button className="btn">Know more</button>
          </Col>
        </Row>
        <br />
        <br />
        { banner[4] != null && banner[4].bannerImgSrc ?  <Row>
          <Col xs={6}>
           <p>
              <h3>{banner[4].bannerTitle}</h3>
              {banner[4].description}
            </p>
            <button className="btn">Get it now</button>
          </Col>

          <Col xs={6}>
            <img
              src={banner[4].bannerImgSrc}
              width="90%"
              height="100%/"
            />
          </Col>
        </Row>:<></>}
      </Container>
      <br />
      <p
        style={{
          position: "relative",
          top: "auto",
          textAlign: "center",
          margin: "1rem",
        }}
      >
        <h1>Our Products</h1>
      </p>
      <Container>
        <Row>
          {currentItems.map((items) => {
            return (
              <Col xs={3}>
                <CardComp style={{ width: "15rem", margin: "1rem" }}
                  obj={items}
                />
              </Col>
            )
          })}

        </Row>
      </Container>

    </div>
  );
};
