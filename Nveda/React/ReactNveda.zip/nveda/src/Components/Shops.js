import React, { useState, useEffect } from "react";
import { Container, Col, Row } from "react-bootstrap";
import axios from "axios";
import "../assets/Css/Shop.css";
import Slider from "react-slider";
import { Pagination } from "react-bootstrap";
import { CardComp } from "./ReusableComponents/Card";

export const Shop = () => {
  const [product, setProduct] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [vis, setVis] = useState(false);
  const [cp, setCp] = useState(1);
  const [cpFilter, setCpFilter] = useState(1);
  const itemsPerPage = 12;
  const indexOfLastItem = cp * itemsPerPage;
  const indexOfLastFilteredItem = cpFilter * itemsPerPage;//2*12
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const indexOfFirstFilteredItem = indexOfLastFilteredItem - itemsPerPage;
  const [currentItems, setCurrentItems] = useState(); //19-12=7
  const [inStockProducts, setInStockProducts] = useState();
  const [outOfStockProducts, setOutOfStockProducts] = useState();
  const pagiante = (pageNumber) => { setCp(pageNumber); };
  const pagianteFilter = (pageNumbers) => { setCpFilter(pageNumbers); };

  const [dropdownButton, setDropDownButton] = useState({
    collectionDropdown: true,
    availabilityDropdown: true,
    priceDropdown: true,
  });

  /*
    DropDown button toggle function
  */
  const toggleCollection = () => {
    setDropDownButton({ ...dropdownButton, collectionDropdown: !dropdownButton.collectionDropdown });
  };
  const toggleAvailability = () => {
    setDropDownButton({ ...dropdownButton, AvailabilityDropdown: !dropdownButton.availabilityDropdown });
  };
  const togglePrice = () => {
    setDropDownButton({ ...dropdownButton, priceDropdown: !dropdownButton.priceDropdown });
  };

  let highestPrice = 0

  /*
    Calculates maximum price of the product
  */
  function maxProductPrice(productItem) {
    if (productItem.productPrice > highestPrice) {
      highestPrice = productItem.productPrice
    }
  }

  const [minPrice, setMinPrice] = useState(0)
  const [maxPrice, setMaxPrice] = useState(0)
  const [values, setValues] = useState([minPrice, maxPrice]);

  /*
      Loads count of stock and out of stock items
    */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/stock`;
    axios
      .get(url)
      .then((stock) => {
        if (stock.status == "200") {
          setInStockProducts(stock.data)
        }
      })
      .catch((error) => console.log(error));
    const outOfStockUrl = `http://localhost:8080/nveda/outOfStock`;
    axios
      .get(outOfStockUrl)
      .then((stock) => {
        if (stock.status == "200") {
          setOutOfStockProducts(stock.data);
        }
      })
      .catch((error) => console.log(error));
  }, [])

  /*
     Loads all the products
   */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/products`;
    axios
      .get(url)
      .then((resData) => {
        resData.data.map(maxProductPrice);
        setMaxPrice(highestPrice);
        setValues([0, highestPrice])
      })
      .catch((error) => console.log(error));
  }, [])
  useEffect(() => {
    const url = `http://localhost:8080/nveda/products`;
    axios
      .get(url)
      .then((resData) => {
        setProduct(resData.data);
        setFiltered(resData.data.slice(indexOfFirstItem, indexOfLastItem));
      })
      .catch((error) => console.log(error));
  }, [cp], [cpFilter]);

  /*
      Loads product according to price filter
    */
  useEffect(() => {
    var filteredList = product.filter(item => item.productPrice >= values[0] && item.productPrice <= values[1]);
    if (filteredList.length === product.length) {
      setCurrentItems(true);
    } else {
      setCurrentItems(false);
    }
    setFiltered(filteredList.slice(indexOfFirstFilteredItem, indexOfLastFilteredItem));
  }, [values]);

  /*
   Navigates to Combo page
  */
  const NavigateToCombo = () => {
    window.location.href = "/category/Combo Offer";
  }
  /*
    Navigates to Nveda products page
   */
  const NavigateToNveda = () => {
    setVis(true);
  }
  return (
    <div>
      <br />
      <Container>
        <Row>
          <Col xs={3}>
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <h6>Collection</h6>
              {dropdownButton.collectionDropdown ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleCollection}
                >
                  <path d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleCollection}
                >
                  <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              )}
            </div>
            {dropdownButton.collectionDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links" onClick={NavigateToCombo}>Combo Offer</p>
                <p className="circle">05</p>
              </div>
            )}
            {dropdownButton.collectionDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links" onClick={NavigateToNveda}>Nveda</p>
                <p className="circle">{inStockProducts}</p>
              </div>
            )}

            <br />
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <h6>Availability</h6>
              {dropdownButton.availabilityDropdown ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleAvailability}
                >
                  <path d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={toggleAvailability}
                >
                  <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              )}
            </div>
            {dropdownButton.availabilityDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links">In Stock</p>
                <p className="circle">{inStockProducts}</p>
              </div>
            )}
            {dropdownButton.availabilityDropdown && (
              <div
                className="d-flex"
                style={{ justifyContent: "space-between" }}
              >
                <p className="links">Out of Stock</p>
                <p className="circle">{outOfStockProducts}</p>
              </div>
            )}
            <br />
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <h6>Price</h6>
              {dropdownButton.priceDropdown ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={togglePrice}
                >
                  <path d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="16"
                  width="14"
                  viewBox="0 0 448 512"
                  onClick={togglePrice}
                >
                  <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              )}
            </div>
            {dropdownButton.priceDropdown && (
              <>
                <Slider
                  className={"slider"}
                  onChange={setValues}
                  value={values}
                  min={minPrice}
                  max={maxPrice}
                />
                <div className="values">
                  Rs {values[0]} - Rs {values[1]}
                </div>
              </>
            )}
          </Col>
          <Col xs={9}>{vis ? <h3 style={{ marginLeft: "2rem" }}>Nveda</h3> :
            <h3 style={{ marginLeft: "2rem" }}>Products</h3>}
            <br />
            <Container>
              <Row>
                {filtered?.map((items) => {
                  return (
                    <Col>
                      <CardComp
                        style={{ width: "23rem", margin: "0.5rem" }}
                        obj={items}
                      />
                    </Col>
                  );
                })}

              </Row>
            </Container>
          </Col>
        </Row>
        <br />
        <Pagination style={{ position: "relative", left: "60%" }}>
          {currentItems ? <>{Array.from({ length: Math.ceil(product.length / itemsPerPage) }).map(
            (_, index) => (
              <Pagination.Item
                key={index}
                active={index + 1 === cp}
                onClick={() => pagiante(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            )
          )}</> : <>{Array.from({ length: Math.ceil(filtered.length / itemsPerPage) }).map(
            (_, index) => (
              <Pagination.Item
                key={index}
                active={index + 1 === cpFilter}
                onClick={() => pagianteFilter(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            )
          )}</>}
        </Pagination>
      </Container>
    </div>
  );
};
