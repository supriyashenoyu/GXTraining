import React, { useEffect, useState } from 'react'
import { useMemo, useRef } from "react";
import Select from "react-select";
import countryList from "react-select-country-list";
import Swal from "sweetalert2";
import axios from "axios";
import '../../assets/Css/Profile.css'
export const Edit = (props) => {
  const [prov, setProv] = useState(false)
  const [vis, setVis] = useState(false)
  const [indianStates, setIndianStates] = useState([]);
  const [selCountry, setSelCountry] = useState("");
  const [selProvince, setSelProvince] = useState("");
  const initialState = {
    firstName: props.obj.firstName,
    lastName: props.obj.lastName,
    phone: props.obj.phone,
    address1: props.obj.address1,
    address2: props.obj.address2,
    province: props.obj.province,
    zip: props.obj.zip,
    city: props.obj.city,
    country: props.obj.country,
  };

  const [input, setInput] = useState(initialState);
  const firstName1 = useRef({});
  const lastName1 = useRef({});
  const phone1 = useRef({});
  const address11 = useRef({});
  const address21 = useRef({});
  const province = useRef({});
  const zip1 = useRef({});
  const city1 = useRef({});

  const [flag, setFlag] = useState({
    isFirstNameValid: true,
    lastNameFlag: true,
    phoneFlag: true,
    zipFlag: true,
    cityFlag: true,
  });
  const ValidfName = () => {
    //Validating first Name
    setInput({ ...input, firstName: firstName1.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (!nameRegex.test(firstName1.current.value)) {
      setError({ ...error, firstName: "Please enter a valid first name" });
      setFlag({ ...flag, isFirstNameValid: false });
    } else {
      setFlag({ ...flag, isFirstNameValid: true });
      setError({ ...error, firstName: "" });
    }
  };

  const ValidlName = () => {
    setInput({ ...input, lastName: lastName1.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (!nameRegex.test(lastName1.current.value)) {
      setError({ ...error, lastName: "Please enter a valid last name" });
      setFlag({ ...flag, lastNameFlag: false });
    } else {
      setFlag({ ...flag, lastNameFlag: true });
      setError({ ...error, lastName: "" });
    }
  };
  const ValidPhone = () => {
    //Validating Phone
    setInput({ ...input, phone: phone1.current.value });
    const nameRegex = /^[7-9]\d{9}$/;
    if (phone1.current.value != "" && !nameRegex.test(phone1.current.value)) {
      setError({ ...error, phone: "Please enter a valid phone number" });
      setFlag({ ...flag, phoneFlag: false });
    } else {
      setFlag({ ...flag, phoneFlag: true });
      setError({ ...error, phone: "" });
    }
  };
  const ValidZip = () => {
    //Validating Zip
    const inputValue = zip1.current.value;

    const nameRegex = /^[1-9][0-9]{5}$/;
    if (!nameRegex.test(inputValue)) {
      setError({ ...error, zip: "Please enter a valid zip code" });
      setFlag({ ...flag, zipFlag: false });
    } else {
      setInput({ ...input, zip: inputValue });
      setFlag({ ...flag, zipFlag: true });
      setError({ ...error, zip: null });
    }
  };

  const ValidCity = () => {
    setInput({ ...input, city: city1.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (city1.current.value != null) {
      if (city1.current.value != "" && !nameRegex.test(input.city)) {
        setError({ ...error, city: "Please enter a valid city name" });
        setFlag({ ...flag, cityFlag: false });
      } else {
        setFlag({ ...flag, cityFlag: true });
        setError({ ...error, city: "" });
      }
    }
  };
  const getStates = () => {
  }


  const counties = useMemo(() => countryList().getData(), []);
  const states = indianStates.map((state) => (
    {
      value: state,
      label: state
    }));

  const saveCountry = (value) => {
    setSelCountry(value);
    setInput({ ...input, country: value.label });
    if (value.label === "India") {
      setProv(true);
    } else {
      setProv(false);
    }
  };
  const saveProvince = (value) => {
    setSelProvince(value);
    province.current.value = value;
    setInput({ ...input, province: value.label });
  };
  const setAddr = () => {
    setInput({
      ...input,
      address1: address11.current.value,
      address2: address21.current.value,
    });
  };
  const [error, setError] = useState({
    firstName: "",
    lastName: "",
    email: "",
    zip: "",
    city: "",
    country: "",
  });
  const [load, setLoad] = useState();
  const checkProvince = () => {
    let province = props.obj.province;
    if (province != null) {
      setProv(true)
    }
  }
  const deleteAddress = () => {
    const id = props.obj.addressId;
    let url = `http://localhost:8080/nveda/delete/` + id

    axios
      .delete(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "Deleted Successfully!",
            icon: "success",
          }).then((result) => {

            if (result.value) {

              window.location.href = "/profile";

            }
          });

        }
      })
      .catch((error) => {
        console.log(error);
      });
  }
  useEffect(() => {
    firstName1.current.value = props.obj.firstName;
    lastName1.current.value = props.obj.lastName;
    phone1.current.value = props.obj.phone;
    city1.current.value = props.obj.city;
    address11.current.value = props.obj.address1;
    address21.current.value = props.obj.address2;
    zip1.current.value = props.obj.zip;
    setSelCountry({
      label: props.obj.country
    });
    setSelProvince({
      label: props.obj.province
    })
  }, [load])
  const update = () => {
    setLoad(true);
    setVis(true);
    setInput({
      ...input,
      firstName: props.obj.firstName,
      lastName: props.obj.lastName,
      address1: props.obj.address1,
      address2: props.obj.address2,
      city: props.obj.city,
      country: props.obj.country,
      province: props.obj.province,
      phone: props.obj.phone,
      zip: props.obj.zip,
    });
  }

  const cancelUpdate = () => {
    setVis(false)
  }
  const UpdateAddress = () => {
    let url = "http://localhost:8080/nveda/update";
    const reqBody = {
      "addressId": props.obj.addressId,
      "email": props.obj.email,
      "firstName": input.firstName,
      "lastName": input.lastName,
      "phone": input.phone,
      "address1": input.address1,
      "address2": input.address2,
      "province": input.province,
      "zip": input.zip,
      "city": input.city,
      "country": input.country,
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "Updated Successfully!",
            icon: "success",
          });

          props.obj.firstName = input.firstName;
          props.obj.lastName = input.lastName;
          props.obj.phone = input.phone;
          props.obj.city = input.city;
          props.obj.address1 = input.address1;
          props.obj.address2 = input.address2;
          props.obj.zip = input.zip;

          setVis(false);
        }
      })
      .catch((error) => {

      });

  }
  useEffect(() => {
    const url = `http://localhost:8080/nveda/states`
    axios
      .get(url)
      .then((resData) => {
        setIndianStates(resData.data);

      })
      .catch((error) => console.log(error));

  }, []);

  useEffect(() => checkProvince())
  return (<><h3>{props.obj.firstName}</h3>
    <div> <span className="d-flex">
      <p style={{ marginRight: "8rem", marginLeft: "1rem" }}>
        First name :
      </p>
      <p>{props.obj.firstName}</p>
    </span>
      <hr />
      <span className="d-flex">
        <p style={{ marginRight: "8rem", marginLeft: "1rem" }}>
          Last name :
        </p>
        <p>{props.obj.lastName}</p>
      </span>
      <hr />
      <span className="d-flex">
        <p style={{ marginRight: "8.2rem", marginLeft: "1rem" }}>
          Address 1 :
        </p>
        <p>{props.obj.address1}</p>
      </span>
      <hr />
      <span className="d-flex">
        <p style={{ marginRight: "8.2rem", marginLeft: "1rem" }}>
          Address 2 :
        </p>
        <p>{props.obj.address2}</p>
      </span>
      <hr />
      <span className="d-flex">
        <p style={{ marginRight: "11rem", marginLeft: "1rem" }}>
          City :
        </p>
        <p>{props.obj.city}</p>
      </span>
      <hr />
      <span className="d-flex">
        <p style={{ marginRight: "6rem", marginLeft: "1rem" }}>
          Country/region :
        </p>
        <p>{props.obj.country}</p>
      </span>
      <hr />
      {prov && (
        <>
          <span className="d-flex">
            <p style={{ marginRight: "8.9rem", marginLeft: "1rem" }}>
              province :
            </p>
            <p>{props.obj.province}</p>
          </span>
          <hr />
        </>
      )}
      <span className="d-flex">
        <p style={{ marginRight: "5.8rem", marginLeft: "1rem" }}>
          Portal/ZIP code :
        </p>
        <p>{props.obj.zip}</p>
      </span>
      <hr />
      <span className="d-flex">
        <p style={{ marginRight: "9.7rem", marginLeft: "1rem" }}>
          Phone :
        </p>
        <p>{props.obj.phone}</p>
      </span>
      <button className="btnTag" onClick={update}>Edit</button>
      <button className="btnTag" onClick={deleteAddress}>Delete</button></div>
    <br />
    {vis && (<><form>
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          First name:
        </label>
        <input
          placeholder="First Name"
          class="updateInput"
          style={{ marginLeft: "5rem" }}
          ref={firstName1}
          onChange={ValidfName.bind(this, firstName1)}
        ></input>
      </span>{" "}
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      >
        {error.firstName}
      </p>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          Last name:
        </label>
        <input
          placeholder="Last Name"
          class="updateInput"
          style={{ marginLeft: "5rem" }}
          ref={lastName1}
          onChange={ValidlName.bind(this, lastName1)}
        ></input>
      </span>{" "}
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      >
        {error.lastName}
      </p>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          Address1:
        </label>
        <input
          placeholder="Address 1"
          class="updateInput"
          style={{ marginLeft: "6rem" }}
          ref={address11}
          onChange={setAddr}
        ></input>
      </span>
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      ></p>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          Address2:
        </label>
        <input
          placeholder="Address 2"
          class="updateInput"
          style={{ marginLeft: "5.7rem" }}
          ref={address21}
          onChange={setAddr}
        ></input>
      </span>
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      ></p>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          City:
        </label>
        <input
          placeholder="City"
          class="updateInput"
          style={{ marginLeft: "8.5rem" }}
          ref={city1}
          onChange={ValidCity.bind(this, city1)}
        ></input>
      </span>
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      >
        {error.city}
      </p>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      <span className="d-flex">
        <label style={{ marginRight: "5rem", marginLeft: "2rem" }}>
          Country/region:
        </label>
        <Select
          options={counties}
          value={selCountry}
          onChange={saveCountry}
        />
      </span>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      {prov && (
        <>
          <span className="d-flex">
            <label
              style={{ marginRight: "8rem", marginLeft: "2rem" }}
            >
              Province:
            </label>
            <Select
              styles={{
                "color": "black"
              }}
              options={states}
              value={selProvince}
              onChange={saveProvince}
            />
          </span>
          <hr style={{ position: "relative", top: "0.3rem" }} />
        </>
      )}
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          Portal/ZIP code:
        </label>
        <input
          placeholder="zip"
          class="updateInput"
          style={{ marginLeft: "3.2rem" }}
          ref={zip1}
          onChange={ValidZip.bind(this, zip1)}
        ></input>
      </span>
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      >
        {error.zip}
      </p>
      <hr style={{ position: "relative", top: "0.3rem" }} />
      <span className="d-flex">
        <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
          Phone:
        </label>
        <input
          placeholder="Phone"
          class="updateInput"
          style={{ marginLeft: "7rem" }}
          ref={phone1}
          onChange={ValidPhone.bind(this, phone1)}
        ></input>
      </span>{" "}
      <p
        style={{
          position: "relative",
          left: "25%",
          top: "0.2rem",
          height: "1rem",
          color: "red",
          width: "60%",
          margin: "0rem",
        }}
      >
        {error.phone}
      </p>
    </form> <br />
      <br />
      <button
        class="btnTag"
        style={{
          position: "relative",
          left: "15rem",
          marginBottom: "1rem",
        }}
        onClick={UpdateAddress}
      >
        Update
      </button>
      <button
        class="btnTag"
        style={{
          position: "relative",
          left: "15rem",
          marginBottom: "1rem",
        }}
        onClick={cancelUpdate}
      >
        Cancel
      </button>
      <br /></>)}
  </>);
}
