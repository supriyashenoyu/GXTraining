import React, { useEffect, useRef, useState } from "react";
import { Container, Col, Row, Breadcrumb } from "react-bootstrap";
import "../../assets/Css/Profile.css";
import axios from "axios";
import Swal from "sweetalert2";
import { useMemo } from "react";
import Select from "react-select";
import countryList from "react-select-country-list";
import { Edit } from "./Edit";
import { OrderCard } from "../ReusableComponents/Card";

export const Profile = () => {
  const [indianStates, setIndianStates] = useState([]);
  const logIn = sessionStorage.getItem("email");
  const [details, setDetails] = useState([]);
  const [vis, setVis] = useState(true);
  const [add, showAdd] = useState(true);
  const [orderItem, setOrderItem] = useState([]);
  const [orderVis, setOrderVis] = useState(false);
  const update = () => {
    showAdd(false);
  };

  const initialState = {
    firstName: null,
    lastName: null,
    phone: null,
    address1: null,
    address2: null,
    province: null,
    zip: null,
    city: null,
    country: null,
  };
  const [input, setInput] = useState(initialState);
  const [flag, setFlag] = useState({
    isFirstNameValid: false,
    lastNameFlag: false,
    phoneFlag: true,
    zipFlag: true,
    cityFlag: true,
  });

  /*
       Adds a new  Validated Address
  */
  const handleAddress = () => {
    if (
      flag.isFirstNameValid &&
      flag.lastNameFlag &&
      flag.cityFlag &&
      flag.phoneFlag &&
      flag.zipFlag
    ) {
      addAddress();
      clear();
      profile();
    }
  };

  /*
      Loads Current User details
  */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/profile/` + logIn;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
          setDetails(resData.data);
          const orderUrl = `http://localhost:8080/nveda/getOrder/` + resData.data.customerId;
          axios
            .get(orderUrl)
            .then((orderItems) => {
              if (orderItems.status === 200) {
                setOrderVis(true);
                setOrderItem(orderItems.data);


              }
            })
            .catch((error) => console.log(error));
        }
      })
      .catch((error) => console.log(error));
  }, [vis],[]);
  const [prov, setProv] = useState(false);
  const [selCountry, setSelCountry] = useState("");
  const [selProvince, setSelProvince] = useState("");
  const firstName = useRef();
  const lastName = useRef();
  const phone = useRef();
  const address1 = useRef();
  const address2 = useRef();
  const province = useRef();
  const zip = useRef();
  const city = useRef();



  /*
      Stores the address
  */
  const addAddress = () => {
    let url = "http://localhost:8080/nveda/add";
    const reqBody = {
      firstName: input.firstName,
      lastName: input.lastName,
      email: logIn,
      phone: input.phone,
      address1: input.address1,
      address2: input.address2,
      province: input.province,
      zip: input.zip,
      city: input.city,
      country: input.country,
    };
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "Updated Successfully!",
            icon: "success",
          });
        }
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Registration Failed",
          text: error.response.data,
        });
      });
  };

  /*
    Loads states based on country
  */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/states`;
    axios
      .get(url)
      .then((resData) => {
        setIndianStates(resData.data);
      })
      .catch((error) => console.log(error));
  }, []);

  /*
    Validate First Name
   */
  const ValidFirstName = () => {
    setInput({ ...input, firstName: firstName.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (!nameRegex.test(firstName.current.value)) {
      setError({ ...error, firstName: "Please enter a valid first name" });
      setFlag({ ...flag, isFirstNameValid: false });
    } else {
      setFlag({ ...flag, isFirstNameValid: true });
      setError({ ...error, firstName: "" });
    }
  };

  /*
    Validate Last Name
   */
  const ValidLastName = () => {
    setInput({ ...input, lastName: lastName.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (!nameRegex.test(lastName.current.value)) {
      setError({ ...error, lastName: "Please enter a valid last name" });
      setFlag({ ...flag, lastNameFlag: false });
    } else {
      setFlag({ ...flag, lastNameFlag: true });
      setError({ ...error, lastName: "" });
    }
  };

  /*
    Validate Phone Number
   */
  const ValidPhone = () => {
    setInput({ ...input, phone: phone.current.value });
    const nameRegex = /^[7-9]\d{9}$/;
    if (phone.current.value != "" && !nameRegex.test(phone.current.value)) {
      setError({ ...error, phone: "Please enter a valid phone number" });
      setFlag({ ...flag, phoneFlag: false });
    } else {
      setFlag({ ...flag, phoneFlag: true });
      setError({ ...error, phone: "" });
    }
  };

  /*
    Validate Zip code
   */
  const ValidZip = () => {
    const inputValue = zip.current.value;
    const nameRegex = /^[1-9][0-9]{5}$/;
    if (!nameRegex.test(inputValue)) {
      setError({ ...error, zip: "Please enter a valid zip code" });
      setFlag({ ...flag, zipFlag: false });
    } else {
      setInput({ ...input, zip: inputValue });
      setFlag({ ...flag, zipFlag: true });
      setError({ ...error, zip: null });
    }
  };

  /*
    Validate City
   */
  const ValidCity = () => {
    setInput({ ...input, city: city.current.value });
    const nameRegex = /^[a-zA-Z\. ]+$/i;
    if (city.current.value != null) {
      if (city.current.value != "" && !nameRegex.test(input.city)) {
        setError({ ...error, city: "Please enter a valid city name" });
        setFlag({ ...flag, cityFlag: false });
      } else {
        setFlag({ ...flag, cityFlag: true });
        setError({ ...error, city: "" });
      }
    }
  };

  const countries = useMemo(() => countryList().getData(), []);
  const states = indianStates.map((state) => ({ value: state, label: state }));

  /*
    Stores Country
   */
  const saveCountry = (value) => {
    setSelCountry(value);
    province.current.value = value;
    setInput({ ...input, country: value.label });
    if (value.label === "India") {
      setProv(true);
    } else {
      setProv(false);
    }
  };

  /*
    Stores Province
   */
  const saveProvince = (value) => {
    setSelProvince(value);
    setInput({ ...input, province: value.label });
  };
  const setAddr = () => {
    setInput({
      ...input,
      address1: address1.current.value,
      address2: address2.current.value,
    });
  };
  const [error, setError] = useState({
    firstName: "",
    lastName: "",
    email: "",
    zip: "",
    city: "",
    country: "",
  });

  /*
  Clears Input fields
 */
  const clear = () => {
    firstName.current.value = "";
    lastName.current.value = "";
    phone.current.value = "";
    address1.current.value = "";
    address2.current.value = "";
    city.current.value = "";
    zip.current.value = "";
  };

  /*
  Navigate to profile
 */
  const profile = () => {
    window.location.href = "/profile";
    setVis(true);
  };

  /*
    Navigate to compare
   */
  const compare = () => {
    window.location.href = "/compare";

  };

  const showAddress = () => {
    setVis(false);
  };


  const showDetails = () => {
    showAdd(false);
  };

  /*
   Navigate to home
  */
  const NavigateToHome = () => {
    window.location.href = "/";
  };
  const addressList = details.addressDTO;

  const NavigateToWishlist = () => {
    window.location.href = "/wishlist";
  }

  const NavigateToCart = () => {
    window.location.href = "/cart";
  }

  /*
   Naviagte to Logout
  */
  const navLogOut = () => {
    window.location.href = "/login";
  };

  /*
    Logout
  */
  const logout = () => {
    sessionStorage.setItem("status", false);
    sessionStorage.setItem("email", null);
    console.log(details.customerId);
    Swal.fire({
      text: "Logged Out",
      timer: 1000,
      icon: "info",
      showConfirmButton: false,
    });
    clearLike();
    setTimeout(navLogOut, 1000);

  };

   /*
    Loads like buuton  based on customers wishlist
   */
    const clearLike = () => {
          const url =
          `http://localhost:8080/nveda/clearFlag`
        axios
          .get(url)
          .catch((error) => console.log(error));
      
    };

  return (
    <div>
      <div style={{ background: "#f3f3f3", height: "4rem" }}>
        <Breadcrumb style={{ padding: "1rem" }}>
          <Breadcrumb.Item onClick={NavigateToHome}>Home</Breadcrumb.Item>
          <Breadcrumb.Item href="#">Profile</Breadcrumb.Item>
        </Breadcrumb>
      </div>
      <Container style={{ marginLeft: "1rem" }}>
        <Row>
          <Col xs={3}>
            <br />
            <h2 style={{ textAlign: "center" }}>My Account</h2>
            <br />
            <div class="features" style={{ textDecoration: "none" }}>
              <li style={{ listStyle: "none" }}>
                <a onClick={profile}>Dashboard</a>
              </li>
              <li style={{ listStyle: "none" }}>
                <a onClick={update}>Addresses</a>
              </li>
              <li style={{ listStyle: "none" }}>
                <a onClick={NavigateToWishlist}>Wishlist</a>
              </li>
              <li style={{ listStyle: "none" }}>
                <a onClick={compare}>Compare</a>
              </li>
              <li style={{ listStyle: "none" }}>
                <a onClick={NavigateToCart}>Cart</a>
              </li>
              <li style={{ listStyle: "none" }}>
                <a onClick={logout}>Log out</a>
              </li>
            </div>
          </Col>
          <Col xs={1}>
            <p className="vlp"></p>
          </Col>
          <Col xs={8}>
            {vis ? (
              <div style={{ marginLeft: "2rem" }}>
                {add ? (
                  <div>
                    <br />
                    <p>
                      Hello {details.firstName}
                      <a
                        onClick={logout}
                        class="logoutLink"
                        style={{ marginLeft: "0.5rem" }}
                      >
                        Logout
                      </a>
                    </p>
                    <h3>Order History</h3>
                    <br />
                    {orderVis ? <>{orderItem?.map((items) => {
                      return <OrderCard obj={items} />;
                    })}</> : <div
                      style={{
                        backgroundColor: "#eaf7e6",
                        height: "3rem",
                        color: "#436b37",
                        padding: "0.5rem",
                      }}
                    >
                      You haven't placed any orders yet.
                    </div>}

                    <br />
                    <h3>Account Details</h3>
                    <br />
                    <span className="d-flex">
                      <p style={{ marginRight: "8rem", marginLeft: "1rem" }}>
                        Name :
                      </p>
                      <p>{details.firstName}</p>
                    </span>
                    <hr />
                    <span className="d-flex">
                      <p style={{ marginRight: "8rem", marginLeft: "1rem" }}>
                        Email :
                      </p>
                      <p>{details.email}</p>
                    </span>
                    <hr />
                    <br />
                    <button
                      class="btnTagBig"
                      style={{
                        position: "relative",
                        left: "1rem",
                        marginBottom: "1rem",
                      }}
                      onClick={showDetails}
                    >
                      View Addresses
                    </button>
                  </div>
                ) : (
                  <>
                    <br />
                    <h3>Your Addresss</h3>
                    <br />
                    <button
                      class="btnTagBig"
                      style={{
                        position: "relative",
                        left: "1rem",
                        marginBottom: "1rem",
                      }}
                      onClick={showAddress}
                    >
                      Add new Address
                    </button>
                    <br />
                    <br />
                    {addressList.map((items) => {
                      return <Edit obj={items} />;
                    })}
                    <br />
                  </>
                )}
              </div>
            ) : (
              <div style={{ marginLeft: "2rem" }}>
                <br />
                <h3>Add Address</h3>
                <br />
                <form>
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      First name:
                    </label>
                    <input
                      placeholder=" First Name"
                      class="updateInput"
                      style={{ marginLeft: "5rem" }}
                      ref={firstName}
                      onChange={ValidFirstName.bind(this, firstName)}
                    ></input>
                  </span>
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  >
                    {error.firstName}
                  </p>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      Last name:
                    </label>
                    <input
                      placeholder=" Last Name"
                      class="updateInput"
                      style={{ marginLeft: "5rem" }}
                      ref={lastName}
                      onChange={ValidLastName.bind(this, lastName)}
                    ></input>
                  </span>
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  >
                    {error.lastName}
                  </p>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      Address1:
                    </label>
                    <input
                      placeholder="Address 1"
                      class="updateInput"
                      style={{ marginLeft: "6rem" }}
                      ref={address1}
                      onChange={setAddr}
                    ></input>
                  </span>
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  ></p>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      Address2:
                    </label>
                    <input
                      placeholder=" Address 2"
                      class="updateInput"
                      style={{ marginLeft: "5.7rem" }}
                      ref={address2}
                      onChange={setAddr}
                    ></input>
                  </span>
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  ></p>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      City:
                    </label>
                    <input
                      placeholder="City"
                      class="updateInput"
                      style={{ marginLeft: "8.5rem" }}
                      ref={city}
                      onChange={ValidCity.bind(this, city)}
                    ></input>
                  </span>
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  >
                    {error.city}
                  </p>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  <span className="d-flex">
                    <label style={{ marginRight: "5rem", marginLeft: "2rem" }}>
                      Country/region:
                    </label>
                    <Select
                      options={countries}
                      ref={province}
                      value={selCountry}
                      onChange={saveCountry}
                    />
                  </span>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  {prov && (
                    <>
                      <span className="d-flex">
                        <label
                          style={{ marginRight: "8rem", marginLeft: "2rem" }}
                        >
                          Province:
                        </label>
                        <Select
                          options={states}
                          value={selProvince}
                          onChange={saveProvince}
                        />
                      </span>
                      <hr style={{ position: "relative", top: "0.3rem" }} />
                    </>
                  )}
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      Portal/ZIP code:
                    </label>
                    <input
                      placeholder="Portal/ZIP code"
                      class="updateInput"
                      style={{ marginLeft: "3.2rem" }}
                      ref={zip}
                      onChange={ValidZip.bind(this, zip)}
                    ></input>
                  </span>
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  >
                    {error.zip}
                  </p>
                  <hr style={{ position: "relative", top: "0.3rem" }} />
                  <span className="d-flex">
                    <label style={{ marginRight: "2rem", marginLeft: "2rem" }}>
                      Phone:
                    </label>
                    <input
                      placeholder="Phone number"
                      class="updateInput"
                      style={{ marginLeft: "7rem" }}
                      ref={phone}
                      onChange={ValidPhone.bind(this, phone)}
                    ></input>
                  </span>{" "}
                  <p
                    style={{
                      position: "relative",
                      left: "25%",
                      top: "0.2rem",
                      height: "1rem",
                      color: "red",
                      width: "60%",
                      margin: "0rem",
                    }}
                  >
                    {error.phone}
                  </p>
                </form>
                <br />
                <br />
                <button
                  class="btnTagBig"
                  style={{
                    position: "relative",
                    left: "15rem",
                    marginBottom: "1rem",
                  }}
                  onClick={handleAddress}
                >
                  Add Address
                </button>
                <br />
              </div>
            )}
          </Col>
        </Row>
      </Container>
    </div>
  );
};
