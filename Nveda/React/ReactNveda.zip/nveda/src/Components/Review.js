import React, { useEffect, useRef, useState } from "react";


import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import ReactStars from 'react-stars'
import "../assets/Css/Review.css";
import Swal from "sweetalert2";
import axios from "axios";

export const Review = (props) => {
  console.log("prop", props)
  const [review, setReview] = useState(false);
  const [rating, setRating] = useState(5);
  const [currentUser, setCurrentUser] = useState("");
  const title = useRef(null);
  const comment = useRef(null);
  const status = sessionStorage.getItem("status");
  const logIn = sessionStorage.getItem("email");
  const ratingChanged = (newRating) => {
    setRating(newRating);
  };
  const toggleReview = () => {
    if (status == "true") {
      setReview(!review);
    } else {
      window.location.href = "/login";
    }
  };

  const cancelReview = () => {
    setReview(false);
  };

  const clearInput = () => {
    title.current.value="";
    comment.current.value="";
    setRating(0);
  }

  useEffect(() => {
    const profileUrl = `http://localhost:8080/nveda/profile/` + logIn;
    axios
      .get(profileUrl)
      .then((profile) => {
        if (profile.status === 200) {
          setCurrentUser(profile.data);

        }
      })
      .catch((error) => console.log(error));


  }, [])
const isValidReview=()=>{
  if(rating>0 && title.current.value!=null && comment.current.value ){
    addReview();
  }
}
  const addReview = () => {
    let url = `http://localhost:8080/nveda/addReview`;
    const reqBody = {
      rating: rating,
      title: title.current.value,
      review: comment.current.value,
      productDTO: props.product,
      customerRegistrationDTO: currentUser,
    }
    axios
      .post(url, reqBody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          Swal.fire({
            title: "Comment added",
            icon: "success",
            timer: 800,
            showConfirmButton: false,
          });
          clearInput();
        }
      })
      .catch((error) => {
        console.log(error);
      });

  }
  return (
    <div>
      <br />
      <h4 className="text-center">Customer Reviews</h4>
      {review ? (
        <button className="ReviewBtn" onClick={toggleReview}>
          Cancel review
        </button>
      ) : (

        <button className="ReviewBtn" onClick={toggleReview}>
          Write a review
        </button>
      )}
      {review && (
        <div>
          <h5 className="text-center">
            <strong>Write a Review</strong>
          </h5>
          <p className="text-center" style={{ fontWeight: "700" }}>Rating</p>
          <ReactStars
            count={5}
            onChange={ratingChanged}
            size={30}
            isHalf={true}
            quiet={false}
            emptyIcon={<i className="far fa-star"></i>}
            halfIcon={<i className="fa fa-star-half-alt"></i>}
            fullIcon={<i className="fa fa-star"></i>}
            activeColor="#ffd700"
            className="star-rating"
          />
          <p className="text-center" style={{ fontWeight: "700" }}>Review Title</p>
          <input type="text" ref={title} class="updateInput textBox" style={{ width: "33rem", borderColor: "grey", marginBottom: "1rem" }} placeholder="Review Titie" />

          <p className="text-center" style={{ fontWeight: "700" }}>Review</p>
          <textarea
            ref={comment}
            type="text"
            className="textBox"
            rows="4"
            cols="70"
            name="comment"
            placeholder="Order special instructions"
          ></textarea>
          <div className="d-flex"><button className="ReviewBtn" onClick={cancelReview} style={{ marginLeft: "-7rem", backgroundColor: "black" }} >
            Cancel Review
          </button><button className="ReviewBtn" onClick={isValidReview}>
              Submit Review
            </button></div>
        </div>
      )}
    </div>
  );
};
