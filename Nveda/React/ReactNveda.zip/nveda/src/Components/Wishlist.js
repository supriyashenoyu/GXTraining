import React from 'react'
import { Breadcrumb } from 'react-bootstrap'
import { useEffect, useState } from 'react'
import axios from "axios";
import { WishlistCard } from './ReusableComponents/WishlistCard';
export const Wishlist = () => {
  const logIn = sessionStorage.getItem("email");
  const [currentUser, setCurrentUser] = useState({});
  const [wishlist, setWishlist] = useState([]);



  /*
     Loads current user
   */
  useEffect(() => {
    const url = `http://localhost:8080/nveda/profile/` + logIn;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
          setCurrentUser(resData.data);
        }
      })
      .catch((error) => console.log(error));
  }, []);

  /*
     Loads Wishlist items
   */
  const loadWishlistItems = () => {
    const url = `http://localhost:8080/nveda/getWishlist/` + currentUser.customerId;
    axios
      .get(url)
      .then((resData) => {
        if (resData.status === 200) {
          setWishlist(resData.data);

        }
      })
      .catch((error) => console.log(error));
  }

  /*
    Loads Wishlist on rendering
  */
  useEffect(() => {
    loadWishlistItems();
  }, [currentUser]);
  return (
    <div>  <div style={{ background: "#f3f3f3", height: "4rem" }}>
      <Breadcrumb style={{ padding: "1.5rem" }}>
        <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
        <Breadcrumb.Item active>Your Wishlist</Breadcrumb.Item>
      </Breadcrumb>
    </div>
      <br /><br />
      <h3 style={{ marginLeft: "3rem" }}>My Wishlist</h3>
      <br />
      <div className='d-flex' style={{ margin: "0rem 10rem" }}><h6 style={{ margin: "0rem 10rem 0rem 20rem" }}>Product</h6><h6 style={{ marginLeft: "17rem" }}>Price</h6></div>
      <br />{wishlist.map((items) => {
        return (
          <WishlistCard obj={items} load={loadWishlistItems} />);
      })

      }
    </div>
  )
}
