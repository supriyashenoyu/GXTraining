
import { useState } from 'react';

import './App.css';




import { Login } from './Components/Login';
import { Profile } from './Components/Profile/Profile';
import { Register } from './Components/Register';
import {BrowserRouter, Route, Routes ,} from "react-router-dom";
import { Shop } from './Components/Shops';
import { Home } from './Components/Home';
import {Header} from './Components/ReusableComponents/Header';
import { Product } from './Components/Product';
import { Footer } from './Components/ReusableComponents/Footer';
import { Wishlist } from './Components/Wishlist';
import { Filter } from './Components/ReusableComponents/Filter';
import { Review } from './Components/Review';
import { Search } from './Components/Search';
import { Cart } from './Components/Cart/Cart';
import { Compare } from './Components/Compare';





function App() {
  const [logIn, setLogIn] = useState(localStorage.getItem('token'));
  const [loggedIn, setLoggedIn] = useState(localStorage.getItem('token'));
 // setLoggedIn(false)
  
  return (
 
   
    <div>
    <BrowserRouter>
    <Header/> 
      <Routes>
      <Route path='/register' element={<Register/>}/>
        <Route path='/login' element={<Login />}/>
        <Route exact path="/profile" element={<Profile/>}/>
        <Route path='/' element={<Home/>}/>
        <Route exact path="/product"  element={<Product />} />
        <Route path='/shop' element={<Shop/>}/>
        <Route path='/search' element={<Search/>}/>
        <Route exact path='/category/:name'  element={<Filter/>}/>
        <Route path='/wishlist' element={<Wishlist/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='/rating' element={<Review/>}/>
        <Route path='/compare' element={<Compare/>}/>

      </Routes>
    </BrowserRouter>
    <Footer/>
    </div>
 
  );
}

export default App;
