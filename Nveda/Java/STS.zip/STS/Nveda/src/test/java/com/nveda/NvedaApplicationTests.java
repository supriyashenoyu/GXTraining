package com.nveda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NvedaApplicationTests {

	@Test
	void contextLoads() {
	}

}
