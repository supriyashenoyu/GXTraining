package com.nveda.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.nveda.dto.AddressDTO;
@SpringBootTest
public class AddressServiceTest {
	@Autowired
	AddressService addressService;

	@Test
	@Order(1)
	void testAddAddressPositive() {
		AddressDTO addressDTO=AddressDTO.build(1,"supp@gmail.com","supriya","shenoy","9387368832","Udyavara","udupi","karnataka",574118,"udpi","India");
		String message=addressService.addAddress(addressDTO);
		assertEquals(message,"added");
		
	}
	
	@Test
	@Order(2)
	void testAddAddressNegative() {
		AddressDTO addressDTO=AddressDTO.build(1,"supp@gcil.gno","supriya","shenoy","9387368832","Udyavara","udupi","karnataka",574118,"udpi","India");
		String message=addressService.addAddress(addressDTO);
		assertEquals(message,"added");
		
	}


}
