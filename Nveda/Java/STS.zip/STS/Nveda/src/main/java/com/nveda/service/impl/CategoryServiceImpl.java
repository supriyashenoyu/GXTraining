package com.nveda.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nveda.controller.ProductController;
import com.nveda.dto.CategoryDTO;
import com.nveda.entities.Category;
import com.nveda.repo.CategoryRepository;
import com.nveda.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {
	@Autowired
	CategoryRepository categoryRepository;
	private static Logger logger = LogManager.getLogger(ProductController.class);

	/**
	 * getAllCategory
	 *
	 * @return List<CategoryDTO>
	 */
	public List<CategoryDTO> getAllCategory() {
		logger.debug("CategoryServiceImpl :: getAllCategory -- begin");
		List<CategoryDTO> categoryDTO = new ArrayList<>();
		List<Category> Categories = categoryRepository.findAll();
		for (Category category : Categories) {
			categoryDTO.add(CategoryDTO.build(category.getCategoryId(),category.getCategoryName(), category.getCategoryImgSrc()));
		}
		logger.debug("CategoryServiceImpl :: getAllCategory -- end");
		return categoryDTO;
	}

}
