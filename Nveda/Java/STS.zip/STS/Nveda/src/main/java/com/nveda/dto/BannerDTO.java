package com.nveda.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class BannerDTO {

	private int bannerId;
	private String bannerImgSrc;
	private String description;
	private String bannerTitle;

}
