package com.nveda.service;


import com.nveda.dto.CustomerRegistrationDTO;

public interface CustomerService {
	String register(CustomerRegistrationDTO customerDTO);
	String verify(String email, String password);
	CustomerRegistrationDTO getCustomerByEmail(String email);
	
	
}
