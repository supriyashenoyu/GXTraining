package com.nveda.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nveda.dto.AddressDTO;
import com.nveda.dto.CustomerLoginDTO;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.service.AddressService;
import com.nveda.service.CustomerService;

@RestController
@RequestMapping("/nveda")
@CrossOrigin(origins = "*")

public class CustomerController {
	@Autowired()
	CustomerService customerService;
	@Autowired()
	AddressService addressService;
	ResponseEntity<String> response = null;
	String errorMessage = "error";

	private static Logger logger = LogManager.getLogger(ProductController.class);

	/**
	 * register->regsiters customer by storing his details
	 * 
	 * @param CustomerRegistrationDTO customerDTO
	 * 
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody CustomerRegistrationDTO customerDTO) {
		logger.debug("CustomerController :: register -- begin");
		String message = "success";
		try {
			message = customerService.register(customerDTO);
			if (message.equals("Email already Exists")) {
				response = new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);
			} else {
				response = new ResponseEntity<String>(message, HttpStatus.OK);
			}
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error during registration of customer");
		}
		logger.debug("CustomerController :: register -- end");
		return response;
	}

	/**
	 * login->Customer logs in using credentials
	 * 
	 * @param customerLoginDTO customerLoginDTO
	 * 
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody CustomerLoginDTO customerLoginDTO) {
		logger.debug("CustomerController :: login -- begin");
		String message = "success";
		String email = customerLoginDTO.getEmail();
		String password = customerLoginDTO.getPassword();
		try {
			message = customerService.verify(email, password);
			if (message != "success") {
				response = new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);
			} else {
				response = new ResponseEntity<String>(message, HttpStatus.OK);
			}
		} catch (Exception ex) {
			response = new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);
			logger.error("Error during customer log in");
		}
		logger.debug("CustomerController :: login -- end");
		return response;

	}

	/**
	 * getCustomerByEmail->fetches customer details using his email
	 * 
	 * @param String email
	 * 
	 * @return ResponseEntity<CustomerProfileDTO>
	 * 
	 */
	@GetMapping("/profile/{email}")
	public ResponseEntity<CustomerRegistrationDTO> getCustomerByEmail(@PathVariable("email") String email) {
		logger.debug("CustomerController :: getCustomerByEmail -- begin");
		ResponseEntity<CustomerRegistrationDTO> responseEntity = null;
		try {
			responseEntity = new ResponseEntity<CustomerRegistrationDTO>(customerService.getCustomerByEmail(email),
					HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<CustomerRegistrationDTO>(customerService.getCustomerByEmail(email),
					HttpStatus.NOT_FOUND);
			logger.error("Error while fetching customer by email");
		}
		logger.debug("CustomerController :: getCustomerByEmail -- end");
		return responseEntity;
	}

	/**
	 * updateAddress->updates the customer addresss
	 * 
	 * @param AddressDTO addressDTO
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/update")
	public ResponseEntity<String> updateAddress(@RequestBody AddressDTO addressDTO) {
		logger.debug("CustomerController :: updateAddress -- begin");
		try {
			response = new ResponseEntity<String>(addressService.updateAddress(addressDTO), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error while updating the address");
		}
		logger.debug("CustomerController :: updateAddress -- begin");
		return response;

	}

	/**
	 * deleteAddress->deletes the address using address id
	 * 
	 * @param integer id
	 * @return ResponseEntity<String>
	 */
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteAddress(@PathVariable("id") int id) {
		logger.debug("CustomerController :: deleteAddress -- begin");
		try {
			response = new ResponseEntity<String>(addressService.deleteAddress(id), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error while deleting the address");
		}
		logger.debug("CustomerController :: deleteAddress -- end");
		return response;
	}

	/**
	 * addAddress->adds new address to the customer
	 * 
	 * @param AddressDTO addressDTO
	 * 
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/add")
	public ResponseEntity<String> addAddress(@RequestBody AddressDTO addressDTO) {
		logger.debug("CustomerController :: addAddress -- begin");
		try {
			response = new ResponseEntity<String>(addressService.addAddress(addressDTO), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error while adding the address");
		}
		logger.debug("CustomerController :: addAddress -- end");
		return response;

	}

	/**
	 * getStates->gets list of all states
	 * 
	 * 
	 * @return ResponseEntity<List<String>>
	 */
	@GetMapping("/states")
	public ResponseEntity<List<String>> getStates() {
		logger.debug("CustomerController :: getStates -- begin");
		ResponseEntity<List<String>> responseEntity;
		try {
			responseEntity = new ResponseEntity<List<String>>(addressService.getStates(), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<List<String>>(addressService.getStates(), HttpStatus.NOT_FOUND);
			logger.error("Error while fetching the states");
		}
		logger.debug("CustomerController :: getStates -- end");
		return responseEntity;
	}

}
