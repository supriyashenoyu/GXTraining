package com.nveda.entities;

import java.sql.Date;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class Review {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int reviewId;
	private Double rating;
	private String title;
	private String review;
	private Date reviewDate;
	@ManyToOne
	@JoinColumn(name="productId")
	Product product;
	@ManyToOne
	@JoinColumn(name="customerId")
	CustomerRegistration customerRegistration;
	

}
