package com.nveda.service;

import java.util.List;

import com.nveda.dto.AddressDTO;



public interface AddressService {
	List<String> getStates();
	String addAddress(AddressDTO addressDTO);
	String deleteAddress(int id);
	String updateAddress(AddressDTO addressDTO);

}
