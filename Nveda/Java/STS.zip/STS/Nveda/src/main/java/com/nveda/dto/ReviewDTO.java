package com.nveda.dto;


import java.sql.Date;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName="build")
@NoArgsConstructor
public class ReviewDTO {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int reviewId;
	private Double rating;
	private String title;
	private String review;
	private Date reviewDate;
	ProductDTO productDTO;
	CustomerRegistrationDTO customerRegistrationDTO;

}
