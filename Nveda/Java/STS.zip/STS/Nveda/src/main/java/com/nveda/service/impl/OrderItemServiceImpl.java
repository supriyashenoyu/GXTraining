package com.nveda.service.impl;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nveda.controller.ProductController;
import com.nveda.dto.AddressDTO;
import com.nveda.dto.CategoryDTO;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.dto.OrderItemDTO;
import com.nveda.dto.ProductDTO;
import com.nveda.dto.ProductImagesDTO;
import com.nveda.dto.ReviewDTO;
import com.nveda.dto.UpdateCartDTO;
import com.nveda.entities.Address;
import com.nveda.entities.Category;
import com.nveda.entities.CustomerRegistration;
import com.nveda.entities.OrderItem;
import com.nveda.entities.Product;
import com.nveda.entities.ProductImages;
import com.nveda.entities.Review;
import com.nveda.repo.CartItemRepository;
import com.nveda.repo.OrderItemRepository;
import com.nveda.repo.ProductsRepository;
import com.nveda.service.OrderItemService;

@Service
public class OrderItemServiceImpl implements OrderItemService {
	@Autowired
	OrderItemRepository orderItemRepository;
	@Autowired
	ProductsRepository productsRepository;
	@Autowired
	CartItemRepository 	cartItemRepository;
	
	private static Logger logger = LogManager.getLogger(ProductController.class);

	/**
	 * toProductImages
	 * 
	 * @param List<ProductImagesDTO> productImagesDTO
	 * 
	 * @return List<ProductImages>
	 */
	public List<ProductImages> toProductImages(List<ProductImagesDTO> productImagesDTO) {
		logger.debug("OrderItemServiceImpl :: toProductImages -- begin");
		List<ProductImages> productImages = new ArrayList<>();
		for (ProductImagesDTO productImage : productImagesDTO) {
			productImages.add(ProductImages.build(productImage.getImageId(), null, productImage.getImgSrc(),productImage.getThumbnail() ,null));
		}
		logger.debug("OrderItemServiceImpl :: toProductImages -- end");
		return productImages;
	}

	/**
	 * toCategory
	 * 
	 * @param CategoryDTO categoryDTO
	 * 
	 * @return Category
	 */
	public Category toCategory(CategoryDTO categoryDTO) {
		logger.debug("OrderItemServiceImpl :: toCategory -- begin");
		logger.debug("OrderItemServiceImpl :: toCategory -- end");
		return Category.build(categoryDTO.getCategoryId(), categoryDTO.getCategoryName(),
				categoryDTO.getCategoryImgSrc(), null);

	}

	/**
	 * toProductEntity
	 * 
	 * @param ProductDTO productDTO
	 * 
	 * @return Product
	 */
	public Product toProduct(ProductDTO productDTO) {
		logger.debug("OrderItemServiceImpl :: toProduct -- begin");
		Category category = toCategory(productDTO.getCategoryDTO());
		List<ProductImages> productImages = toProductImages(productDTO.getProductImagesDTOs());
		List<Review> reviews=toReviews(productDTO.getReviewDTOs());
		Product product = Product.build(productDTO.getProductId(), productDTO.getProductName(),
				productDTO.getProductDesc(), productDTO.getProductPrice(), productDTO.getStock(), category,
				productImages, null, productDTO.getWishlistflag(),productDTO.getRating(), null,reviews,null);
		logger.debug("OrderItemServiceImpl :: toProduct -- end");
		return product;
	}

	/**
	 * toReviewDTO
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public ReviewDTO toReviewDTO(Review review) {
		logger.debug("OrderItemServiceImpl :: toReviewDTO -- begin");
		logger.debug("OrderItemServiceImpl :: toReviewDTO -- end");
		return ReviewDTO.build(review.getReviewId(),review.getRating(),review.getTitle(),review.getReview(),review.getReviewDate(),null ,null);
	}

	/**
	 * toReview
	 * 
	 * @param ReviewDTO reviewDTO 
	 * 
	 * @return Review
	 */
	public Review toReview(ReviewDTO reviewDTO) {
		logger.debug("OrderItemServiceImpl :: toReview -- begin");
		   LocalDateTime localDateTime = LocalDateTime.now();
		    Date date = Date.valueOf(localDateTime.toLocalDate());
		    logger.debug("OrderItemServiceImpl :: toReview -- end");
		    return Review.build(reviewDTO.getReviewId(),reviewDTO.getRating(),reviewDTO.getTitle(),reviewDTO.getReview(),date,null,null);
	}

	/**
	 * toReviewDTOs
	 * 
	 * @param List<Review> reviews
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<ReviewDTO> toReviewDTOs(List<Review> reviews) {
		logger.debug("OrderItemServiceImpl :: toReviewDTOs -- begin");
		List<ReviewDTO> reviewDTOs = reviews.stream().map(item->toReviewDTO(item)).collect(Collectors.toList());
		logger.debug("OrderItemServiceImpl :: toReviewDTOs -- end");
		return reviewDTOs;
	}

	/**
	 * toReviews
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<Review> toReviews(List<ReviewDTO> reviewDTOs) {
		logger.debug("OrderItemServiceImpl :: toReviews -- begin");
		List<Review> reviews = reviewDTOs.stream().map(item->toReview(item)).collect(Collectors.toList());
		logger.debug("OrderItemServiceImpl :: toReviews -- end");
		return reviews;
	}

	/**
	 * toProductDTO
	 * 
	 * @param Product product
	 * 
	 * @return Product
	 */
	public ProductDTO toProductDTO(Product product) {
		logger.debug("OrderItemServiceImpl :: toProductDTO -- begin");
		CategoryDTO categoryDTO = toCategoryDTO(product.getCategory());
		List<ProductImagesDTO> productImagesDTOs = toProductImagesDTOs(product.getProductImages());
		List<ReviewDTO> reviewDTOs=toReviewDTOs(product.getReviews());
		ProductDTO productDTO = ProductDTO.build(product.getProductId(), product.getProductName(),
				product.getProductDesc(), product.getProductPrice(), product.getStock(), categoryDTO, productImagesDTOs,
				product.getWishlistflag(),product.getRating(),reviewDTOs);
		logger.debug("OrderItemServiceImpl :: toProductDTO -- end");
		return productDTO;
	}

	/**
	 * toProducts
	 * 
	 *
	 * @param List<ProductDTO> productsDTO
	 * 
	 * @return List<Product>
	 */
	public List<Product> toProducts(List<ProductDTO> productsDTOs) {
		logger.debug("OrderItemServiceImpl :: toProducts -- begin");
		List<Product> product = productsDTOs.stream().map(item -> toProduct(item)).collect(Collectors.toList());
		logger.debug("OrderItemServiceImpl :: toProducts -- end");
		return product;
	}

	/**
	 * toAdresses
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * 
	 * @return List<Address>
	 */
	public List<Address> toAddresses(List<AddressDTO> addressDTOs) {
		logger.debug("OrderItemServiceImpl :: toAddresses -- begin");
		List<Address> addresses = new ArrayList<>();
		for (AddressDTO addressDTO : addressDTOs) {
			Address address = Address.build(addressDTO.getAddressId(), null, addressDTO.getFirstName(),
					addressDTO.getLastName(), addressDTO.getPhone(), addressDTO.getAddress1(), addressDTO.getAddress2(),
					addressDTO.getZip(), addressDTO.getCity(), addressDTO.getCountry(), null);
			addresses.add(address);
		}
		logger.debug("OrderItemServiceImpl :: toAddresses -- end");
		return addresses;
	}

	/**
	 * toCustomerRegistration
	 * 
	 *
	 * @param CustomerRegistrationDTO customerRegistrationDTO
	 * 
	 * @return CustomerRegistration
	 */
	public CustomerRegistration toCustomerRegistration(CustomerRegistrationDTO customerRegistrationDTO) {
		logger.debug("OrderItemServiceImpl :: toCustomerRegistration -- begin");
		List<Address> addresses = toAddresses(customerRegistrationDTO.getAddressDTO());
		CustomerRegistration customerRegistration = CustomerRegistration.build(customerRegistrationDTO.getCustomerId(),
				customerRegistrationDTO.getFirstName(), customerRegistrationDTO.getLastName(),
				customerRegistrationDTO.getEmail(), null, addresses, null,null,null,null);
		logger.debug("OrderItemServiceImpl :: toCustomerRegistration -- end");
		return customerRegistration;

	}

	/**
	 * toProductImagesDTOs
	 * 
	 *
	 * @param List<ProductImages> productImages
	 * 
	 * @return List<ProductImagesDTO>
	 */
	public List<ProductImagesDTO> toProductImagesDTOs(List<ProductImages> productImages) {
		logger.debug("OrderItemServiceImpl :: toProductImagesDTOs -- begin");
		List<ProductImagesDTO> productImagesDTOs = new ArrayList<>();
		for (ProductImages productImage : productImages) {
			productImagesDTOs.add(ProductImagesDTO.build(productImage.getImageId(), productImage.getImgSrc(), productImage.getThumbnail()));
		}
		logger.debug("OrderItemServiceImpl :: toProductImagesDTOs -- end");
		return productImagesDTOs;
	}

	/**
	 * toAddressDTOs
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * 
	 * @return List<Address>
	 */
	public List<AddressDTO> toAddressDTOs(List<Address> addresses) {
		logger.debug("OrderItemServiceImpl :: toAddressDTOs -- begin");
		List<AddressDTO> addressDTOs = new ArrayList<>();
		for (Address address : addresses) {
			AddressDTO addressDTO = AddressDTO.build(address.getAddressId(), null, address.getFirstName(),
					address.getLastName(), address.getPhone(), address.getAddress1(), address.getAddress2(),
					address.getCity(), address.getZip(), address.getCountry(), null);
			addressDTOs.add(addressDTO);
		}
		logger.debug("OrderItemServiceImpl :: toAddressDTOs -- end");
		return addressDTOs;
	}

	/**
	 * toCategoryDTO
	 * 
	 *
	 * @param Category category
	 * 
	 * @return CategoryDTO
	 */
	public CategoryDTO toCategoryDTO(Category category) {
		logger.debug("OrderItemServiceImpl :: toCategoryDTO -- begin");
		logger.debug("OrderItemServiceImpl :: toCategoryDTO -- end");
		return CategoryDTO.build(category.getCategoryId(), category.getCategoryName(), category.getCategoryImgSrc());

	}

	/**
	 * toCustomerRegistrationDTO
	 * 
	 *
	 * @param CustomerRegistration customerRegistration
	 * 
	 * @return CustomerRegistrationDTO
	 */
	public CustomerRegistrationDTO toCustomerRegistrationDTO(CustomerRegistration customerRegistration) {
		logger.debug("OrderItemServiceImpl :: toCustomerRegistrationDTO -- begin");
		List<AddressDTO> addressesDTOs = toAddressDTOs(customerRegistration.getAddress());
		CustomerRegistrationDTO customerRegistrationDTO = CustomerRegistrationDTO.build(
				customerRegistration.getCustomerId(), customerRegistration.getFirstName(),
				customerRegistration.getLastName(), customerRegistration.getEmail(), null, addressesDTOs, null);
		logger.debug("OrderItemServiceImpl :: toCustomerRegistrationDTO -- end");
		return customerRegistrationDTO;

	}

	/**
	 * toProductDTos
	 * 
	 *
	 * @param List<Product> products
	 * 
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> toProductDTOs(List<Product> products) {
		logger.debug("OrderItemServiceImpl :: toProductDTOs -- begin");
		List<ProductDTO> productDispalyDTOs = new ArrayList<>();
		for (Product product : products) {
			productDispalyDTOs.add(toProductDTO(product));
		}
		logger.debug("OrderItemServiceImpl :: toProductDTOs -- end");
		return productDispalyDTOs;
	}



	/**
	 * toOrderDTO
	 * 
	 * @param OrderItem
	 * 
	 * @return OrderItemDTO
	 */
	public OrderItemDTO toOrderDTO(OrderItem orderItem) {
		logger.debug("OrderItemServiceImpl :: toOrderDTO -- begin");
		OrderItemDTO orderItemDTO = OrderItemDTO.build(0, 
				toCustomerRegistrationDTO(orderItem.getCustomerRegistration()),toProductDTO(orderItem.getProduct()), orderItem.getQuantity(), orderItem.getTotalAmount());
		logger.debug("OrderItemServiceImpl :: toOrderDTO -- end");
		return orderItemDTO;
	}
	
	/**
	 * toOrder
	 * 
	 * @param CartItemDTO cartDTO
	 * 
	 * @return CartItem
	 */
	public OrderItem toOrder(OrderItemDTO orderItemDTO) {
		logger.debug("OrderItemServiceImpl :: toOrder -- begin");
		OrderItem orderItem = OrderItem.build(orderItemDTO.getOrderId(), toProduct(orderItemDTO.getProductDTO()),
				toCustomerRegistration(orderItemDTO.getCustomerRegistrationDTO()), orderItemDTO.getQuantity(),
				orderItemDTO.getTotalAmount());
		logger.debug("OrderItemServiceImpl :: toOrder -- end");
		return orderItem;
	}



	/**
	 * addToOrder
	 * 
	 * @param orderItemDTO
	 * 
	 * @return String
	 */
	public String addToOrder(OrderItemDTO orderItemDTO) {
		logger.debug("OrderItemServiceImpl :: addToOrder -- begin");
		orderItemRepository.save(toOrder(orderItemDTO));
		productsRepository.updateProductQuantity(orderItemDTO.getProductDTO().getStock()-orderItemDTO.getQuantity(), orderItemDTO.getProductDTO().getProductId());
		cartItemRepository.deleteCartItem(orderItemDTO.getCustomerRegistrationDTO().getCustomerId(), orderItemDTO.getProductDTO().getProductId());
		logger.debug("OrderItemServiceImpl :: addToOrder -- end");
		return "Added to cart";
	}

	/**
	 * getOrder
	 * 
	 * @param Integer customerId
	 * 
	 * @return List<OrderItemDTO>
	 */
	public List<OrderItemDTO> getOrder(int customerId) {
		logger.debug("OrderItemServiceImpl :: getOrder -- begin");
		List<OrderItem> orderItems = orderItemRepository.findByCustomerId(customerId);
		List<OrderItemDTO> orderItemDTOs = new ArrayList<>();
		for (OrderItem orderItem : orderItems) {
			orderItemDTOs.add(toOrderDTO(orderItem));
		}
		logger.debug("OrderItemServiceImpl :: getOrder -- end");
		return orderItemDTOs;

	}

	/**
	 * updateCartQuantity
	 * 
	 * @param long customerId,Integer productId,Integer quantity
	 * 
	 * @return String
	 */
	public String updateCartQuantity(UpdateCartDTO updateCartDTO) {
		logger.debug("OrderItemServiceImpl :: updateCartQuantity -- begin");
		cartItemRepository.updateQuantity(updateCartDTO.getCustomerId(), updateCartDTO.getProductId(),
				updateCartDTO.getQuantity(), updateCartDTO.getTotalAmount());
		logger.debug("OrderItemServiceImpl :: updateCartQuantity -- end");
		return "cart Item updated";
	}

	/**
	 * deleteFromCart
	 * 
	 * @param long customerId,Integer productId
	 * 
	 * @return String
	 */
	public String deleteFromCart(int customerId, int productId) {
		logger.debug("OrderItemServiceImpl :: deleteFromCart -- begin");
		cartItemRepository.deleteCartItem(customerId, productId);
		logger.debug("OrderItemServiceImpl :: deleteFromCart -- end");
		return "deleted cart Item";
	}

	

}
