package com.nveda.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class CustomerProfileDTO {
	
			private String email;
			private String firstName;
			private String lastName;
			private String phone;
			private String address1;
			private String address2;
			private String province;
			private Integer zip;
			private String city;
			private String country;
	

}
