package com.nveda.service;

import java.util.List;

import com.nveda.dto.BannerDTO;
import com.nveda.dto.ProductDTO;


public interface ProductService {
	ProductDTO findProductByProductId(int productId);
	List<ProductDTO> getAllProducts();
	List<ProductDTO> getProductByCategory(int categoryId);
	int inStockProducts();
	int outOfStockProducts();
	String setCompare(int productId);
	String resetCompare(int productId);
	String countOfCompareItems();
	String clearCompare();
	Integer checkCompare(int productId);
	List<ProductDTO> getCompare();
	String updateRating(Double rating,int productId);
	List<BannerDTO> getBanner();
	String clearWishlistFlag();
	

}
