package com.nveda.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class CustomerRegistrationDTO {
		private long customerId;
		private String firstName;
		private String lastName;
		private String email;
		private String password;
		private List<AddressDTO> addressDTO;
		private List<WishlistDTO> wishlistDTO;
		
}
