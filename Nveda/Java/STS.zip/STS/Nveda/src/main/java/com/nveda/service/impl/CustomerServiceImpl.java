package com.nveda.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.nveda.controller.ProductController;
import com.nveda.dto.AddressDTO;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.entities.Address;
import com.nveda.entities.CustomerRegistration;
import com.nveda.repo.AddressRepository;
import com.nveda.repo.CustomerRepository;
import com.nveda.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	private static Logger logger = LogManager.getLogger(ProductController.class);

	/**
	 * toCustomerRegistration
	 * 
	 * @param customerRegistrationDTO
	 * @return CustomerRegistration
	 */
	public CustomerRegistration toCustomerRegistration(CustomerRegistrationDTO customerRegistrationDTO) {
		logger.debug("CustomerServiceImpl :: toCustomerRegistration -- begin");
		logger.debug("CustomerServiceImpl :: toCustomerRegistration -- end");
		return CustomerRegistration.build(customerRegistrationDTO.getCustomerId(),
				customerRegistrationDTO.getFirstName(), customerRegistrationDTO.getLastName(),
				customerRegistrationDTO.getEmail(), customerRegistrationDTO.getPassword(), null, null, null, null,
				null);
	}

	/**
	 * register
	 * 
	 * @param CustomerRegistrationDTO
	 * @return String
	 */

	public String register(CustomerRegistrationDTO customerRegistrationDTO) {
		logger.debug("CustomerServiceImpl :: register -- begin");
		String message = "Success";
		CustomerRegistration customerRegistration = toCustomerRegistration(customerRegistrationDTO);
		String encryptedPassword = bCryptPasswordEncoder.encode(customerRegistrationDTO.getPassword()); // Password Encryption
		customerRegistration.setPassword(encryptedPassword);
		try {
			customerRegistration = customerRepository.save(customerRegistration);
			List<AddressDTO> addressDTOs = customerRegistrationDTO.getAddressDTO();
			List<Address> addreses = new ArrayList<>();
			for (AddressDTO addressDTO : addressDTOs) {
				Address address = Address.build(addressDTO.getAddressId(), addressDTO.getFirstName(),
						addressDTO.getLastName(), addressDTO.getPhone(), addressDTO.getAddress1(),
						addressDTO.getAddress2(), addressDTO.getProvince(), addressDTO.getZip(), addressDTO.getCity(),
						addressDTO.getCountry(), customerRegistration);
				addreses.add(address);
			}
			addressRepository.saveAll(addreses);

		}

		catch (DataIntegrityViolationException ex) {
			message = "Email already Exists";
			logger.error("Email already Exists {}",ex);
		}
		logger.debug("CustomerServiceImpl :: register -- end");
		return message;

	}

	/**
	 * verify
	 * 
	 * @param String email,String password
	 * @return String
	 */

	public String verify(String email, String password) {
		logger.debug("CustomerServiceImpl :: verify -- begin");
		CustomerRegistration customerRegistration = null;
		String message = "success";
		try {
			customerRegistration = customerRepository.findByEmail(email);
			String passwordDB = customerRegistration.getPassword();
			Boolean valid = bCryptPasswordEncoder.matches(password, passwordDB);
			if (!valid)
				message = "Invalid Password";

		} catch (NullPointerException ex) {
			message = "Invalid Email";
			logger.error("Invalid Email");
		}
		logger.debug("CustomerServiceImpl :: verify -- end");
		return message;

	}

	/**
	 * getCustomerByEmail
	 *
	 * @param String email
	 * @return CustomerRegistrationDTO
	 */
	public CustomerRegistrationDTO getCustomerByEmail(String email) {
		logger.debug("CustomerServiceImpl :: getCustomerByEmail -- begin");
		CustomerRegistration customerRegistration = customerRepository.findByEmail(email);
		List<Address> addresses = customerRegistration.getAddress();
		List<AddressDTO> addressDTOs = new ArrayList<>();
		for (Address address : addresses) {
			addressDTOs.add(AddressDTO.build(address.getAddressId(), email, address.getFirstName(),
					address.getLastName(), address.getPhone(), address.getAddress1(), address.getAddress2(),
					address.getProvince(), address.getZip(), address.getCity(), address.getCountry()));
		}
		logger.debug("CustomerServiceImpl :: getCustomerByEmail -- end");
		return CustomerRegistrationDTO.build(customerRegistration.getCustomerId(), customerRegistration.getFirstName(),
				customerRegistration.getLastName(), email, null, addressDTOs, null);

	}

}
