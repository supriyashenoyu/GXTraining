package com.nveda.entities;

import java.util.List;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class CustomerRegistration {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long customerId;
	private String firstName;
	private String lastName;
	@Column(unique = true)
	private String email;
	private String password;
	@OneToMany(mappedBy="customerRegistration",cascade = CascadeType.ALL)
	private List<Address> address;
	@OneToMany(mappedBy="customerRegistration",cascade = CascadeType.ALL)
	private List<Wishlist> wishlist;
	@OneToMany(mappedBy="customerRegistration",cascade = CascadeType.ALL)
	private List<CartItem> carts;
	@OneToMany(mappedBy="customerRegistration",cascade = CascadeType.ALL)
	private List<Review> reviews;
	@OneToMany(mappedBy="customerRegistration",cascade = CascadeType.ALL)
	private List<OrderItem> order;
	

}
