package com.nveda.service.impl;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.nveda.controller.ProductController;
import com.nveda.dto.AddressDTO;
import com.nveda.dto.CategoryDTO;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.dto.BannerDTO;
import com.nveda.dto.ProductDTO;
import com.nveda.dto.ProductImagesDTO;
import com.nveda.dto.ReviewDTO;
import com.nveda.entities.Address;
import com.nveda.entities.Category;
import com.nveda.entities.CustomerRegistration;
import com.nveda.entities.Banner;
import com.nveda.entities.Product;
import com.nveda.entities.ProductImages;
import com.nveda.entities.Review;
import com.nveda.repo.AddressRepository;
import com.nveda.repo.CategoryRepository;
import com.nveda.repo.CustomerRepository;
import com.nveda.repo.BannerRepository;
import com.nveda.repo.ProductsRepository;
import com.nveda.repo.WishlistRepository;
import com.nveda.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	CategoryRepository categoryRepository;
	@Autowired
	ProductsRepository productsRepository;
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	WishlistRepository wishlistRepository;
	@Autowired 
	BannerRepository bannerRepository;
	private static Logger logger = LogManager.getLogger(ProductController.class);

	/**
	 * toProductImagesDTOs
	 * 
	 *
	 * @param List<ProductImages> productImages
	 * @return List<ProductImagesDTO>
	 */
	public List<ProductImagesDTO> toProductImagesDTOs(List<ProductImages> productImages) {
		logger.debug("ProductServiceImpl :: toProductImagesDTOs -- begin");
		List<ProductImagesDTO> productImagesDTOs = new ArrayList<>();
		for (ProductImages productImage : productImages) {
			productImagesDTOs.add(ProductImagesDTO.build(productImage.getImageId(), productImage.getImgSrc(),
					productImage.getThumbnail()));
		}
		logger.debug("ProductServiceImpl :: toProductImagesDTOs -- end");
		return productImagesDTOs;
	}

	/**
	 * toCategoryDTO
	 * 
	 *
	 * @param Category category
	 * @return CategoryDTO
	 */
	public CategoryDTO toCategoryDTO(Category category) {
		logger.debug("ProductServiceImpl :: toCategoryDTO -- begin");
		logger.debug("ProductServiceImpl :: toCategoryDTO -- end");
		return CategoryDTO.build(category.getCategoryId(), category.getCategoryName(), category.getCategoryImgSrc());

	}

	/**
	 * toAddressDTOs
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * @return List<Address>
	 */
	public List<AddressDTO> toAddressDTOs(List<Address> addresses) {
		logger.debug("ProductServiceImpl :: toAddressDTOs -- begin");
		List<AddressDTO> addressDTOs = new ArrayList<>();
		for (Address address : addresses) {
			AddressDTO addressDTO = AddressDTO.build(address.getAddressId(), null, address.getFirstName(),
					address.getLastName(), address.getPhone(), address.getAddress1(), address.getAddress2(),
					address.getCity(), address.getZip(), address.getCountry(), null);
			addressDTOs.add(addressDTO);
		}
		logger.debug("ProductServiceImpl :: toAddressDTOs -- end");
		return addressDTOs;
	}

	/**
	 * toCustomerRegistrationDTO
	 * 
	 *
	 * @param CustomerRegistration customerRegistration
	 * @return CustomerRegistrationDTO
	 */
	public CustomerRegistrationDTO toCustomerRegistrationDTO(CustomerRegistration customerRegistration) {
		logger.debug("ProductServiceImpl :: toCustomerRegistrationDTO -- begin");
		List<AddressDTO> addressesDTOs = toAddressDTOs(customerRegistration.getAddress());
		CustomerRegistrationDTO customerRegistrationDTO = CustomerRegistrationDTO.build(
				customerRegistration.getCustomerId(), customerRegistration.getFirstName(),
				customerRegistration.getLastName(), customerRegistration.getEmail(), null, addressesDTOs, null);
		logger.debug("ProductServiceImpl :: toCustomerRegistrationDTO -- end");
		return customerRegistrationDTO;

	}

	/**
	 * toReviewDTO
	 * 
	 * @param Product product
	 * @return List<ReviewDTO>
	 */
	public ReviewDTO toReviewDTO(Review review) {
		logger.debug("ProductServiceImpl :: toReviewDTO -- begin");
		logger.debug("ProductServiceImpl :: toReviewDTO -- end");
		return ReviewDTO.build(review.getReviewId(), review.getRating(), review.getTitle(), review.getReview(),
				review.getReviewDate(), null, null);
	}

	/**
	 * toReview
	 * 
	 * @param ReviewDTO reviewDTO
	 * @return Review
	 */
	public Review toReview(ReviewDTO reviewDTO) {
		logger.debug("ProductServiceImpl :: toReview -- begin");
		LocalDateTime localDateTime = LocalDateTime.now();
		Date date = Date.valueOf(localDateTime.toLocalDate());
		logger.debug("ProductServiceImpl :: toReview -- end");
		return Review.build(reviewDTO.getReviewId(), reviewDTO.getRating(), reviewDTO.getTitle(), reviewDTO.getReview(),
				date, null, null);
	}

	/**
	 * toReviewDTOs
	 * 
	 * @param List<Review> reviews
	 * @return List<ReviewDTO>
	 */
	public List<ReviewDTO> toReviewDTOs(List<Review> reviews) {
		logger.debug("ProductServiceImpl :: toReviewDTOs -- begin");
		List<ReviewDTO> reviewDTOs = reviews.stream().map(item -> toReviewDTO(item)).collect(Collectors.toList());
		logger.debug("ProductServiceImpl :: toReviewDTOs -- end");
		return reviewDTOs;
	}

	/**
	 * toReviews
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<Review> toReviews(List<ReviewDTO> reviewDTOs) {
		logger.debug("ProductServiceImpl :: toReviews -- begin");
		List<Review> reviews = reviewDTOs.stream().map(item -> toReview(item)).collect(Collectors.toList());
		logger.debug("ProductServiceImpl :: toReviews -- end");
		return reviews;
	}

	/**
	 * toCategory
	 * 
	 * @param CategoryDTO categoryDTO
	 * 
	 * @return Category
	 */
	public Category toCategory(CategoryDTO categoryDTO) {
		logger.debug("ProductServiceImpl :: toCategory -- begin");
		logger.debug("ProductServiceImpl :: toCategory -- end");
		return Category.build(categoryDTO.getCategoryId(), categoryDTO.getCategoryName(),
				categoryDTO.getCategoryImgSrc(), null);

	}

	/**
	 * toProductEntity
	 * 
	 * @param ProductDTO productDTO
	 * 
	 * @return Product
	 */
	public Product toProduct(ProductDTO productDTO) {
		logger.debug("ProductServiceImpl :: toProduct -- begin");
		Category category = toCategory(productDTO.getCategoryDTO());
		List<ProductImages> productImages = toProductImages(productDTO.getProductImagesDTOs());
		List<Review> reviews = toReviews(productDTO.getReviewDTOs());
		Product product = Product.build(productDTO.getProductId(), productDTO.getProductName(),
				productDTO.getProductDesc(), productDTO.getProductPrice(), productDTO.getStock(), category,
				productImages, null, productDTO.getWishlistflag(), productDTO.getRating(),null, reviews, null);
		logger.debug("ProductServiceImpl :: toProduct -- end");
		return product;
	}

	/**
	 * toProductImages
	 * 
	 * @param List<ProductImagesDTO> productImagesDTO
	 * 
	 * @return List<ProductImages>
	 */
	public List<ProductImages> toProductImages(List<ProductImagesDTO> productImagesDTO) {
		logger.debug("ProductServiceImpl :: toProductImages -- begin");
		List<ProductImages> productImages = new ArrayList<>();
		for (ProductImagesDTO productImage : productImagesDTO) {
			productImages.add(ProductImages.build(productImage.getImageId(), null, productImage.getImgSrc(),
					productImage.getThumbnail(), null));
		}
		logger.debug("ProductServiceImpl :: toProductImages -- end");
		return productImages;
	}

	/**
	 * toProductDTO
	 * 
	 * @param Product product
	 * 
	 * @return Product
	 */
	public ProductDTO toProductDTO(Product product) {
		logger.debug("ProductServiceImpl :: toProductDTO -- begin");
		CategoryDTO categoryDTO = toCategoryDTO(product.getCategory());
		List<ProductImagesDTO> productImagesDTOs = toProductImagesDTOs(product.getProductImages());
		List<ReviewDTO> reviewDTOs = toReviewDTOs(product.getReviews());
		ProductDTO productDTO = ProductDTO.build(product.getProductId(), product.getProductName(),
				product.getProductDesc(), product.getProductPrice(), product.getStock(), categoryDTO, productImagesDTOs,
				product.getWishlistflag(),product.getRating(),reviewDTOs);
		logger.debug("ProductServiceImpl :: toProductDTO -- end");
		return productDTO;
	}

	/**
	 * toProductDTos
	 * 
	 * @param List<Product> products
	 * 
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> toProductDTOs(List<Product> products) {
		logger.debug("ProductServiceImpl :: toProductDTOs -- begin");
		List<ProductDTO> productDispalyDTOs = new ArrayList<>();
		for (Product product : products) {
			productDispalyDTOs.add(toProductDTO(product));
		}
		logger.debug("ProductServiceImpl :: toProductDTOs -- end");
		return productDispalyDTOs;
	}

	/**
	 * getAllProducts
	 *
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> getAllProducts() {
		logger.debug("ProductServiceImpl :: getAllProducts -- begin");
		List<Product> products = productsRepository.findAll();
		logger.debug("ProductServiceImpl :: getAllProducts -- end");
		return toProductDTOs(products);

	}

	/**
	 * getProductByCategory
	 * 
	 * @param Integer categoryId
	 * 
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> getProductByCategory(int categoryId) {
		logger.debug("ProductServiceImpl :: getProductByCategory -- begin");
		List<Product> products = productsRepository.getProductByCategory(categoryId);
		logger.debug("ProductServiceImpl :: getProductByCategory -- end");
		return toProductDTOs(products);

	}

	/**
	 * inStockProducts
	 * 
	 * @return Integer
	 */
	public int inStockProducts() {
		logger.debug("ProductServiceImpl :: inStockProducts -- begin");
		logger.debug("ProductServiceImpl :: inStockProducts -- end");
		return productsRepository.inStockProducts();

	}

	/**
	 * outOfStockProducts
	 * 
	 * @return Integer
	 */
	public int outOfStockProducts() {
		logger.debug("ProductServiceImpl :: outOfStockProducts -- begin");
		logger.debug("ProductServiceImpl :: outOfStockProducts -- end");
		return productsRepository.outOfStockProducts();
	}

	/**
	 * setCompare
	 * 
	 * @param Integer productId
	 * 
	 * @return String
	 */
	public String setCompare(int productId) {
		logger.debug("ProductServiceImpl :: setCompare -- begin");
		productsRepository.setCompare(productId);
		logger.debug("ProductServiceImpl :: setCompare -- end");
		return "Product added to Compare";
	}

	/**
	 * resetCompare
	 * 
	 * @param Integer productId
	 * 
	 * @return String
	 */
	@Override
	public String resetCompare(int productId) {
		logger.debug("ProductServiceImpl :: resetFlresetCompareag -- begin");
		productsRepository.resetCompare(productId);
		logger.debug("ProductServiceImpl :: resetCompare -- end");
		return "Product removed from compare";
	}

	/**
	 * countOfCompareItems
	 * 
	 * @return String
	 */
	public String countOfCompareItems() {
		String message = null;
		logger.debug("ProductServiceImpl :: countOfCompareItems -- begin");
		int count = productsRepository.countOfCompareItems();
		if (count > 1) {
			message = "Only 2 prodcuts can be comapred at a time";
		}
		logger.debug("ProductServiceImpl :: countOfCompareItems -- end");
		return message;
	}

	/**
	 * clearCompare
	 * 
	 * @return String
	 */
	public String clearCompare() {
		logger.debug("ProductServiceImpl :: clearCompare -- begin");
		logger.debug("ProductServiceImpl :: clearCompare -- end");
		productsRepository.clearCompare();
		return "Compare cleared";
	}

	/**
	 * checkCompare
	 * 
	 * @param Integer productId
	 * 
	 * @return Integer
	 */
	public Integer checkCompare(int productId) {
		logger.debug("ProductServiceImpl :: checkCompare -- begin");
		logger.debug("ProductServiceImpl :: checkCompare -- end");
		return productsRepository.checkCompare(productId);
	}

	/**
	 * getCompare
	 * 
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> getCompare() {
		logger.debug("ProductServiceImpl :: getCompare -- begin");
		List<Product> products=productsRepository.getCompare();
		logger.debug("ProductServiceImpl :: getCompare -- end");
		return toProductDTOs(products);
	}

	/**
	 * updateRating
	 * 
	 * @param Float rating ,Integer productId
	 * 
	 * @return String
	 */
	public String updateRating(Double rating, int productId) {
		logger.debug("ProductServiceImpl :: updateRating -- begin");
		productsRepository.updateRating(rating, productId);
		logger.debug("ProductServiceImpl :: updateRating -- end");
		return "rating updated";
	}

	/**
	 * getBanner
	 * 
	 * @return List<HomeDTO>
	 */
	public List<BannerDTO> getBanner() {
		logger.debug("ProductServiceImpl :: getBanner -- begin");
		List<Banner> banners=bannerRepository.getBanners();
		List<BannerDTO> bannerDTOs=new ArrayList<>();
		for(Banner banner:banners) {
			bannerDTOs.add(BannerDTO.build(banner.getBannerId(),banner.getBannerImgSrc(),banner.getDescription(),banner.getBannerTitle()));
		}
		logger.debug("ProductServiceImpl :: getBanner -- end");
		return bannerDTOs;
	}

	/**
	 * findByProductId
	 * 
	 * @return Product
	 */
	public ProductDTO findProductByProductId(int productId) {
		logger.debug("ProductServiceImpl :: findByProductId -- begin");
		Product product=productsRepository.findProductByProductId(productId);
		ProductDTO productDTO=toProductDTO(product);
		logger.debug("ProductServiceImpl :: findByProductId -- end");
		return productDTO;
	}

	/**
	 * clearWishlistFlag
	 * 
	 * @return String
	 */
	public String clearWishlistFlag() {
		logger.debug("ProductServiceImpl :: clearWishlistFlag -- begin");
		productsRepository.clearWishlistFlag();
		logger.debug("ProductServiceImpl :: clearWishlistFlag -- end");
		return "cleared WishlistFlag";
	}

	

}
