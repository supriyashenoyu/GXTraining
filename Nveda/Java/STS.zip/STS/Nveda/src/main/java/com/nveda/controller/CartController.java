package com.nveda.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nveda.dto.CartItemDTO;
import com.nveda.dto.UpdateCartDTO;
import com.nveda.service.CartItemService;
@RestController
@RequestMapping("/nveda")
@CrossOrigin(origins = "*")
public class CartController {
	@Autowired
	CartItemService cartService;
	ResponseEntity<String> response = null;
	String errorMessage = "error";
	  private static Logger logger = LoggerFactory.getLogger(CartController.class);
	
	/**
	 * addToCart->adds product to cart
	 * 
	 * @param CartItemDTO cartDTO
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/addToCart")
	public ResponseEntity<String> addToCart(@RequestBody CartItemDTO cartDTO) {
		logger.debug("CartController :: addToCart -- begin");
		String message="success";
		try {
			message= cartService.addToCart(cartDTO);
			if (message.equals("Item out of stock")) {
				response = new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);
				
			} else {
				response = new ResponseEntity<String>(message, HttpStatus.OK);
			}
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error adding item to cart");
		}
		logger.debug("CartController :: addToCart -- end");
		return response;
	}
	
	/**
	 * getCart->fetches all the cart items
	 * 
	 * @param integer customerId
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/getCart/{customerId}")
	public ResponseEntity<List<CartItemDTO>> getCart(@PathVariable("customerId") int customerId) {
		logger.debug("CartController :: getCart -- begin");
		ResponseEntity<List<CartItemDTO>> responseEntity=null;
		try {
			responseEntity = new ResponseEntity<List<CartItemDTO>>(cartService.getCart(customerId),HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<List<CartItemDTO>>(cartService.getCart(customerId),HttpStatus.NOT_FOUND);
			logger.error("Caught an Exception {} while fetching items from cart",ex);
		}
		logger.debug("CartController :: getCart -- end");
		return responseEntity;
	}
	
	/**
	 * updateCart-> updates the cart quantity
	 * 
	 * @param UpdateCartDTO updateCartDTO
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/updateCart")
	public ResponseEntity<String> updateCart(@RequestBody UpdateCartDTO updateCartDTO) {
		logger.debug("CartController :: updateCart -- begin");
		try {
			response = new ResponseEntity<String>(cartService.updateCartQuantity(updateCartDTO),HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage,HttpStatus.NOT_FOUND);
			logger.error("Caught an Exception {} while updating items in cart",ex);
		}
		logger.debug("CartController :: updateCart -- end");
		return response;
	}
	
	/**
	 * deleteCart->deletes cart item using customerId and productId
	 * 
	 * @param Long customerId,integer productId
	 * @return ResponseEntity<String>
	 */
	@DeleteMapping("/deleteCart/{customerId}/{productId}")
	public ResponseEntity<String> deleteCart(@PathVariable("customerId") long customerId,@PathVariable("productId") int productId) {
		logger.debug("CartController :: deleteCart -- begin");
		try {
			response = new ResponseEntity<String>(cartService.deleteFromCart(customerId, productId), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Caught an Exception {} while deleting items from the cart",ex);
		}
		logger.debug("CartController :: deleteCart -- end");
		return response;
	}

}
