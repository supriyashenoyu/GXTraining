package com.nveda.controller;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nveda.dto.OrderItemDTO;
import com.nveda.service.OrderItemService;
@RestController
@RequestMapping("/nveda")
@CrossOrigin(origins = "*")
public class OrderController {
	@Autowired
	OrderItemService orderItemService;
	ResponseEntity<String> response = null;
	String errorMessage = "error";
	  private static Logger logger = LoggerFactory.getLogger(OrderController.class);
	
	/**
	 * addToCart->adds product to order
	 * 
	 * @param OrderItemDTO orderDTO
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/addToOrder")
	public ResponseEntity<String> addToOder(@RequestBody OrderItemDTO orderDTO) {
		logger.debug("OrderController :: addToOder -- begin");
		try {
		response =   new ResponseEntity<String>(orderItemService.addToOrder(orderDTO), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error adding item to order");
		}
		logger.debug("OrderController :: addToOder -- end");
		return response;
	}
	
	/**
	 * getOrder->fetches all the order items
	 * 
	 * @param integer customerId
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/getOrder/{customerId}")
	public ResponseEntity<List<OrderItemDTO>> getOrder(@PathVariable ("customerId") int customerId) {
		logger.debug("OrderController :: getOrder -- begin");
		ResponseEntity<List<OrderItemDTO>> responseEntity=null;
		try {
			responseEntity = new ResponseEntity<List<OrderItemDTO>>(orderItemService.getOrder(customerId),HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<List<OrderItemDTO>>(orderItemService.getOrder(customerId),HttpStatus.NOT_FOUND);
			logger.error("Caught an Exception {} while fetching items from cart",ex);
		}
		logger.debug("OrderController :: getOrder -- end");
		return responseEntity;
	}
//	
//	/**
//	 * updateCart-> updates the cart quantity
//	 * 
//	 * @param UpdateCartDTO updateCartDTO
//	 * @return ResponseEntity<String>
//	 */
//	@PostMapping("/updateCart")
//	public ResponseEntity<String> updateCart(@RequestBody UpdateCartDTO updateCartDTO) {
//		logger.debug("OrderController :: updateCart -- begin");
//		try {
//			response = new ResponseEntity<String>(cartService.updateCartQuantity(updateCartDTO),HttpStatus.OK);
//		} catch (Exception ex) {
//			response = new ResponseEntity<String>(errorMessage,HttpStatus.NOT_FOUND);
//			logger.error("Caught an Exception {} while updating items in cart",ex);
//		}
//		logger.debug("OrderController :: updateCart -- end");
//		return response;
//	}
//	
//	/**
//	 * deleteCart->deletes cart item using customerId and productId
//	 * 
//	 * @param Long customerId,integer productId
//	 * @return ResponseEntity<String>
//	 */
//	@DeleteMapping("/deleteCart/{customerId}/{productId}")
//	public ResponseEntity<String> deleteCart(@PathVariable("customerId") long customerId,@PathVariable("productId") int productId) {
//		logger.debug("OrderController :: deleteCart -- begin");
//		try {
//			response = new ResponseEntity<String>(cartService.deleteFromCart(customerId, productId), HttpStatus.OK);
//		} catch (Exception ex) {
//			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
//			logger.error("Caught an Exception {} while deleting items from the cart",ex);
//		}
//		logger.debug("OrderController :: deleteCart -- end");
//		return response;
//	}

}
