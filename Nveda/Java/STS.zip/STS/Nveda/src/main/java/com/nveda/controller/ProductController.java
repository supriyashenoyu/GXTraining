package com.nveda.controller;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nveda.dto.BannerDTO;
import com.nveda.dto.CategoryDTO;
import com.nveda.dto.ProductDTO;
import com.nveda.dto.RatingDTO;
import com.nveda.dto.ReviewDTO;
import com.nveda.dto.WishlistDTO;
import com.nveda.service.CategoryService;
import com.nveda.service.ProductService;
import com.nveda.service.ReviewService;
import com.nveda.service.WishlistService;


@RestController
@RequestMapping("/nveda")
@CrossOrigin(origins = "*")

public class ProductController {
	ResponseEntity<String> response = null;
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductService productService;
	@Autowired
	WishlistService wishlistService;
	@Autowired
	ReviewService reviewService; 
	String errorMessage="error";
	private static Logger logger = LogManager.getLogger(ProductController.class);
	 
	/**
	 * addAddress->Adds address of the customer
	 * 
	 * @return ResponseEntity<List<ProductDispalyDTO>>
	 */
	@GetMapping("/products")
	public ResponseEntity<List<ProductDTO>> getProducts() {
		logger.debug("ProductController :: getProducts -- begin");
		ResponseEntity<List<ProductDTO>> responseEntity = null;
		try {
			responseEntity = new ResponseEntity<List<ProductDTO>>(productService.getAllProducts(),
					HttpStatus.OK);
		} catch (Exception ex) {
			ex.printStackTrace();
			responseEntity = new ResponseEntity<List<ProductDTO>>(productService.getAllProducts(),
					HttpStatus.NOT_FOUND);
			  logger.error("Error fetching products");
		}
		logger.debug("ProductController :: getProducts -- end");
		return responseEntity;
	}

	/**
	 * getCategory->fetches product category
	 *
	 * @return ResponseEntity<List<CategoryDTO>>
	 */
	@GetMapping("/category")
	public ResponseEntity<List<CategoryDTO>> getCategory() {
		logger.debug("ProductController :: getCategory -- begin");
		ResponseEntity<List<CategoryDTO>> responseEntity = null;
		try {
			responseEntity = new ResponseEntity<List<CategoryDTO>>(categoryService.getAllCategory(), HttpStatus.OK);
		} catch (Exception ex) {
			ex.printStackTrace();
			responseEntity = new ResponseEntity<List<CategoryDTO>>(categoryService.getAllCategory(),
					HttpStatus.NOT_FOUND);
			logger.error("Error fetching category");
		}
		logger.debug("ProductController :: getCategory -- end");
		return responseEntity;
	}

	/**
	 * addToWishlist->adds product to the wishlist
	 * 
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/addToWishlist")
	public ResponseEntity<String> addToWishlist(@RequestBody WishlistDTO wishlistDTO) {
		logger.debug("ProductController :: addToWishlist -- begin");
		try {
			response= new ResponseEntity<String>(wishlistService.addToWishlist(wishlistDTO), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("item removed from wishlist");
		}
		logger.debug("ProductController :: addToWishlist -- end");
		return response;
	}

	/**
	 * setFlag->set the flag if product is in customers wishlist
	 *
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/setFlag/{customerId}")
	public ResponseEntity<String> setFlag(@PathVariable("customerId") int customerId) {
		logger.debug("ProductController :: setFlag -- begin");
		try {
			response= new ResponseEntity<String>(wishlistService.setFlag(customerId), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("caught exception while setting the flag");
		}
		logger.debug("ProductController :: setFlag -- end");
		return response;
	}

	/**
	 * reSetFlag->resets the flag if product is removed from customers wishlist
	 * 
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/resetFlag/{customerId}")
	public ResponseEntity<String> resetFlag(@PathVariable("customerId") int customerId) {
		logger.debug("ProductController :: resetFlag -- begin");
		try {
			response= new ResponseEntity<String>(wishlistService.resetFlag(customerId), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("caught exception while setting the flag");
		}
		logger.debug("ProductController :: resetFlag -- end");
		return response;
	}
	
	
	/**
	 * clearFlag->clears wishlistFlag of products
	 * 
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/clearFlag")
	public ResponseEntity<String> clearFlag() {
		logger.debug("ProductController :: clearFlag -- begin");
		try {
			response =  new ResponseEntity<String>(productService.clearWishlistFlag(), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("caught exception while setting the flag");
		}
		logger.debug("ProductController :: clearFlag -- end");
		return response;
	}
	
	/**
	 * deleteFromWishlist->deletes items from wishlist using productId
	 * 
	 * @param Integer productId
	 * @return ResponseEntity<String>
	 */
	@DeleteMapping("/deleteFromWishlist/{customerId}/{productId}")
	public ResponseEntity<String> deleteFromWishlist(@PathVariable("customerId") int customerId,@PathVariable("productId") int productId) {
		logger.debug("ProductController :: deleteFromWishlist -- begin");
		try {
			response= new ResponseEntity<String>(wishlistService.deleteFromWishlist(customerId,productId), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error deleteing item from wishlist");
		}
		logger.debug("ProductController :: deleteFromWishlist -- end");
		return response;
	}
	
	/**
	 * getWishlistById->fetches wishlist item by customer id
	 *
	 * @param Integer customerId
	 * @return ResponseEntity<List<WishlistDTO>>
	 */
	@GetMapping("/getWishlist/{customerId}")
	public ResponseEntity<List<WishlistDTO>> getWishlistById(@PathVariable("customerId") int customerId) {
		logger.debug("ProductController :: getWishlistById -- begin");
		ResponseEntity<List<WishlistDTO>> responseEntity;
		try {
			responseEntity= new ResponseEntity<List<WishlistDTO>>(wishlistService.getWishlistById(customerId), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<List<WishlistDTO>>(wishlistService.getWishlistById(customerId), HttpStatus.NOT_FOUND);
			logger.error("Error fetching items from wishlist");
		}
		logger.debug("ProductController :: getWishlistById -- end");
		return responseEntity;
	}
	
	/**
	 * getProductByCategory->fectches products based on category id
	 *
	 * @param Integer categoryId
	 * 
	 * @return ResponseEntity<List<categoryId>>
	 */
	@GetMapping("/getProductByCategory/{categoryId}")
	public ResponseEntity<List<ProductDTO>> getProductByCategory(@PathVariable("categoryId") int categoryId) {
		logger.debug("ProductController :: getProductByCategory -- begin");
		ResponseEntity<List<ProductDTO>> responseEntity;
		try {
			responseEntity= new ResponseEntity<List<ProductDTO>>(productService.getProductByCategory(categoryId), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<List<ProductDTO>>(productService.getProductByCategory(categoryId), HttpStatus.NOT_FOUND);
			logger.error("Error Fetching products by categoryId");
		}
		logger.debug("ProductController :: getProductByCategory -- end");
		return responseEntity;
	}
	
	/**
	 * inStock->gives count of products in stock
	 *
	 * @return ResponseEntity<Integer>
	 */
	@GetMapping("/stock")
	public ResponseEntity<Integer> inStock() {
		logger.debug("ProductController :: inStock -- begin");
		ResponseEntity<Integer> responseEntity;
		try {
			responseEntity= new ResponseEntity<Integer>(productService.inStockProducts(), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<Integer>(productService.inStockProducts(), HttpStatus.NOT_FOUND);
			logger.error("Error fetching count of items instock");
		}
		logger.debug("ProductController :: inStock -- end");
		return responseEntity;
	}
	
	/**
	 * inStockgives count of products out of stock
	 *
	 * @return ResponseEntity<Integer>
	 */
	@GetMapping("/outOfStock")
	public ResponseEntity<Integer> outOfStock() {
		logger.debug("ProductController :: outOfStock -- begin");
		ResponseEntity<Integer> responseEntity;
		try {
			responseEntity= new ResponseEntity<Integer>(productService.outOfStockProducts(), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<Integer>(productService.outOfStockProducts(), HttpStatus.NOT_FOUND);
			logger.error("Error fetching count of items out of stock");
		}
		logger.debug("ProductController :: outOfStock -- end");
		return responseEntity;
	}
	
	/**
	 * saveReview
	 *
	 *@param ReviewDTO reviewDTO
	 *
	 * @return ResponseEntity<Integer>
	 */
	@PostMapping("/addReview")
	public ResponseEntity<String> saveReview(@RequestBody ReviewDTO reviewDTO) {
		logger.debug("ProductController :: saveReview -- begin");
		try {
			response= new ResponseEntity<String>(reviewService.saveReview(reviewDTO), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error adding review of the product");
			
		}
		logger.debug("ProductController :: saveReview -- begin");
		return response;
	}
	
	/**
	 * getRating->gives rating of product 
	 *
	 * @param integer productId
	 *
	 * @return ResponseEntity<RatingDTO>
	 */
	@GetMapping("/rating/{productId}")
	public ResponseEntity<RatingDTO> getRating(@PathVariable("productId") int productId) {
		logger.debug("ProductController :: getRating -- begin");
		ResponseEntity<RatingDTO> responseEntity;
		try {
			responseEntity= new ResponseEntity<RatingDTO>(reviewService.getRating(productId), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<RatingDTO>(reviewService.getRating(productId), HttpStatus.NOT_FOUND);
			logger.error("Error fetching rating of the product");
		}
		logger.debug("ProductController :: getRating -- end");
		return responseEntity;
	}
	
	/**
	 * setCompare->set the compare flag of product
	 * 
	 * @param integer productId
	 *
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/setCompare/{productId}")
	public ResponseEntity<String> setCompare(@PathVariable("productId") int productId) {
		logger.debug("ProductController :: setCompare -- begin");
		try {
			response= new ResponseEntity<String>(productService.setCompare(productId), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("caught exception while setting compare flag of product");
		}
		logger.debug("ProductController :: setCompare -- end");
		return response;
	}
	
	/**
	 * resetCompare->resets  the compare flag of product
	 * 
	 * @param integer productId
	 * 
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/resetCompare/{productId}")
	public ResponseEntity<String> resetCompare(@PathVariable("productId") int productId) {
		logger.debug("ProductController :: resetCompare -- begin");
		try {
			response= new ResponseEntity<String>(productService.resetCompare(productId), HttpStatus.OK);
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("caught exception while resetting the flag");
		}
		logger.debug("ProductController :: resetCompare -- end");
		return response;
	}
	
	/**
	 * countOfCompare->gives the count of items to compare
	 * 
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/countCompare")
	public ResponseEntity<String> countOfCompare(){
		logger.debug("ProductController :: countOfCompare -- begin");
		try {
			String message=productService.countOfCompareItems();
			if(message==null) {
			response= new ResponseEntity<String>(productService.countOfCompareItems(), HttpStatus.OK);}
			else {
				response= new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);}
			
		} catch (Exception ex) {
			response = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("caught exception counting items in compare");
		}
		logger.debug("ProductController :: countOfCompare -- end");
		return response;
	}
	
	/**
	 * checkCompare->gives value of compare flag
	 *
	 * @param  Integer productId
	 * @return ResponseEntity<Integer>
	 */
	@GetMapping("/checkCompare/{productId}")
	public ResponseEntity<Integer> checkCompare(@PathVariable int productId) {
		logger.debug("ProductController :: checkCompare -- begin");
		ResponseEntity<Integer> responseEntity;
		try {
			responseEntity= new ResponseEntity<Integer>(productService.checkCompare(productId), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<Integer>(productService.checkCompare(productId), HttpStatus.NOT_FOUND);
			logger.error("Error fetching compare flag of product");
		}
		logger.debug("ProductController :: checkCompare -- end");
		return responseEntity;
	}
	
	
	/**
	 * clearCompare->sets compare flag of all products to zero
	 *
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/clearCompare")
	public ResponseEntity<String> clearCompare() {
		logger.debug("ProductController :: checkCompare -- begin");
		try {
			response= new ResponseEntity<String>(productService.clearCompare(), HttpStatus.OK);
		} catch (Exception ex) {
			response= new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error fetching compare flag of product");
		}
		logger.debug("ProductController :: checkCompare -- end");
		return response;
	}
	
	/**
	 * getCompare->fetches all products from compare
	 *
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/getCompare")
	public ResponseEntity<List<ProductDTO>> getCompare() {
		logger.debug("ProductController :: checkCompare -- begin");
		ResponseEntity<List<ProductDTO>> responseEntity;
		try {
			responseEntity= new ResponseEntity<List<ProductDTO>>(productService.getCompare(), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity= new ResponseEntity<List<ProductDTO>>(productService.getCompare(), HttpStatus.NOT_FOUND);
			logger.error("Error fetching compare flag of product");
		}
		logger.debug("ProductController :: checkCompare -- end");
		return responseEntity;
	}
	
	/**
	 * getCompare->fetches all products from compare
	 *
	 * @return ResponseEntity<String>
	 */
	@GetMapping("/updateRating/{rating}/{productId}")
	public ResponseEntity<String> updateRating(@PathVariable Double rating,@PathVariable int productId) {
		logger.debug("ProductController :: updateRating -- begin");
		try {
			response= new ResponseEntity<String>(productService.updateRating(rating, productId), HttpStatus.OK);
		} catch (Exception ex) {
			response= new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
			logger.error("Error updating rating of product");
		}
		logger.debug("ProductController :: updateRating -- end");
		return response;
	}
	
	/**
	 * getBanner->gives banners details
	 *
	 * @return ResponseEntity<Integer>
	 */
	@GetMapping("/getBanner")
	public ResponseEntity<List<BannerDTO>> getBanner() {
		logger.debug("ProductController :: getBanner -- begin");
		ResponseEntity<List<BannerDTO>> responseEntity;
		try {
			responseEntity= new ResponseEntity<List<BannerDTO>>(productService.getBanner(), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<List<BannerDTO>>(productService.getBanner(), HttpStatus.NOT_FOUND);
			logger.error("Error fetching count of items out of stock");
		}
		logger.debug("ProductController :: getBanner -- end");
		return responseEntity;
	}
	
	/**
	 * findProductById
	 *
	 *@param Integer productId
	 *
	 * @return ResponseEntity<Integer>
	 */
	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<ProductDTO> findProductByProductId(@PathVariable int productId) {
		logger.debug("ProductController :: findProductById -- begin");
		ResponseEntity<ProductDTO> responseEntity;
		try {
			responseEntity= new ResponseEntity<ProductDTO>(productService.findProductByProductId(productId), HttpStatus.OK);
		} catch (Exception ex) {
			responseEntity = new ResponseEntity<ProductDTO>(productService.findProductByProductId(productId), HttpStatus.NOT_FOUND);
			logger.error("Error finding product by Id");
			
		}
		logger.debug("ProductController :: findProductById -- begin");
		return responseEntity;
	}


}
