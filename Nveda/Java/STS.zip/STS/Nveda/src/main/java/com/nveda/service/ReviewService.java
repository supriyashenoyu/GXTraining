package com.nveda.service;





import com.nveda.dto.RatingDTO;
import com.nveda.dto.ReviewDTO;




public interface ReviewService {
	String saveReview(ReviewDTO reviewDTO);
	RatingDTO getRating(int productId);
}
