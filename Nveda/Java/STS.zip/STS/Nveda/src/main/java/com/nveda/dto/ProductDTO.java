package com.nveda.dto;


import java.util.List;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName="build")
@NoArgsConstructor
public class ProductDTO {
	private int productId;
	private  String productName;
	private String productDesc;
	private  float productPrice;
	private int stock;
	private CategoryDTO categoryDTO;
	private  List<ProductImagesDTO> productImagesDTOs;
	private Boolean Wishlistflag;
	private Double rating;
	private List<ReviewDTO> reviewDTOs;

	
}
