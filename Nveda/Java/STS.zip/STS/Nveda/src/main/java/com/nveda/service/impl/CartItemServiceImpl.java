package com.nveda.service.impl;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nveda.controller.ProductController;
import com.nveda.dto.AddressDTO;
import com.nveda.dto.CartItemDTO;
import com.nveda.dto.CategoryDTO;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.dto.ProductDTO;
import com.nveda.dto.ProductImagesDTO;
import com.nveda.dto.ReviewDTO;
import com.nveda.dto.UpdateCartDTO;
import com.nveda.entities.Address;
import com.nveda.entities.CartItem;
import com.nveda.entities.Category;
import com.nveda.entities.CustomerRegistration;
import com.nveda.entities.Product;
import com.nveda.entities.ProductImages;
import com.nveda.entities.Review;
import com.nveda.repo.CartItemRepository;
import com.nveda.repo.ProductsRepository;
import com.nveda.service.CartItemService;

@Service
public class CartItemServiceImpl implements CartItemService {
	@Autowired
	CartItemRepository cartItemRepository;
	@Autowired
	ProductsRepository productsRepository;
	private static Logger logger = LogManager.getLogger(ProductController.class);

	/**
	 * toProductImages
	 * 
	 * @param List<ProductImagesDTO> productImagesDTO
	 * 
	 * @return List<ProductImages>
	 */
	public List<ProductImages> toProductImages(List<ProductImagesDTO> productImagesDTO) {
		logger.debug("CartItemServiceImpl :: toProductImages -- begin");
		List<ProductImages> productImages = new ArrayList<>();
		for (ProductImagesDTO productImage : productImagesDTO) {
			productImages.add(ProductImages.build(productImage.getImageId(), null, productImage.getImgSrc(),productImage.getThumbnail() ,null));
		}
		logger.debug("CartItemServiceImpl :: toProductImages -- end");
		return productImages;
	}

	/**
	 * toCategory
	 * 
	 * @param CategoryDTO categoryDTO
	 * 
	 * @return Category
	 */
	public Category toCategory(CategoryDTO categoryDTO) {
		logger.debug("CartItemServiceImpl :: toCategory -- begin");
		logger.debug("CartItemServiceImpl :: toCategory -- end");
		return Category.build(categoryDTO.getCategoryId(), categoryDTO.getCategoryName(),
				categoryDTO.getCategoryImgSrc(), null);

	}

	/**
	 * toProductEntity
	 * 
	 * @param ProductDTO productDTO
	 * 
	 * @return Product
	 */
	public Product toProduct(ProductDTO productDTO) {
		logger.debug("CartItemServiceImpl :: toProduct -- begin");
		Category category = toCategory(productDTO.getCategoryDTO());
		List<ProductImages> productImages = toProductImages(productDTO.getProductImagesDTOs());
		List<Review> reviews=toReviews(productDTO.getReviewDTOs());
		Product product = Product.build(productDTO.getProductId(), productDTO.getProductName(),
				productDTO.getProductDesc(), productDTO.getProductPrice(), productDTO.getStock(), category,
				productImages, null, productDTO.getWishlistflag(),productDTO.getRating(), null,reviews,null);
		logger.debug("CartItemServiceImpl :: toProduct -- end");
		return product;
	}

	/**
	 * toReviewDTO
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public ReviewDTO toReviewDTO(Review review) {
		logger.debug("CartItemServiceImpl :: toReviewDTO -- begin");
		logger.debug("CartItemServiceImpl :: toReviewDTO -- end");
		return ReviewDTO.build(review.getReviewId(),review.getRating(),review.getTitle(),review.getReview(),review.getReviewDate(),null ,null);
	}

	/**
	 * toReview
	 * 
	 * @param ReviewDTO reviewDTO 
	 * 
	 * @return Review
	 */
	public Review toReview(ReviewDTO reviewDTO) {
		logger.debug("CartItemServiceImpl :: toReview -- begin");
		   LocalDateTime localDateTime = LocalDateTime.now();
		    Date date = Date.valueOf(localDateTime.toLocalDate());
		    logger.debug("CartItemServiceImpl :: toReview -- end");
		    return Review.build(reviewDTO.getReviewId(),reviewDTO.getRating(),reviewDTO.getTitle(),reviewDTO.getReview(),date,null,null);
	}

	/**
	 * toReviewDTOs
	 * 
	 * @param List<Review> reviews
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<ReviewDTO> toReviewDTOs(List<Review> reviews) {
		logger.debug("CartItemServiceImpl :: toReviewDTOs -- begin");
		List<ReviewDTO> reviewDTOs = reviews.stream().map(item->toReviewDTO(item)).collect(Collectors.toList());
		logger.debug("CartItemServiceImpl :: toReviewDTOs -- end");
		return reviewDTOs;
	}

	/**
	 * toReviews
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<Review> toReviews(List<ReviewDTO> reviewDTOs) {
		logger.debug("CartItemServiceImpl :: toReviews -- begin");
		List<Review> reviews = reviewDTOs.stream().map(item->toReview(item)).collect(Collectors.toList());
		logger.debug("CartItemServiceImpl :: toReviews -- end");
		return reviews;
	}

	/**
	 * toProductDTO
	 * 
	 * @param Product product
	 * 
	 * @return Product
	 */
	public ProductDTO toProductDTO(Product product) {
		logger.debug("CartItemServiceImpl :: toProductDTO -- begin");
		CategoryDTO categoryDTO = toCategoryDTO(product.getCategory());
		List<ProductImagesDTO> productImagesDTOs = toProductImagesDTOs(product.getProductImages());
		List<ReviewDTO> reviewDTOs=toReviewDTOs(product.getReviews());
		ProductDTO productDTO = ProductDTO.build(product.getProductId(), product.getProductName(),
				product.getProductDesc(), product.getProductPrice(), product.getStock(), categoryDTO, productImagesDTOs,
				product.getWishlistflag(),product.getRating(),reviewDTOs);
		logger.debug("CartItemServiceImpl :: toProductDTO -- end");
		return productDTO;
	}

	/**
	 * toProducts
	 * 
	 *
	 * @param List<ProductDTO> productsDTO
	 * 
	 * @return List<Product>
	 */
	public List<Product> toProducts(List<ProductDTO> productsDTOs) {
		logger.debug("CartItemServiceImpl :: toProducts -- begin");
		List<Product> product = productsDTOs.stream().map(item -> toProduct(item)).collect(Collectors.toList());
		logger.debug("CartItemServiceImpl :: toProducts -- end");
		return product;
	}

	/**
	 * toAdresses
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * 
	 * @return List<Address>
	 */
	public List<Address> toAddresses(List<AddressDTO> addressDTOs) {
		logger.debug("CartItemServiceImpl :: toAddresses -- begin");
		List<Address> addresses = new ArrayList<>();
		for (AddressDTO addressDTO : addressDTOs) {
			Address address = Address.build(addressDTO.getAddressId(), null, addressDTO.getFirstName(),
					addressDTO.getLastName(), addressDTO.getPhone(), addressDTO.getAddress1(), addressDTO.getAddress2(),
					addressDTO.getZip(), addressDTO.getCity(), addressDTO.getCountry(), null);
			addresses.add(address);
		}
		logger.debug("CartItemServiceImpl :: toAddresses -- end");
		return addresses;
	}

	/**
	 * toCustomerRegistration
	 * 
	 *
	 * @param CustomerRegistrationDTO customerRegistrationDTO
	 * 
	 * @return CustomerRegistration
	 */
	public CustomerRegistration toCustomerRegistration(CustomerRegistrationDTO customerRegistrationDTO) {
		logger.debug("CartItemServiceImpl :: toCustomerRegistration -- begin");
		List<Address> addresses = toAddresses(customerRegistrationDTO.getAddressDTO());
		CustomerRegistration customerRegistration = CustomerRegistration.build(customerRegistrationDTO.getCustomerId(),
				customerRegistrationDTO.getFirstName(), customerRegistrationDTO.getLastName(),
				customerRegistrationDTO.getEmail(), null, addresses, null,null,null,null);
		logger.debug("CartItemServiceImpl :: toCustomerRegistration -- end");
		return customerRegistration;

	}

	/**
	 * toProductImagesDTOs
	 * 
	 *
	 * @param List<ProductImages> productImages
	 * 
	 * @return List<ProductImagesDTO>
	 */
	public List<ProductImagesDTO> toProductImagesDTOs(List<ProductImages> productImages) {
		logger.debug("CartItemServiceImpl :: toProductImagesDTOs -- begin");
		List<ProductImagesDTO> productImagesDTOs = new ArrayList<>();
		for (ProductImages productImage : productImages) {
			productImagesDTOs.add(ProductImagesDTO.build(productImage.getImageId(), productImage.getImgSrc(), productImage.getThumbnail()));
		}
		logger.debug("CartItemServiceImpl :: toProductImagesDTOs -- end");
		return productImagesDTOs;
	}

	/**
	 * toAddressDTOs
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * 
	 * @return List<Address>
	 */
	public List<AddressDTO> toAddressDTOs(List<Address> addresses) {
		logger.debug("CartItemServiceImpl :: toAddressDTOs -- begin");
		List<AddressDTO> addressDTOs = new ArrayList<>();
		for (Address address : addresses) {
			AddressDTO addressDTO = AddressDTO.build(address.getAddressId(), null, address.getFirstName(),
					address.getLastName(), address.getPhone(), address.getAddress1(), address.getAddress2(),
					address.getCity(), address.getZip(), address.getCountry(), null);
			addressDTOs.add(addressDTO);
		}
		logger.debug("CartItemServiceImpl :: toAddressDTOs -- end");
		return addressDTOs;
	}

	/**
	 * toCategoryDTO
	 * 
	 *
	 * @param Category category
	 * 
	 * @return CategoryDTO
	 */
	public CategoryDTO toCategoryDTO(Category category) {
		logger.debug("CartItemServiceImpl :: toCategoryDTO -- begin");
		logger.debug("CartItemServiceImpl :: toCategoryDTO -- end");
		return CategoryDTO.build(category.getCategoryId(), category.getCategoryName(), category.getCategoryImgSrc());

	}

	/**
	 * toCustomerRegistrationDTO
	 * 
	 *
	 * @param CustomerRegistration customerRegistration
	 * 
	 * @return CustomerRegistrationDTO
	 */
	public CustomerRegistrationDTO toCustomerRegistrationDTO(CustomerRegistration customerRegistration) {
		logger.debug("CartItemServiceImpl :: toCustomerRegistrationDTO -- begin");
		List<AddressDTO> addressesDTOs = toAddressDTOs(customerRegistration.getAddress());
		CustomerRegistrationDTO customerRegistrationDTO = CustomerRegistrationDTO.build(
				customerRegistration.getCustomerId(), customerRegistration.getFirstName(),
				customerRegistration.getLastName(), customerRegistration.getEmail(), null, addressesDTOs, null);
		logger.debug("CartItemServiceImpl :: toCustomerRegistrationDTO -- end");
		return customerRegistrationDTO;

	}

	/**
	 * toProductDTos
	 * 
	 *
	 * @param List<Product> products
	 * 
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> toProductDTOs(List<Product> products) {
		logger.debug("CartItemServiceImpl :: toProductDTOs -- begin");
		List<ProductDTO> productDispalyDTOs = new ArrayList<>();
		for (Product product : products) {
			productDispalyDTOs.add(toProductDTO(product));
		}
		logger.debug("CartItemServiceImpl :: toProductDTOs -- end");
		return productDispalyDTOs;
	}

	/**
	 * toCart
	 * 
	 * @param CartItemDTO cartDTO
	 * 
	 * @return CartItem
	 */
	public CartItem toCart(CartItemDTO cartDTO) {
		logger.debug("CartItemServiceImpl :: toCart -- begin");
		CartItem cartItem = CartItem.build(cartDTO.getCartId(), toProduct(cartDTO.getProductDTO()),
				toCustomerRegistration(cartDTO.getCustomerRegistrationDTO()), cartDTO.getQuantity(),
				cartDTO.getTotalAmount());
		logger.debug("CartItemServiceImpl :: toCart -- end");
		return cartItem;
	}

	/**
	 * toCartDTO
	 * 
	 * @param CartItem
	 * 
	 * @return CartDTO
	 */
	public CartItemDTO toCartDTO(CartItem cart) {
		logger.debug("CartItemServiceImpl :: toCartDTO -- begin");
		CartItemDTO cartDTO = CartItemDTO.build(cart.getCartId(), toProductDTO(cart.getProduct()),
				toCustomerRegistrationDTO(cart.getCustomerRegistration()), cart.getQuantity(), cart.getTotalAmount());
		logger.debug("CartItemServiceImpl :: toCartDTO -- end");
		return cartDTO;
	}

	/**
	 * UpdateCart
	 * 
	 * @param Integer productId,Integer leftOverStock,long customerId,Integer
	 *                quantity,float price
	 *                
	 * @return String
	 */
	public String UpdateCart(int productId, int leftOverStock, long customerId, int quantity, float price) {
		logger.debug("CartItemServiceImpl :: UpdateCart -- begin");
		String message = "Added to cart";
		List<Integer> cartProducts = cartItemRepository.isPresentInCart(customerId);
		if (cartProducts.contains(productId)) {
			CartItem cartItem = cartItemRepository.findByProductId(productId, customerId);
			int cartQuantity = cartItem.getQuantity();
			int updatedQuantity = cartQuantity + quantity;
			if (updatedQuantity <= leftOverStock) {
				float updatedAmount = updatedQuantity * price;
				cartItemRepository.updateQuantity(customerId, productId, updatedQuantity, updatedAmount);
			} else {
				message = "Item out of stock";
			}
		} else {
			message = "new Cart Item";
		}
		logger.debug("CartItemServiceImpl :: UpdateCart -- end");
		return message;
	}

	/**
	 * addToCart
	 * 
	 * @param cartDTO
	 * 
	 * @return String
	 */
	public String addToCart(CartItemDTO cartDTO) {
		logger.debug("CartItemServiceImpl :: addToCart -- begin");
		String message = "Added to cart";
		message = UpdateCart(cartDTO.getProductDTO().getProductId(), cartDTO.getProductDTO().getStock(),
				cartDTO.getCustomerRegistrationDTO().getCustomerId(), cartDTO.getQuantity(),
				cartDTO.getProductDTO().getProductPrice());
		if (message.equals("new Cart Item")) {
			cartItemRepository.save(toCart(cartDTO));
			message = "Added to cart";
		}
		logger.debug("CartItemServiceImpl :: addToCart -- end");
		return message;
	}

	/**
	 * getCart
	 * 
	 * @param Integer customerId
	 * 
	 * @return List<CartItemDTO>
	 */
	public List<CartItemDTO> getCart(int customerId) {
		logger.debug("CartItemServiceImpl :: getCart -- begin");
		List<CartItem> cartItems = cartItemRepository.findByCustomerId(customerId);
		List<CartItemDTO> cartItemDTOs = new ArrayList<>();
		for (CartItem cartItem : cartItems) {
			cartItemDTOs.add(toCartDTO(cartItem));
		}
		logger.debug("CartItemServiceImpl :: getCart -- end");
		return cartItemDTOs;

	}

	/**
	 * updateCartQuantity
	 * 
	 * @param long customerId,Integer productId,Integer quantity
	 * 
	 * @return String
	 */
	public String updateCartQuantity(UpdateCartDTO updateCartDTO) {
		logger.debug("CartItemServiceImpl :: updateCartQuantity -- begin");
		cartItemRepository.updateQuantity(updateCartDTO.getCustomerId(), updateCartDTO.getProductId(),
				updateCartDTO.getQuantity(), updateCartDTO.getTotalAmount());
		logger.debug("CartItemServiceImpl :: updateCartQuantity -- end");
		return "cart Item updated";

	}

	/**
	 * deleteFromCart
	 * 
	 * @param long customerId,Integer productId
	 * 
	 * @return String
	 */
	public String deleteFromCart(long customerId, int productId) {
		logger.debug("CartItemServiceImpl :: deleteFromCart -- begin");
		cartItemRepository.deleteCartItem(customerId, productId);
		logger.debug("CartItemServiceImpl :: deleteFromCart -- end");
		return "deleted cart Item";

	}

}
