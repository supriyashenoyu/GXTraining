package com.nveda.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.nveda.entities.Wishlist;

import jakarta.transaction.Transactional;
@Repository
public interface WishlistRepository extends JpaRepository<Wishlist,Integer>{
	
	
	@Query(value="select * from wishlist where customer_id=:customerId",nativeQuery=true)
	List<Wishlist> findByCustomerRegistration(int customerId);

	@Transactional
	@Modifying
	@Query(value="delete from wishlist where customer_id=:customerId and product_id=:productId",nativeQuery=true)
	void deleteByProductId(int customerId,int productId);
	
	
	
	  


}
