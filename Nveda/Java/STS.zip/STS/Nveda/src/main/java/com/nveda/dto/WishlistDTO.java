package com.nveda.dto;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class WishlistDTO {
	private int wishlistId;
	private CustomerRegistrationDTO customerRegistrationDTO;
	private ProductDTO productDTO;

}
