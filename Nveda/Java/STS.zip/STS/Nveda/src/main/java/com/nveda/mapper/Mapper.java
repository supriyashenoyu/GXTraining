package com.nveda.mapper;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.nveda.dto.AddressDTO;
import com.nveda.dto.CategoryDTO;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.dto.ProductDTO;
import com.nveda.dto.ProductImagesDTO;
import com.nveda.dto.ReviewDTO;
import com.nveda.entities.Address;
import com.nveda.entities.Category;
import com.nveda.entities.CustomerRegistration;
import com.nveda.entities.Product;
import com.nveda.entities.ProductImages;
import com.nveda.entities.Review;
@Component
public class Mapper {
	private static Logger logger = LogManager.getLogger(Mapper.class);

	/**
	 * toProductImagesDTOs
	 * 
	 *
	 * @param List<ProductImages> productImages
	 * 
	 * @return List<ProductImagesDTO>
	 */
	public List<ProductImagesDTO> toProductImagesDTOs(List<ProductImages> productImages) {
		logger.debug("Mapper :: toProductImagesDTOs -- begin");
		List<ProductImagesDTO> productImagesDTOs = new ArrayList<>();
		for (ProductImages productImage : productImages) {
			productImagesDTOs.add(ProductImagesDTO.build(productImage.getImageId(), productImage.getImgSrc(),
					productImage.getThumbnail()));
		}
		logger.debug("Mapper :: toProductImagesDTOs -- end");
		return productImagesDTOs;
	}

	/**
	 * toProductDTos
	 * 
	 *
	 * @param List<Product> products
	 * 
	 * @return List<ProductDTO>
	 */
	public List<ProductDTO> toProductDTOs(List<Product> products) {
		logger.debug("Mapper :: toProductDTOs -- begin");
		List<ProductDTO> productDispalyDTOs = new ArrayList<>();
		for (Product product : products) {
			productDispalyDTOs.add(toProductDTO(product));
		}
		logger.debug("Mapper :: toProductDTOs -- end");
		return productDispalyDTOs;
	}

	/**
	 * toProducts
	 * 
	 * @param List<ProductDTO> productsDTO
	 * 
	 * @return List<Product>
	 */
	public List<Product> toProducts(List<ProductDTO> productsDTOs) {
		logger.debug("Mapper :: toProducts -- begin");
		List<Product> product = new ArrayList<>();
		for (ProductDTO productDTO : productsDTOs) {
			product.add(toProduct(productDTO));
		}
		logger.debug("Mapper :: toProducts -- end");
		return product;
	}

	/**
	 * toProductImages
	 * 
	 * @param List<ProductImagesDTO> productImagesDTO
	 * 
	 * @return List<ProductImages>
	 */
	public List<ProductImages> toProductImages(List<ProductImagesDTO> productImagesDTO) {
		logger.debug("Mapper :: toProductImages -- begin");
		List<ProductImages> productImages = new ArrayList<>();
		for (ProductImagesDTO productImage : productImagesDTO) {
			productImages.add(ProductImages.build(productImage.getImageId(), null, productImage.getImgSrc(),
					productImage.getThumbnail(), null));
		}
		logger.debug("Mapper :: toProductImages -- end");
		return productImages;
	}

	/**
	 * toCategory
	 * 
	 * @param CategoryDTO categoryDTO
	 * 
	 * @return Category
	 */
	public Category toCategory(CategoryDTO categoryDTO) {
		logger.debug("Mapper :: toCategory -- begin");
		logger.debug("Mapper :: toCategory -- end");
		return Category.build(categoryDTO.getCategoryId(), categoryDTO.getCategoryName(),
				categoryDTO.getCategoryImgSrc(), null);

	}

	/**
	 * toCategoryDTO
	 * 
	 *
	 * @param Category category
	 * 
	 * @return CategoryDTO
	 */
	public CategoryDTO toCategoryDTO(Category category) {
		logger.debug("Mapper :: toCategoryDTO -- begin");
		logger.debug("Mapper :: toCategoryDTO -- end");
		return CategoryDTO.build(category.getCategoryId(), category.getCategoryName(), category.getCategoryImgSrc());

	}

	/**
	 * toAdresses
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * 
	 * @return List<Address>
	 */
	public List<Address> toAddresses(List<AddressDTO> addressDTOs) {
		logger.debug("Mapper :: toAddresses -- begin");
		List<Address> addresses = new ArrayList<>();
		for (AddressDTO addressDTO : addressDTOs) {
			Address address = Address.build(addressDTO.getAddressId(), null, addressDTO.getFirstName(),
					addressDTO.getLastName(), addressDTO.getPhone(), addressDTO.getAddress1(), addressDTO.getAddress2(),
					addressDTO.getZip(), addressDTO.getCity(), addressDTO.getCountry(), null);
			addresses.add(address);
		}
		logger.debug("Mapper :: toAddresses -- end");
		return addresses;
	}

	/**
	 * toAddressDTOs
	 * 
	 * @param List<AddressDTO> addressDTOs
	 * 
	 * @return List<Address>
	 */
	public List<AddressDTO> toAddressDTOs(List<Address> addresses) {
		logger.debug("Mapper :: toAddressDTOs -- begin");
		List<AddressDTO> addressDTOs = new ArrayList<>();
		for (Address address : addresses) {
			AddressDTO addressDTO = AddressDTO.build(address.getAddressId(), null, address.getFirstName(),
					address.getLastName(), address.getPhone(), address.getAddress1(), address.getAddress2(),
					address.getCity(), address.getZip(), address.getCountry(), null);
			addressDTOs.add(addressDTO);
		}
		logger.debug("Mapper :: toAddressDTOs -- end");
		return addressDTOs;
	}

	/**
	 * toReviewDTO
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public ReviewDTO toReviewDTO(Review review) {
		logger.debug("Mapper :: toReviewDTO -- begin");
		logger.debug("Mapper :: toReviewDTO -- end");
		return ReviewDTO.build(review.getReviewId(), review.getRating(), review.getTitle(), review.getReview(),
				review.getReviewDate(), null, null);
	}

	/**
	 * toReview
	 * 
	 * @param ReviewDTO reviewDTO
	 * 
	 * @return Review
	 */
	public Review toReview(ReviewDTO reviewDTO) {
		logger.debug("Mapper :: toReviewDTOs -- begin");
		LocalDateTime localDateTime = LocalDateTime.now();
		Date date = Date.valueOf(localDateTime.toLocalDate());
		logger.debug("Mapper :: toReview -- end");
		return Review.build(reviewDTO.getReviewId(), reviewDTO.getRating(), reviewDTO.getTitle(), reviewDTO.getReview(),
				date, null, null);
	}

	/**
	 * toReviewDTOs
	 * 
	 * @param List<Review> reviews
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<ReviewDTO> toReviewDTOs(List<Review> reviews) {
		logger.debug("Mapper :: toReviewDTOs -- begin");
		List<ReviewDTO> reviewDTOs = reviews.stream().map(item -> toReviewDTO(item)).collect(Collectors.toList());
		logger.debug("Mapper :: toReviewDTOs -- end");
		return reviewDTOs;
	}

	/**
	 * toReviews
	 * 
	 * @param Product product
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<Review> toReviews(List<ReviewDTO> reviewDTOs) {
		logger.debug("Mapper :: toReviews -- begin");
		List<Review> reviews = reviewDTOs.stream().map(item -> toReview(item)).collect(Collectors.toList());
		logger.debug("Mapper :: toReviews -- end");
		return reviews;
	}

	/**
	 * toCustomerRegistration
	 * 
	 *
	 * @param CustomerRegistrationDTO customerRegistrationDTO
	 * 
	 * @return CustomerRegistration
	 */
	public CustomerRegistration toCustomerRegistration(CustomerRegistrationDTO customerRegistrationDTO) {
		logger.debug("Mapper :: toCustomerRegistration -- begin");
		List<Address> addresses = toAddresses(customerRegistrationDTO.getAddressDTO());
		CustomerRegistration customerRegistration = CustomerRegistration.build(customerRegistrationDTO.getCustomerId(),
				customerRegistrationDTO.getFirstName(), customerRegistrationDTO.getLastName(),
				customerRegistrationDTO.getEmail(), null, addresses, null, null, null, null);
		logger.debug("Mapper :: toCustomerRegistration -- end");
		return customerRegistration;

	}

	/**
	 * toCustomerRegistrationDTO
	 * 
	 *
	 * @param CustomerRegistration customerRegistration
	 * 
	 * @return CustomerRegistrationDTO
	 */
	public CustomerRegistrationDTO toCustomerRegistrationDTO(CustomerRegistration customerRegistration) {
		logger.debug("Mapper :: toCustomerRegistrationDTO -- begin");
		List<AddressDTO> addressesDTOs = toAddressDTOs(customerRegistration.getAddress());
		CustomerRegistrationDTO customerRegistrationDTO = CustomerRegistrationDTO.build(
				customerRegistration.getCustomerId(), customerRegistration.getFirstName(),
				customerRegistration.getLastName(), customerRegistration.getEmail(), null, addressesDTOs, null);
		logger.debug("Mapper :: toCustomerRegistrationDTO -- end");
		return customerRegistrationDTO;

	}

	/**
	 * toProductEntity
	 * 
	 * @param ProductDTO productDTO
	 * 
	 * @return Product
	 */
	public Product toProduct(ProductDTO productDTO) {
		logger.debug("Mapper :: toProduct -- begin");
		Category category = toCategory(productDTO.getCategoryDTO());
		List<ProductImages> productImages = toProductImages(productDTO.getProductImagesDTOs());
		List<Review> reviews = toReviews(productDTO.getReviewDTOs());
		Product product = Product.build(productDTO.getProductId(), productDTO.getProductName(),
				productDTO.getProductDesc(), productDTO.getProductPrice(), productDTO.getStock(), category,
				productImages, null, productDTO.getWishlistflag(),productDTO.getRating() ,null, reviews, null);
		logger.debug("Mapper :: toProduct -- end");
		return product;
	}

	/**
	 * toProductDTO
	 * 
	 * @param Product product
	 * 
	 * @return Product
	 */
	public ProductDTO toProductDTO(Product product) {
		logger.debug("Mapper :: toProductDTO -- begin");
		CategoryDTO categoryDTO = toCategoryDTO(product.getCategory());
		List<ProductImagesDTO> productImagesDTOs = toProductImagesDTOs(product.getProductImages());
		List<ReviewDTO> reviewDTOs = toReviewDTOs(product.getReviews());
		ProductDTO productDTO = ProductDTO.build(product.getProductId(), product.getProductName(),
				product.getProductDesc(), product.getProductPrice(), product.getStock(), categoryDTO, productImagesDTOs,
				product.getWishlistflag(), product.getRating(),reviewDTOs);
		logger.debug("Mapper :: toProductDTO -- end");
		return productDTO;
	}
}
