package com.nveda.entities;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int productId;
	private String productName;
	private String productDesc;
	private Float productPrice;
	private int stock;
	@ManyToOne
	@JoinColumn(name="cat_id")
	private Category category;
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	private List<ProductImages> productImages;
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	private List<Wishlist> wishlist;
	private Boolean Wishlistflag;
	private Double rating;
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	private List<CartItem> carts;
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	private List<Review> reviews;
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	private List<OrderItem> orders;
	
	

}
