package com.nveda.repo;


import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.nveda.entities.Address;




@Repository
public interface AddressRepository extends JpaRepository<Address, Integer> {
	Address findByAddressId(int id);
	Address deleteAllByAddressId(int id);
	void deleteByAddressId(int id);
	
	@Query(value="select * from states",nativeQuery=true)
	List<String> getStates();

}
