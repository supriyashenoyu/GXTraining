package com.nveda.repo;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nveda.entities.CustomerRegistration;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerRegistration,Long> {

	@Query(value="select * from customer_registration where email=:email",nativeQuery=true)
	CustomerRegistration findByEmail(String email);


}
