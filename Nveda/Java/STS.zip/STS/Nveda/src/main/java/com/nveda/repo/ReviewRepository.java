package com.nveda.repo;






import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.nveda.entities.Review;
import jakarta.persistence.Tuple;
@Repository
public interface ReviewRepository extends JpaRepository<Review,Integer>{
	
	@Query(value="select count(*),AVG(rating)from review where product_id=:productId group by product_id ",nativeQuery=true)
	Tuple getRating( int productId);
	
	@Query(value="select * from review where product_id=:productId",nativeQuery=true)
	List<Review> getReviewsByProductId(int productId);
	

	
	
	  


}
