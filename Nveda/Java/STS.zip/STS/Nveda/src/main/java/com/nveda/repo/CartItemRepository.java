package com.nveda.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.nveda.entities.CartItem;

import jakarta.transaction.Transactional;
@Repository
public interface CartItemRepository extends JpaRepository<CartItem,Integer>{
	
	@Query(value="select * from cart_item where customer_id=:customerId",nativeQuery=true)
	List<CartItem> findByCustomerId( int customerId);
	
	@Query(value="select product_id from cart_item where customer_id=:customerId",nativeQuery=true)
    List<Integer> isPresentInCart( long customerId);
	
	@Transactional
	@Modifying
	@Query(value="update cart_item set quantity=:quantity,total_amount=:totalAmount where customer_id=:customerId and product_id=:productId",nativeQuery=true)
	void updateQuantity(long customerId ,int productId,int quantity,float totalAmount);
	
	@Query(value="select * from cart_item where product_id=:productId and customer_id=:customerId",nativeQuery=true)
	CartItem findByProductId(int productId, long customerId);
	
	@Transactional
	@Modifying
	@Query(value="delete from cart_item where customer_id=:customerId and product_id=:productId",nativeQuery=true)
	void deleteCartItem(long customerId,int productId);

}
