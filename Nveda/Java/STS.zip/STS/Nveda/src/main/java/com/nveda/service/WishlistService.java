package com.nveda.service;

import java.util.List;

import com.nveda.dto.WishlistDTO;

public interface WishlistService {
	String addToWishlist(WishlistDTO wishlistDTO);
	String setFlag(int customerId);
	String resetFlag(int customerId);
	String deleteFromWishlist(int customerId,int productId);
	List<WishlistDTO> getWishlistById(int customerId);

}
