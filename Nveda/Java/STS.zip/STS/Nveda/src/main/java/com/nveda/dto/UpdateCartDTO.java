package com.nveda.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class UpdateCartDTO {
	private long customerId;
	private int productId;
	private int quantity;
	private float totalAmount;

}
