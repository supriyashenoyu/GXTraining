package com.nveda.service;


import java.util.List;

import com.nveda.dto.CartItemDTO;
import com.nveda.dto.UpdateCartDTO;


public interface CartItemService {
	 String addToCart(CartItemDTO cartDTO);
	 List<CartItemDTO> getCart(int customerId);
	 String deleteFromCart(long customerId,int productId);
	 String updateCartQuantity(UpdateCartDTO updateCartDTO);
		

}
