package com.nveda.service;


import java.util.List;
import com.nveda.dto.OrderItemDTO;
import com.nveda.dto.UpdateCartDTO;


public interface OrderItemService {
	 String addToOrder(OrderItemDTO orderItemDTO);
	 List<OrderItemDTO> getOrder(int customerId);
	 String deleteFromCart(int customerId,int productId);
	 String updateCartQuantity(UpdateCartDTO updateCartDTO);
		

}
