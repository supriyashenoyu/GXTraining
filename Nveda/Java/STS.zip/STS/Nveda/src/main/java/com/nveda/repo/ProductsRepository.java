package com.nveda.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.nveda.entities.Product;

import jakarta.transaction.Transactional;
@Repository
public interface ProductsRepository extends JpaRepository<Product, Integer>{
	
	@Query(value="select * from product where product_id=:productId",nativeQuery=true)
	 Product findProductByProductId(int productId);
	
	@Query(value="select * from product where cat_id=:categoryId",nativeQuery=true)
	List<Product> getProductByCategory(int categoryId);
	
	@Query(value="select COUNT(product_id) from product where stock>0",nativeQuery=true)
	int inStockProducts();
	
	@Query(value="select COUNT(product_id) from product where stock=0",nativeQuery=true)
	int outOfStockProducts();
	@Transactional
	@Modifying
	@Query(value="update product set stock=?1 where product_id=?2",nativeQuery=true)
	void updateProductQuantity(int quantity,int productId);
	
	@Transactional
	@Modifying
	@Query(value="UPDATE product SET wishlistflag = 1 WHERE product_id In (select DISTINCT product_id from wishlist where customer_id=:customerId)",nativeQuery=true)
	void setFlag(int customerId);
	
	@Transactional
	@Modifying
	@Query(value="UPDATE product SET wishlistflag = 0 WHERE product_id not In (select DISTINCT product_id from wishlist  where customer_id=:customerId)",nativeQuery=true)
	void resetFlag( int customerId);
	
	@Transactional
	@Modifying
	@Query(value="UPDATE product SET compare_flag = 1 WHERE product_id=:productId",nativeQuery=true)
	void setCompare(int productId);
	
	@Transactional
	@Modifying
	@Query(value="UPDATE product SET compare_flag=0 WHERE product_id=:productId",nativeQuery=true)
	void resetCompare( int productId);
	
	@Query(value="select count(*) from product where compare_flag=1",nativeQuery=true)
	Integer countOfCompareItems();
	
	@Transactional
	@Modifying
	@Query(value="UPDATE product SET compare_flag=0",nativeQuery=true)
	void clearCompare();
	
	@Query(value="select compare_flag from product where product_id=:productId",nativeQuery=true)
	Integer checkCompare(int productId);
	
	@Query(value="select * from product where compare_flag=1",nativeQuery=true)
	List<Product> getCompare();
	
	@Transactional
	@Modifying
	@Query(value="update product set rating=:rating where product_id=:productId",nativeQuery=true)
	void updateRating(Double rating,int productId );
	
	@Transactional
	@Modifying
	@Query(value="UPDATE product SET wishlistflag = 0",nativeQuery=true)
	void clearWishlistFlag();

	
	
	

	

}
