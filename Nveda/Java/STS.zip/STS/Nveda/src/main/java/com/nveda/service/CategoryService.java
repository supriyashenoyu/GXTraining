package com.nveda.service;

import java.util.List;

import com.nveda.dto.CategoryDTO;

public interface CategoryService {
	List<CategoryDTO> getAllCategory() ;

}
