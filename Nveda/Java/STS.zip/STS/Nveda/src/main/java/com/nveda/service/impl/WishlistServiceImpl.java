package com.nveda.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nveda.dto.CustomerRegistrationDTO;
import com.nveda.dto.ProductDTO;
import com.nveda.dto.WishlistDTO;
import com.nveda.entities.CustomerRegistration;
import com.nveda.entities.Product;
import com.nveda.entities.Wishlist;
import com.nveda.mapper.Mapper;
import com.nveda.repo.ProductsRepository;
import com.nveda.repo.WishlistRepository;
import com.nveda.service.WishlistService;

@Service
public class WishlistServiceImpl implements WishlistService {
	@Autowired
	WishlistRepository wishlistRepository;
	@Autowired
	ProductsRepository productRepository;
	@Autowired
	Mapper mapper;
	private static Logger logger = LogManager.getLogger(WishlistServiceImpl.class);



	/**
	 * addToWishlist
	 * 
	 *
	 * @param WishlistDTO wishlistDTO
	 * 
	 * @return String
	 */
	public String addToWishlist(WishlistDTO wishlistDTO) {
		logger.debug("WishlistServiceImpl :: addToWishlist -- begin");
		CustomerRegistration customerRegistration =mapper.toCustomerRegistration(wishlistDTO.getCustomerRegistrationDTO());
		Product product = mapper.toProduct(wishlistDTO.getProductDTO());
		Wishlist list = Wishlist.build(wishlistDTO.getWishlistId(), customerRegistration, product);
		wishlistRepository.save(list);
		logger.debug("WishlistServiceImpl :: addToWishlist -- end");
		return "added to wishlist";
	}

	/**
	 * setFlag
	 * 
	 * @return String
	 */
	public String setFlag(int customerId) {
		logger.debug("WishlistServiceImpl :: setFlag -- begin");
		productRepository.setFlag(customerId);
		logger.debug("WishlistServiceImpl :: setFlag -- end");
		return "flag set";
	}

	/**
	 * setFlag
	 * 
	 * @return String
	 */
	@Override
	public String resetFlag(int customerId) {
		logger.debug("WishlistServiceImpl :: resetFlag -- begin");
		productRepository.resetFlag(customerId);
		logger.debug("WishlistServiceImpl :: resetFlag -- end");
		return "flag reset";
	}

	/**
	 * getWishlistById
	 * 
	 * @param Integer customerId
	 * 
	 * @return List<WishlistDTO>
	 */
	public List<WishlistDTO> getWishlistById(int customerId) {
		logger.debug("WishlistServiceImpl :: getWishlistById -- begin");
		List<Wishlist> wishlists = wishlistRepository.findByCustomerRegistration(customerId);
		List<WishlistDTO> wishlistDTOs = new ArrayList<>();
		for (Wishlist wishlist : wishlists) {
			CustomerRegistrationDTO customerRegistrationDTO = mapper.toCustomerRegistrationDTO(
					wishlist.getCustomerRegistration());
			ProductDTO productDTO = mapper.toProductDTO(wishlist.getProduct());
			wishlistDTOs.add(WishlistDTO.build(wishlist.getWishlistId(), customerRegistrationDTO, productDTO));

		}
		logger.debug("WishlistServiceImpl :: getWishlistById -- end");
		return wishlistDTOs;
	}

	/**
	 * deleteFromWishlist
	 * 
	 * @param Integer productId
	 * 
	 * @return String
	 */
	public String deleteFromWishlist(int customerId, int productId) {
		logger.debug("WishlistServiceImpl :: deleteFromWishlist -- begin");
		wishlistRepository.deleteByProductId(customerId, productId);
		logger.debug("WishlistServiceImpl :: deleteFromWishlist -- end");
		return "deleted";

	}

}
