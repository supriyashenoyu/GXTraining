package com.nveda.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class Wishlist {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int wishlistId;
	@ManyToOne
	@JoinColumn(name="customerId")
	private CustomerRegistration customerRegistration;
	@ManyToOne
	@JoinColumn(name="productId")
	private Product product;

}
