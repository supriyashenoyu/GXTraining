package com.nveda.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nveda.controller.ProductController;
import com.nveda.dto.AddressDTO;
import com.nveda.entities.Address;
import com.nveda.entities.CustomerRegistration;
import com.nveda.repo.AddressRepository;
import com.nveda.repo.CustomerRepository;
import com.nveda.service.AddressService;

import jakarta.transaction.Transactional;

@Service
public class AddressServiceImpl implements AddressService {
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	AddressRepository addressRepository;
	private static Logger logger = LogManager.getLogger(ProductController.class);
	/**
	 * updateAddress
	 * 
	 * @param AddressDTO addressDTO
	 * @return String
	 */

	public String updateAddress(AddressDTO addressDTO) {
		logger.debug("AddressServiceImpl :: updateAddress -- begin");
		CustomerRegistration customerRegistration = customerRepository.findByEmail(addressDTO.getEmail());
		int id = addressDTO.getAddressId();
		Address addressById = addressRepository.findByAddressId(id);
		Address address = Address.build(id, addressDTO.getFirstName(), addressDTO.getLastName(), addressDTO.getPhone(),
				addressDTO.getAddress1(), addressDTO.getAddress2(), addressDTO.getProvince(), addressDTO.getZip(),
				addressDTO.getCity(), addressDTO.getCountry(), customerRegistration);
		addressById.setFirstName(address.getFirstName());
		addressById.setLastName(address.getLastName());
		addressById.setPhone(address.getPhone());
		addressById.setAddress1(address.getAddress1());
		addressById.setAddress2(address.getAddress2());
		addressById.setProvince(address.getProvince());
		addressById.setZip(address.getZip());
		addressById.setCity(address.getCity());
		addressById.setCountry(address.getCountry());
		addressRepository.save(addressById);
		logger.debug("AddressServiceImpl :: updateAddress -- end");
		return "updated";
	}

	/**
	 * addAddress
	 *
	 * @param AddressDTO addressDTO
	 * @return String
	 */
	@Transactional
	public String addAddress(AddressDTO addressDTO) {
		logger.debug("AddressServiceImpl :: addAddress -- begin");
		CustomerRegistration customerRegistration = customerRepository.findByEmail(addressDTO.getEmail());
		List<Address> addreses = customerRegistration.getAddress();
		Address address = Address.build(0, addressDTO.getFirstName(), addressDTO.getLastName(), addressDTO.getPhone(),
				addressDTO.getAddress1(), addressDTO.getAddress2(), addressDTO.getProvince(), addressDTO.getZip(),
				addressDTO.getCity(), addressDTO.getCountry(), customerRegistration);
		addreses.add(address);
		customerRegistration.setAddress(addreses);
		customerRepository.save(customerRegistration);
		logger.debug("AddressServiceImpl :: addAddress -- end");
		return "added";
	}

	/**
	 * deleteAddress
	 *
	 * @param integer id
	 * @return String
	 */
	public String deleteAddress(int id) {
		logger.debug("AddressServiceImpl :: deleteAddress -- begin");
		addressRepository.deleteById(id);
		logger.debug("AddressServiceImpl :: deleteAddress -- end");
		return "deleted";

	}

	/**
	 * getStates
	 *
	 * @return List<String>
	 */

	public List<String> getStates() {
		logger.debug("AddressServiceImpl :: getStates -- begin");
		logger.debug("AddressServiceImpl :: getStates -- end");
		return addressRepository.getStates();
		
	}

}
