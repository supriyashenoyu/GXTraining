package Practice;

public class Hostellers extends Stu{
	int roomNo;

	public Hostellers(String name, int rollNo, String section, int cat,int roomNo ) {
		super(name, rollNo, section, cat);
		this.roomNo=roomNo;
		// TODO Auto-generated constructor stub
	}
	

}
