import logo from './logo.svg';
import './App.css';
//import { Counter } from './Counter';
import ShoppingCart from './BBRAssignment/ShoppingCart';
import { Asgn1 } from './BBRAssignment/Asgn1';
import { Greeting } from './BBRAssignment/Asgn2'
import Counter  from './BBRAssignment/Asgn3'
import { TempConvertor}  from './BBRAssignment/Asgn4'
import {Parent} from './BBRAssignment/Asgn5'
import LoginController from './BBRAssignment/Asgn6'
import { Assignment1 } from './HooksAssignment/Assignment1';
import MyContext from './HooksAssignment/MyContext'
import {useState} from 'react'
import { Assignment2 } from './HooksAssignment/Assignment2';
import { Assignment3 } from './HooksAssignment/Assignment3';
import { Calculator } from './HooksAssignment/Assignment4';
import  {Assignment5 } from './HooksAssignment/Assignment5';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import "bootstrap/dist/js/bootstrap.bundle.min";


function App() {

 
  return (
    <div className="App">
     {/* <Counter/> */}
      <ShoppingCart/> 
      {/* <Asgn1/>
      <Greeting name="Supriya"/>
      <Counter/>
      <TempConvertor/>
      <Parent/>
      <LoginController/> */}
     
      <Assignment1/>
      <Assignment2/>
      <Assignment3 data={['a','b','cd']}/>
      <Calculator />
      <Assignment5/>
      
    </div>
  );
}

export default App;
