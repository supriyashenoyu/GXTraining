import { useState} from 'react'
import React from 'react'

export const TempConvertor = () => {
  const [cel, setCelsius] = useState();
  const [far, setFar] = useState();
  return (
    <div>
     <label>Fahrenheit</label>
      <input
    
        placeholder="Enter a value in farenheit"
        value={far}
        onChange={(event) => {
            let val=event.target.value
        setCelsius(val - 32 * (5 / 9));
        }}
      />
      <label>Celsius</label>
      <input
      
        placeholder="Enter a value in celsius"
        value={cel}
        onChange={(event) => {
            let val1=event.target.value
        setFar(val1 * (9 / 5) + 32);
        }}
      />
    </div>
  );
}


