import { useReducer, useState } from "react";

const cartReducer = (state, action) => {
  switch (action.type) {
    case "ADD_TO_CART":
      return {
        cart: state.cart.concat({ name: action.name, price: action.price }),
      };
    case "REMOVE_FROM_CART":
      return { cart: state.cart.filter((item) => item.name !== action.name) };
    default:
      return state;
  }
};


const initialState = {
  cart: [
    {
      name: "",
      price: null,
    },
  ],
}
const ShoppingCart = () => {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  // let item, itemOne;

  const [item, setItem] = useState("")
  const [itemOne, setItemOne] = useState("")

  let HoldItem = (event) => {
    setItem(event.target.value);
   
  };

  let HolditemOne = (event) => {
    setItemOne(event.target.value);
  };
 
  console.log(item)
  return (
    <div>
      <h1>ShoppingCart</h1>
      <div style={{ display: "flex" }}>
        <input
          placeholder="Enter an item"
          value={item}
          onChange={HoldItem}
          style={{ position: "relative", left: "450px", top: "10px" }}
        ></input>
        <br></br>
        <input
          placeholder="Enter the price"
          value={itemOne}
          onChange={HolditemOne}
          style={{ position: "relative", left: "510px", top: "10px" }}
        ></input>
        <br></br>
      </div>
      <div style={{ display: "flex" }}>
        <button
          onClick={() => {
            setItem("");
            setItemOne("");
            dispatch({ type: "ADD_TO_CART", name: item, price: itemOne, payload: "" });
          }}
          style={{ position: "relative", left: "450px", top: "20px" }}
        >
          ADD TO CART
        </button>
        <br></br>
        <button
          onClick={() => {
            dispatch({ type: "REMOVE_FROM_CART", name: item });
          }}
          style={{ position: "relative", left: "575px", top: "20px" }}
        >
          REMOVE FROM CART
        </button>
      </div>
      <br></br>
      {state.cart.map((x) => (
        <p style={{ display: "flex" }}>
          <span style={{ position: "relative", left: "600px", top: "20px" }}>
            {x.name}
          </span>
          <span style={{ position: "relative", left: "650px", top: "20px" }}>
            {x.price}
          </span>
        </p>
      ))}
    </div>
  );
};
export default ShoppingCart;
