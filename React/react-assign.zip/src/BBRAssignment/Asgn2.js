import React from 'react'

export const Greeting = (props) => {
  return (
    <div>Welcome {props.name}, to react sessions</div>
  )
}
