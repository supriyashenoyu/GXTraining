import { useReducer } from "react";

 const cartReducer = (state, action) => {
    switch (action.type) {
      case "ADD_TO_CART":
        return { cart:state.cart.action.value};
      case "REMOVE_FROM_CART":
        return {
        };
      default:
        return state.cart;
    }
  };
  var items=["apple","banana","orange"]
const ShoppingCart=()=>{
    const [state,dispatch]=useReducer(cartReducer,{

    });
    let HoldItem=(event)=>{
        let item =event.value;
    }
    return(
        <div>
            <h1>ShoppingCart</h1>
            <input placeholder="Enter an item" onChange={HoldItem}></input>
            <br></br>
            <button onClick={()=>{dispatch({type:"ADD_TO_CART"});}}>Item 1</button>
            <br></br>
            <button onClick={()=>{dispatch({type:"ADD_TO_CART"});}}>Item 2</button>
            <br></br>
            {state.cart &&<p>{items}</p>}
        </div>
    )


}
export default ShoppingCart