import React, { useState, useEffect } from "react";
import swal from "react";

const CountDownTimer = () => {
  const [timeRemaining, setTimeRemaining] = useState();
  const [show, setShow] = useState();
  const [visible,setVisible]=useState();
  let pause, timerId;

    useEffect(() => {
      if (timeRemaining < 1) {
      alert('Please Enter Valid time in seconds(s)')
    //   Swal.fire({
    //     title: "Timer Alert!",
    //     text: "Please Enter Valid time in seconds!",
    //     icon: "failure"
    //   });
        return;
      }if(show===true){
       timerId = setInterval(() => {
        setTimeRemaining((prevTime) => prevTime - 1);
    }, 1000);
    }

      return () => {
        clearInterval(timerId); //The setInterval() method calls a function at specified intervals (in milliseconds). The setInterval() method continues calling the function until clearInterval() is called, or the window is closed.
      };

    }, [timeRemaining][show]);

  function HandleInput(event) {
    setTimeRemaining(event.target.value);
  }
  function Start() {
    if (timeRemaining < 1) {
      alert("Please Enter Valid time in seconds(s)");
      
      return;
    }
    setShow(true);
    setVisible(true)
    

    if (pause >= 0) {
      setInterval(() => {
        setTimeRemaining((pause) => pause - 1);
      }, 1000);
    }
    return () => {
      clearInterval(timerId); //The setInterval() method calls a function at specified intervals (in milliseconds). The setInterval() method continues calling the function until clearInterval() is called, or the window is closed.
    };
  }
  function Pause() {
    setShow(false);
    pause = timerId;
    
  }

  return (
    <div>
      <h2>Timer  Level-1</h2>
      <input placeholder="Enter time in seconds" onChange={HandleInput}></input>
      <br></br>
      <button onClick={Start}>Start</button>
      <button onClick={Pause}>Pause</button>
      {visible && <p>{timeRemaining}</p>}
    </div>
  );
};

export default CountDownTimer;
