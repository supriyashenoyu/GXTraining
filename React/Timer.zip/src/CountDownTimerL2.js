import React, { useState, useEffect } from "react";
import swal from "react";

const CountDownTimer2 = () => {
  const [timeRemaining, setTimeRemaining] = useState();
  const [show, setShow] = useState();
  const [run, setRun] = useState(false);
  const [visible, setVisible] = useState();
  let pause, timerId;

  useEffect(() => {
    if (timeRemaining < 1) {
      alert("Please Enter Valid time in seconds(s)");
      //   Swal.fire({
      //     title: "Timer Alert!",
      //     text: "Please Enter Valid time in seconds!",
      //     icon: "failure"
      //   });
      return;
    }
    if (show === true) {
      timerId = setInterval(() => {
        setTimeRemaining((prevTime) => prevTime - 1);
      }, 1000);
    }

    return () => {
      clearInterval(timerId); //The setInterval() method calls a function at specified intervals (in milliseconds). The setInterval() method continues calling the function until clearInterval() is called, or the window is closed.
    };
  }, [timeRemaining][show]);

  function Counter(props) {
    //const run=props.IsRunning;
    setRun(props.IsRunning);
    if (run) {
       <Star></Star>;
    }
     <Paus></Paus>;
  }
  function Star(props) {
    return <button onClick={props.onClick}>Start</button>;
  }
  function Paus(props) {
    return <button onClick={props.onClick}>Pause</button>;
  }

  function HandleInput(event) {
    setTimeRemaining(event.target.value);
  }
  function handleStarClick() {
    setRun(true);
    Start();
    //const run=true;
  }
  function handlePausClick() {
    const run=false;
    Pause();
    setRun(false);
  }
  function Start() {
    if (timeRemaining < 1) {
      alert("Please Enter Valid time in seconds(s)");
      return;
    }
    setShow(true);
    setVisible(true);
    setRun(true);
    if (pause >= 0) {
      setInterval(() => {
        setTimeRemaining((pause) => pause - 1);
      }, 1000);
    }
    return () => {
      clearInterval(timerId); //The setInterval() method calls a function at specified intervals (in milliseconds). The setInterval() method continues calling the function until clearInterval() is called, or the window is closed.
    };
  }
  function Pause() {
    setShow(false);
    pause = timerId;
    setRun(false);
  }
  //setRun(true);
  const isrunning = run;
  let button;
  if (isrunning) {
    button = (<Paus onClick={() => handlePausClick()}></Paus>);
  } else {
    button =( <Star onClick={() => handleStarClick()}></Star>);
  }
  return (
    <div>
      <h2>Timer Level-2</h2>
      <input placeholder="Enter time in seconds" onChange={HandleInput}></input>
      <br></br>
      <Counter IsRunning={isrunning}></Counter>
      {visible && <p>{timeRemaining}</p>}
      {button}

      {/* <button onClick={Start}>Start</button>
      <button onClick={Pause}>Stop</button>
      {visible && <p>{timeRemaining}</p>} */}
    </div>
  );
};

export default CountDownTimer2;
