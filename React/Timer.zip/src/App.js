import logo from './logo.svg';
import './App.css';
import CountDownTimer from './CountDownTimer';
import CountdownTimer3 from './CountDownTimerL3';
import CountDownTimer2 from './CountDownTimerL2';
import CountDownTimer4 from './CountDownTimer4';
import Test from './Test';


function App() {
  return (
    <div className="App">
     <CountDownTimer/>
     <CountDownTimer2/>
     <CountdownTimer3/>
     <CountDownTimer4/>
     {/* <Test/> */}
   
    </div>
  );
}

export default App;
