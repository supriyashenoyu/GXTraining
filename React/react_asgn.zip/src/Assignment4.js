import React from "react";
import { useState, useRef, useMemo, useContext } from "react";


export const Calculator = () => {
  const [num, setNum] = useState({
    one: '',
    two: '',
    op: '',
   
  });
  const [vis,setVis]=useState(false);
  


  const Calculate = () => {
    switch (num.op) {
      case "+":
        return num.one + num.two;
        break;
      case "-":
        return num.one - num.two;
        break;
      case "*":
        return num.one * num.two;
        break;
      case "/":
        return num.one / num.two;
        break;
      default:
        return 0;
    }
  };
  const handleNum1Change = (event) => {
    setNum({ ...num, one:parseFloat(event.target.value) })
  };

  const handleNum2Change = (event) => {
    setNum({ ...num, two: parseFloat(event.target.value) })
  };

  const handleOperatorChange = (event) => {
    setNum({ ...num, op: (event.target.value)});
    setVis(true)
  };

  const resValue = useMemo(() => {
    return Calculate();
  }, [num]);

  return (
    <div style={{border:"3px solid black",backgroundColor:"pink"}}>
      <h2>Calculator</h2>
      <div>
        <input
          type="number"
          value={num.one}
          placeholder="number1"
          onChange={(event)=>{handleNum1Change(event)}}
        />
        <input
          type="number"
          value={num.two}
          placeholder="number2"
          onChange={(event)=>{handleNum2Change(event)}}
        />
      </div>
      {/* <label>
        Select Operation:
        <select value={num.op} onChange={(event)=>{handleOperatorChange(event)}}>
          <option value="+">+</option>
          <option value="-">-</option>
          <option value="*">*</option>
          <option value="/">/</option>
        </select>
      </label> */}
      <button value="+" onClick={(event)=>{handleOperatorChange(event)}}>+</button>
      <button value="/"  onClick={(event)=>{handleOperatorChange(event)}}>/</button>
      <button  value="-" onClick={(event)=>{handleOperatorChange(event)}}>-</button>
      <button  value="*" onClick={(event)=>{handleOperatorChange(event)}}>*</button>
      {vis? <p>{resValue}</p>:null}
    </div>
  );
};
