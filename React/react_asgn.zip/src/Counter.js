const { useState } = require("react")

export const Counter=()=>{
    const [count,IncrCnt]=useState(0);
    return(
        <div>
            {count}
            <button onClick={()=>{IncrCnt((val)=>val+1)}}>Increment</button>
        </div>
    )
}
 