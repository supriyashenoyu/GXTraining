import React from 'react'
import {useRef,useState,useEffect} from 'react'
export const Assignment2 = () => {
    const name=useRef();
    const mail=useRef();
    const pass=useRef();
    const [names, setName] = useState('');
    const [email, setMail] = useState('');
    const [passw, setPass] = useState('');
   
    const [error,setError]=useState({
        name:"",
        email:"",
        pass:""
    })
    const ValidName=()=>{                       //Validating Name
        setName(name.current.value)
        const nameRegex = /^[a-zA-Z\. ]+$/i;
        if (!nameRegex.test(names)) {
            setError({...error,name:"Please enter a valid name"})
        } else {
            setError('');
        }
    }
    const ValidEmail=()=>{
        setMail(mail.current.value)
        const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/i;
        if (!emailRegex.test(email)) {
            setError({...error,email:"Please enter a valid email"})
        } else {
            setError('');
        }
    }
    const ValidPass=()=>{
        setPass(pass.current.value)
        const passRegex = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/i;
        if (!passRegex.test(passw)) {
            setError({...error,pass:"Please enter a valid password"})
        } else {
            setError('');
        }
    }
   
  return (
    <div style={{border:"3px solid black",backgroundColor:"red"}}>
    <h2>Form</h2>
    <form >
        <label>Name</label>
      
        <input placeholder='Enter your name' ref={name} onChange={ValidName.bind(this,name)} required='true'></input>{error.name}
        <br/>
        <label>Email</label>
        <input placeholder='Enter your EmailId' ref={mail} onChange={ValidEmail.bind(this,mail)} required='true'></input>{error.email}
        <br/>
        <label>Password</label>
        <input placeholder='Enter a Valid Passsword' ref={pass} onChange={ValidPass.bind(this,pass)} required='true' ></input>{error.pass}
        <br/>
        <button type="submit">Submit</button>

    </form>
    </div>
  )
}
