import React from 'react'
import { useCallback,useState } from 'react';

export const Assignment3 = (props) => {
    const [list, setList] = useState(props.data);
    const [name, setName] = useState("");

    function handleChange(event) {
      setName(event.target.value);
      console.log("evnt called")
    }
    const addList = useCallback(() => {
        console.log("callback rendered")
        const newList = list.concat( name );
        setList(newList);
  }, [name]);
  return (
    <div style={{border:"3px solid black",backgroundColor:"yellow"}}><h2>My List</h2>
    {list.map((x) => {
        return <p>{x}</p>;
      })}
      
      <input type="text" value={name} onChange={handleChange} />
      <button onClick={()=>{addList();setName("")}}>Add to list</button>
      </div>
  );
}
