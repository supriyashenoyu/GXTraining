import logo from './logo.svg';
import './App.css';
//import { Counter } from './Counter';
import ShoppingCart from './ShoppingCart';
import { Asgn1 } from './Asgn1';
import { Greeting } from './Asgn2'
import Counter  from './Asgn3'
import { TempConvertor}  from './Asgn4'
import {Parent} from './Assign4'
import LoginController from './Asgn6'
import { Assignment1 } from './Assignment1';
import MyContext from './MyContext'
import {useState} from 'react'
import { Assignment2 } from './Assignment2';
import { Assignment3 } from './Assignment3';
import { Calculator } from './Assignment4';
import  {Assignment5 } from './Assignment5';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import "bootstrap/dist/js/bootstrap.bundle.min";


function App() {

 
  return (
    <div className="App">
      {/* <Counter/>
      <ShoppingCart/> */}
      {/* <Asgn1/>
      <Greeting name="Supriya"/>
      <Counter/>
      <TempConvertor/>
      <Parent/>
      <LoginController/> */}
     
      <Assignment1/>
      <Assignment2/>
      <Assignment3 data={['a','b','cd']}/>
      <Calculator />
      <Assignment5/>
      
    </div>
  );
}

export default App;
