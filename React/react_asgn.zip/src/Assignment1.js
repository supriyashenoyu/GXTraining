

import React from 'react'
import {useContext,useState} from 'react'
import MyContext from './MyContext'

export const Assignment1 = () => {
    const [theme,setTheme]=useState(false)
  
    const backg = {
        "backgroundColor" : theme? "black" : "white"
    }
    
    
   
   
  return (
    <div style={backg} >
        <p>Parent</p>
        <button onClick={()=>{setTheme(!theme)}}>Toggle</button> 
         <MyContext.Provider value={{theme,setTheme}}>
            <Child />
         </MyContext.Provider>
    </div>
    );

   
  
}

const Child=()=>{
    const {theme,setTheme}=useContext(MyContext);
    return(
        <div><p>Child</p>
        <button onClick={()=>{setTheme(!theme)}}>Toggle</button>
        </div>
    )
    }
    
