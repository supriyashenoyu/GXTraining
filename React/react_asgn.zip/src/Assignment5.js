import React from "react";
import { useState, useEffect } from "react";
import Table from 'react-bootstrap/Table'
export const Assignment5 = () => {
  const [data, setData] = useState([]);
  const [time, setTime] = useState(false);
  const [err, setErr] = useState(false);
  const fetchData = () => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        return response.json();
      })
      .then((Resdata) => {
        setData(Resdata);
      })
      .catch((error) => {
        //alert("Caught an Unexpected error");
        setErr(true)
      });
  };
  useEffect(() => {
    setTimeout(() => {
      fetchData();
      setTime(true);
    }, 2000);
  }, [time]);

  return (
    <div style={{border:"3px solid black",backgroundColor:"cyan"}}>
    <h2>Fetch API</h2>
    
    {time?
  
     <Table striped bordered hover>
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Username</th>
            <th scope="col">Email</th>
          </tr>
        </thead>
        <tbody>
        {data.map((item)=>{ return(
          <tr>
          <td>{item.id}</td>
          <td>{item.name}</td>
          <td>{item.username}</td>
          <td>{item.email}</td>
          </tr>)
        })}
        </tbody>
</Table> 
    :err?<h3>Error Loading Page</h3>:<h3>Loading....</h3>}</div>
  );
};
