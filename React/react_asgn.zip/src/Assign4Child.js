const Child = (props) => {
    return (
      <div>Child{props.msg}</div>
    )
  }

export default Child