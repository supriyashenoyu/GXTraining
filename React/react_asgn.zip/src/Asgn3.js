import {Component } from 'react'
 class Counter extends Component{
    constructor(props){
        super(props);
        this.IncrCnt=this.IncrCnt.bind(this)
        this.state={
            counter:0
        }
    }
    IncrCnt=()=>{
        this.setState({counter:this.state.counter+1});

    }
    render(){
    return(
        <div>{this.state.counter}
        {/* <button onClick={()=>this.IncrCnt()}>Increment</button> */}
       <button onClick={this.IncrCnt}>Increment</button>
        </div>
    );
    }
    
 }
 export default Counter