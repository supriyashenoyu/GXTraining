import React from 'react'
import { Component } from 'react';


export class Parent extends Component{
    constructor(){
        super();
        this.state={
            msg:"Hi I am Parent",
        }
    }
    render(){
        return(
            <div>
                <Child msg = {this.state.msg}/>
            </div>
        )
    }
}
const Child = (props) => {
    return (
      <div>Child--{props.msg}</div>
    )
  }

