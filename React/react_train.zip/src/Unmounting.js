import {Component} from 'react'
import {Child2} from './BasicComponenet'
class Unmounting extends Component{
   constructor(){
   super()
   this.state = {
          count:0,
          display:"true",
          data:{
           name:"suppi",
           address:"udupi"
          }
       }
       console.log("Constructor")
       
   }
   updateVal(){
       console.log(this.state.count);
       this.setState({
           count:this.state.count+1,dispaly:!this.state.dispaly
       });
   }
   render(){
       return(
           <div>
           <div>{this.props.name}</div>
           <div>{this.state.count}</div>
               <button onClick={()=>this.updateVal()}>Click</button>
               {(this.state.display)?<Child2 count={this.state.count} updateVal={this.updateVal.bind(this)}/>:null}
           </div>
       )
   }
}
export default Unmounting