import React from 'react'
import  {Button}  from 'react-bootstrap'
import Alert from 'react-bootstrap/Alert'

export const Style = () => {
  return (
    <div>Style<Button className='mt-2'>click here</Button>
      <Alert key='primary' variant='primary'>
          This is a alert—check it out!
        </Alert></div>
  )
}
