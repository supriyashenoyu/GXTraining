import React from 'react'
import {useState,useMemo,useEffect} from 'react'

const slowFunctionRender=(num)=>{
    for(let index=0;index<1000000;index++){
        console.log("Inside slow function")
        return num*2;
    }
}
    const MemoDemo=()=>{
        const[number,setNumber]=useState(0);
        const[dark,setDark]=useState(false);
     
        const doubleValue = useMemo(()=>{
            return slowFunctionRender(number)
        },[number])
        const themeStyle=useMemo(()=>{
            return{
                backgroundColor:dark?"black":"white",
                color:dark?"white":"black"
            }
        },[dark])

        useEffect(()=>{
            console.log("I am being rendered")
        })
     return(<div>
        <input type='number' value={number}
        onChange={(e)=>{
            setNumber(parseInt(e.target.value))
        }}/>
        <button onClick={()=>{setDark(!dark)}}>Toggle Theme</button>
        <div style={themeStyle}>{doubleValue}</div>
     </div>);

}
export default MemoDemo