import React from 'react'
import { useState } from 'react'

export const Todo = () => {
    const [list,setList]=useState([])
    const [input,setInput]=useState('')
    function HandleInputChange(event){
        setInput(event.target.value)
    }
    function HandleSubmit(){
        // if (input.trim()) {
        //     setList([...list, input.trim()]);
        //     setInput('');
        //   }
        setList([...list,input])
        setInput('')
    }
    function HandleDelete(index){
      
        setList(list.filter((_,i) => i!==index ))
        
    }
  return (
       <ul>
        <input placeholder='Enter item'value={input} onChange={HandleInputChange}/>
        <button onClick={HandleSubmit}>Add Item</button>
     

        {/* {list.map((todo, index) => (
          <li key={index}>
            {todo}
            <button onClick={() => HandleDelete(index)}>Delete</button>
          </li>
        ))} */}
           { list.map((item,index) => (
                <li key={index}>{item}
                <button onClick={()=>HandleDelete(index)}>X</button></li>
                
            ))}
        </ul>
    
  )
}
