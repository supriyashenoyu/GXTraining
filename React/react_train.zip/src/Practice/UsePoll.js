import React, { useCallback, useEffect, useState } from "react";

export function usePoll<T, E>(
  url: string,
  fetcher: (url: string) => Promise<T>,
  refreshInterval: number
) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<E | null>(null);
  const [isPolling, setIsPolling] = useState(true);

  const trigger = useCallback(() => {
    fetcher(url)
      .then((data) => setData(data))
      .catch((error) => setError(error));
  }, [fetcher, url]);

  useEffect(() => {
    let intervalId;
    if (isPolling) {
      intervalId = setInterval(trigger, refreshInterval);
    } else {
      clearInterval(intervalId);
    }
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [isPolling, trigger, refreshInterval]);

  const stop = () => {
    setIsPolling(false);
  };

  const start = () => {
    setIsPolling(true);
  };

  return { data, error, start, trigger, stop, running: isPolling };
}
