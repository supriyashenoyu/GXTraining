import React, { useState, useEffect } from 'react';

const CountdownTimer = ({ initialValue }) => {
  const [timeRemaining, setTimeRemaining] = useState(initialValue);

  useEffect(() => {
    if (timeRemaining <= 0) {
      return;
    }

    const timerId = setInterval(() => {
      setTimeRemaining((prevTime) => prevTime - 1);
    }, 1000);

    return () => {
      clearInterval(timerId); //The setInterval() method calls a function at specified intervals (in milliseconds). The setInterval() method continues calling the function until clearInterval() is called, or the window is closed.
    };
  }, [timeRemaining]);

  return (
    <div>
      <p>Time Remaining: {timeRemaining}</p>
    </div>
  );
};

export default CountdownTimer;
