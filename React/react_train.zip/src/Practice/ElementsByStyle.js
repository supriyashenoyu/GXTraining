/**
 * @param {string} property
 * @param {string} value
 * @returns {HTMLElement[]}
 */
export function getElementsByStyle(property, value) {
    const elements = [];
    const stack = [document.body];
  
    while (stack.length) {
      const current = stack.pop();
  
      if (current.children.length) {
        stack.push(...current.children);
      }
  
      const styles = getComputedStyle(current);
  
      if (styles[property] === value) {
        elements.push(current);
      }
    }
  
    return elements;
  }
  
  /*
   * You can use the runner function to test your
   * solution before submitting it to the platform.
   */
  export const runner = () => {
    const div = document.createElement("div");
  
    div.style.color = "rgb(255, 255, 255)";
    div.style.textAlign = "center";
  
    document.body.appendChild(div);
  
    const elements = getElementsByStyle("color", "rgb(255, 255, 255)");
  
    console.log(elements);
  };
  