 
 export function CalculateTotal(array){
    let sum=array.reduce((s, cost) => s=s+cost);
    return sum;
        
    }

