export const StudentInfo=[{
    name:"suppi",
    age:"22",
    grade:"A",
},
{
    name:"aksu",
    age:"22",
    grade:"A",
},
{
    name:"trish",
    age:"22",
    grade:"A",
},
{
    name:"pooja",
    age:"22",
    grade:"A",
},
{
    name:"rambo",
    age:"22",
    grade:"B",
}]


 