import React from 'react'
import {useRef} from 'react'
export const UseRefDemo = () => {
    const inputRef=useRef("");
  return (
    <div><input type="text" ref={inputRef}></input>
    <button onClick={()=>{console.log(inputRef);inputRef.current.focus();
    inputRef.current.value=""}}> changeInput</button></div>
  )
}

