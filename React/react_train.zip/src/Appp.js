const temp=()=>{
    return(<p>temp function</p>);
}
