import { Component } from "react";
class WelcomeClass extends Component {
    constructor(props){
        super(props);
        this.state={
            count:0,
            firstName:"suppi",
            company:"gx",
        };
        
    }
    updateState(){
            this.setState({
                count:this.state.count+1,
                firstName:"shanka",
       });
    }
    render(){
        return(
            <>
            <h1>hiii, {this.state.firstName}</h1>
            <h2>{this.state.count}</h2>
            <button type="button" onClick={()=>this.updateState()}>UpdateName</button>
            </>
        );
    }
}
export default WelcomeClass