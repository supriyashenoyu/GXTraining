import React from 'react'
import { useState } from "react";


  const HandleForm=()=>{
    const [inputVal,displayInput]=useState({
        name:"",
        age:null,
        hobby:""
    });
    let HandleInput=(event)=>{
        let name=event.target.name;
        let value=event.target.value;
        displayInput({
            ...inputVal,
            [name]:value

        })
        console.log(event.target.value)

    }
  return (
    <div>
    <form>
    <label>Name</label><input  className="name"  placeholder="Enter name" name="name" value={inputVal.name} onChange={HandleInput}/> 
    <br></br>
    <label>Age</label><input  className="age"  placeholder="Enter age" name="age" value={inputVal.age} onChange={HandleInput} />
    <br></br>
    <label>Hobby</label><input  className="hobby"  placeholder="Enter hobby" name="hobby" value={inputVal.hobby} onChange={HandleInput}/>
    <br></br>
    </form>
    {inputVal.name}
   <br></br>
        {inputVal.age}
        <br></br>
        {inputVal.hobby}
   </div> ); 
}

export default HandleForm