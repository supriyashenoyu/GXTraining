import React from'react'
import {Component} from 'react'
export class ClassExp extends Component{

render(){
    return(
        <div>Class</div>
    )
}
}