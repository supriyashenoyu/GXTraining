import React from 'react'

export const ULogin = () => {
  return (
    <div>ULogin</div>
  )
}
