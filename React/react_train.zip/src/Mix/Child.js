import react,{useState,useEffect} from 'react'

export const Child=({getItems})=>{
    const[items,setItems]=useState([])
useEffect(()=>{
    setItems(getItems());
    console.log("Inside Child Component")
},[getItems])
return(<div>
    {items.map(item=><div key={item}>{item}</div>)}
</div>)




}