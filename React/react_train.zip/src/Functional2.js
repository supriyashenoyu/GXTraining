import React from 'react'

export const Functional2 = (props) => {
  if(props.name=="Suppi"){
    throw new Error("Name is not correct")
  }
  
    return (
    <div>Functional2{props.name}</div>
  )
}
