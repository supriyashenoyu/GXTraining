import React, { Component } from "react";
import MyOwnContext from "./MyOwnContext";

class ProvideContext extends Component {
  constructor(props) {
    super(props);

    this.state = {
      message: "Hello World!",
    };
  }

  render() {
    return (
      <MyOwnContext.Provider value={{ myValue: this.state.message }}>
        {this.props.children}
      </MyOwnContext.Provider>
    );
  }
}

export default ProvideContext;
