import React from "react";

const MyOwnContext = React.createContext();

export default MyOwnContext;
