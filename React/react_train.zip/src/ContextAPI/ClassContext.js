import React, { Component } from "react";
import MyOwnContext from "./MyOwnContext";

class ClassContext extends React.Component {
  render() {
    return (
      <div>
       
        <div>{this.context.myValue}</div>
        <MyOwnContext.Consumer>{(msg)=>{ return <div>{msg.myvalue}</div>}}</MyOwnContext.Consumer>
      </div>
    );
  }
}
ClassContext.contextType = MyOwnContext;

export default ClassContext;
