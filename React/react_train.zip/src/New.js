import React from 'react'
import { useState } from "react";


  const HandleChange=()=>{
    const [input,setInput]=useState("hi")
  return (
    <div>
    {input}<input onChange={(event)=>setInput(event.target.value)}></input></div>
  );
   
}

export default HandleChange