import React, { Component } from 'react'

export default class AboutUs extends Component {
  render() {
    return (
      <div>AboutUs</div>
    )
  }
}
