import React from 'react'
import {  Link} from "react-router-dom";
import {useState} from 'react'
export const Menu = () => {
    const [link,setLink]=useState(false);
    const handleClick=()=>{
        window.location.href='/aboutus';
    }
    const handleLogin=()=>{
        setLink(true)
    }
  return (
    <div>Menu
    <div>
    <p><Link to="/">Menu</Link></p>
    <p><Link to="/home">Home</Link></p>
    <p><Link to="/signin">SignIn</Link></p>
   
 
    <button onClick={()=>{handleLogin()}}>LOGIN</button>
    <br/>
    <button onClick={()=>handleClick()}>AboutUs</button>
    {link? <p><Link to="/login">Login</Link></p>:null}
    <p><Link to="/class">Class</Link></p>

    </div>
    </div>
  )
}
