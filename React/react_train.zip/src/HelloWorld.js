
export function HelloWorld(){
return(<div>HelloWorld</div>);
}
// export function Welcome(name){
//    return( <div>welcome ${name}</div>);
// }
// export const City='udupi';

// export const GreetPersonWithCityy= (name)=>{
//    return( <p>Hello ${name}</p>)
// }

// export default GreetPersonWithCityy

// export function GreetPersonWithCityy({name}){
//    return(
//    <p>Hello {name}</p>
//    )
// }
// const GreetPersonWithCity = (name,city)=>{
//     return '${name} lives in ${city}';
// }
// console.log(GreetPersonWithCity("Suppi","ud"));

// const humans={
//    name:"Suppi",
//    city:"udupi",
//    greet: function(){
//       console.log(`Hello ${this.name} from ${this.city}`);
//    },
// };
// humans.greet();

// function sum(n1=0,n2=0,...z){
//    console.log(z);
//    return n1+n2;
// }
// console.log(sum(2));
// function sum1(a,b,c){
//    return a+b+c;
// }
// console.log(sum(2,6,5,6,sum1));


// function dispayNames(fn,ln, ...rest){
//    console.log(rest);
//    console.log(fn);
//    console.log(ln);
//    console.log(rest[0]);
// }

 //dispayNames("suppi","shenoy","shanka")
// const vehicles=['v1','v2'];
// const[Car,suv]=vehicles;
// console.log(Car);
// const human={
//    name:"sup",
//    gender:"female",
//    favcolor:"pink"
// }
//  function display({name,gender,favcolor}){
//    console.log(name,gender,favcolor);
//  }
//  display(human);
//  let dispayNamess=['suppi','sheno','shanka']

//  for(let x of dispayNamess){
//    console.log(x)
   
//  }

 let myarray=[1,3,5,7,8,]
// //  let newValue=myarray.find((item)=>item>6)
// //  console.log(newValue)
// function mul(a){
//    return a*a;
// }
//  //const mapArray=myarray.map((x)=>x+10)
// const mapArray=myarray.map(mul);

//   console.log(mapArray)

//  var data=[
//    {id:"1",name:"sup",age:"22",gender:"female"},
//    {id:"2",name:"supp",age:"22",gender:"female"},
//    {id:"3",name:"supppi",age:"22",gender:"female"},
//  ]

//  let arr=data.map((item,index)=>{
//    console.log(item.id);
//    console.log(item.name);
//    console.log(data[index]);
//  })
 //console.log(arr)
//  let cach = data.find(x=>x.name==="sup")
//  console.log(cach);

//  let array=myarray.filter((x)=>x>6)
//  console.log(array)

//  var num=[1,3,5,7,9];
//  let accSum=num.reduce((acc,i)=>acc=acc+i)

//  console.log("sum "+accSum);
