import React from 'react'
import { Component ,useState} from "react";
import {ChildComponent} from './BasicComponenet'
export const ClassPrac = (props) => {
    let age=50;
    const [num,setAge]=useState(0);
    const [arr,setArray]=useState({
      name:"suppi",
        age:5
    })
 const updateVal=()=>{
    setAge(30);
    console.log(arr)
     const updateArray=arr;
     arr.name="ragi"
    setArray(updateArray);    
}
  return (
    <>
    <div>hi {props.name} your age is {age}</div>
    <div>{num}</div>
    <div>{arr.name}</div>
    

    <button onClick={updateVal}>Update</button>
    <ChildComponent object={arr}/>
    </>
  )
}
class Prac extends Component {
    constructor(props){
        super(props);
        this.state={
            firstName:"suppi",
            company:"gx",
        };
    }
    render(){
        return(
            <>
            <h1>hiii, {this.props.name}</h1>
            <p>{this.state.arr}</p>
            <button type="button" onClick={()=>this.updateState()}>UpdateName</button>
           
           </>
        );
    }
}
export default Prac



export const PracP = () => {
  return (
    <div>ClassPrac</div>
  )
}
