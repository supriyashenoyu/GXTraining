import React, { useEffect, useState } from "react";
export function BasicComponent(){
    return <p>Basic compo</p>
}
let item;
const Hooks=()=>{
    
    const [count,setcount]=useState(0);
    const [data,setData]=useState("");
    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/comments')
        .then(response=>response.json()).then(resData=>{
        
            //setData(resDate[0].body)
           item=resData[0].email;
        })
    },[data])
    return(
        <div><p>{count}</p>
        <button onClick={()=>{setcount((x)=>x+1)}}>Increment</button>
        <button onClick={()=>setData(item)}>Email</button> 
        <p>{data}</p>
        </div>
        
    )
}
export default Hooks