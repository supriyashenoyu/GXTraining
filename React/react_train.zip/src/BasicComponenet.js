import React, { useState , Component} from "react";
export function ChildComponent(props){
    return (<div><p>{props.object.name}</p>
    <p>{props.object.age}</p></div>)
}
const UseStateDemo=()=>{
    
    const [count,setcount]=useState(0);
    return(
        <div>{count}
        <button onClick={()=>{setcount((x)=>x+1)}}>Increment</button>
        </div>
        
    )
}

export default UseStateDemo

export class Child2 extends Component{
    constructor(props){
        super(props);
        this.state={
            count:0
        }
        this.handleClick = this.handleClick.bind(this);
    }
    componentWillUnmount(){
        console.log("Unmounted");
        document.addEventListener('mousedown',this.handleClick)

    
    }
    handleClick(){
        console.log("handleClick")
    }
    updateVal(){
        document.addEventListener('mousedown',this.handleClick)


    }
    render(){
        return(
            <div>
                <p>{this.props.count}</p>
                <button onClick={()=>this.updateVal()}>ChildClick</button>
            </div>
        );
    }
}
