import React, { useState, useEffect } from "react";
import axios from "axios";
import { UseRefDemo } from "./UseRefDemo";

export const ServiceIntegration = () => {
  const [userList, setUserList] = useState('');
  const [input,setInput]=useState({
    name:'',
    email:''
  })

  useEffect(() => {
    getUserData();
  }, []);

  const getUserData = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/get-details";

    axios
      .get(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          let uList=resData.data.map((item)=>{
            return (
              <tr>
               <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
              </tr>
            );
            
            
          })
         
          setUserList(uList)
         
         console.log(userList)
         
        }
      })
      .catch((error) => {
        alert("Caught an Unexpected error1");
      });
      
  };

  const addUser = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/save-details";
    const reqBody={
      name:"suuppriya",
      email:"suppz@gmail.com"
    }
    axios
      .post(url, reqBody,{
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          alert("success");
          let uList=resData.data.map((item)=>{
            return (
              <tr>
              <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
              </tr>
            );
            
            
          })
          setUserList(uList)
          
        }
        
      })
      .catch((error) => {
        console.error(error.response.data); 
        alert("Caught an Unexpected error");
      });
      
  };
 





  const updateUser = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/save-details";
    const reqBody={
      name:"suuppriya",
      email:"suppz@gmail.com"
    }
    axios
      .put(url, reqBody,{
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          alert("success");
          let uList=resData.data.map((item)=>{
            return (
              <tr>
              <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
              </tr>
            );
            
            
          })
          setUserList(uList)
          
        }
        
      })
      .catch((error) => {
        console.error(error.response.data); 
        alert("Caught an Unexpected error");
      });
      
  };


  const deleteUser = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/save-details";
    const reqBody={
      name:"suuppriya",
      email:"suppz@gmail.com"
    }
    axios
      .delete(url, reqBody,{
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          alert("success");
          let uList=resData.data.map((item)=>{
            return (
              <tr>
              <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
              </tr>
            );
            
            
          })
          setUserList(uList)
          
        }
        
      })
      .catch((error) => {
        console.error(error.response.data); 
        alert("Caught an Unexpected error");
      });
      
  };


  // const adduser = () => {
  //   //let url='https://jsonplaceholder.typicode.com/users';
  //   let url = "http://localhost:8080/amazon-service/save-details";
  //   const reqBody = {
  //     name: "Suupprriya",
  //     email: "supp@gmail.com",
  //   };
  //   axios
  //     .post(
  //       url,
  //       JSON.stringify(reqBody), {
  //         headers: {
  //           "Content-Type": "application/json",
  //           "Access-Control-Allow-Headers": "Content-Type",
  //           "Access-Control-Allow-Origin": "*",
  //         },
  //       }
  //     )
  //     .then((resData) => {
  //       if (resData.status === 200) {
  //         alert("success");
  //         let uList = resData.data.map((x) => {
  //           return (
  //             <tr>
  //               <td>{x.name}</td>
  //               <td>{x.email}</td>
  //             </tr>
  //           );
  //         });
  //         setUserList(uList);
  //       }
  //     })
  //     .catch((error) => {
  //       alert("Caught an Unexpected error");
  //     });
  // };
  // const handleInput1=(event)=>{
  //   ...input
  //   name:event.target.value;

  // }
  // const handleInput2=(event)=>{
  //   ...input
  //   mail:event.target.value;

  // }
  return (
    <div>
      <table>
        <thead>
          <tr>
          <th>Id</th>
            <th>Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
       {userList}
              </tbody>
      </table>
      {/* <input placeholder="Enter name" onChange={handleInput1()}></input>
      <input placeholder="Enter email" onChange={handleInput2()}></input> */}
      <button type="button" onClick={()=>{addUser();getUserData()}}>
        Add
      </button>
      <button type="button" onClick={()=>{updateUser();getUserData()}}>
        update
      </button>
      <button type="button" onClick={()=>{deleteUser();getUserData()}}>
        Delete
      </button>
   
    </div>
  );
};
