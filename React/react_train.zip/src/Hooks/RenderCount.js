import React from "react";
import { useRef, useState, useEffect } from "react";

export const RenderCount = () => {
  const [val, setVal] = useState();
  const InputRef = useRef("");
  useEffect(() => {
    InputRef.current++;
  });
  return (
    <div>
      <input
        onChange={(event) => {
          setVal(event.target.value);
        }}
      />
      <p>{val}</p>I rendered {InputRef.current} times
    </div>
  );
};

export const StorePrev = () => {
  const [val, setVal] = useState();
  const PrevInput = useRef("");
  useEffect(() => {
    PrevInput.current = val;
  }, [val]);
  return (
    <div>
      <input
        onChange={(e) => {
          setVal(e.target.value);
        }}
      />
      <p>Current value:{val}</p>
      <p>Previous value:{PrevInput.current}</p>
    </div>
  );
};
