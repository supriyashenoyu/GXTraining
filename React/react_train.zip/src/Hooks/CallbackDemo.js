import React from 'react'
import {useState,useMemo,useCallback} from 'react'
import { Child } from '../Child'
const slowFunctionRender=(num)=>{
    for(let index=0;index<1000000;index++){
        console.log("Inside slow function")
        return num*2;
    }
}
    const CallbackDemo=()=>{
        const[number,setNumber]=useState(0);
        const[dark,setDark]=useState(false);
     
        const doubleValue = useMemo(()=>{
            return slowFunctionRender(number)
        },[number])
        const themeStyle=useMemo(()=>{
            return{
                backgroundColor:dark?"black":"white",
                color:dark?"white":"black"
            }
        },[dark])
        const getItems=useCallback(()=>{
            return [number,number+1,number+2]
        },[number])

    
     return(<div>
        <input type='number' value={number}
        onChange={(e)=>{
            setNumber(parseInt(e.target.value))
        }}/>
        <button onClick={()=>{setDark(!dark)}}>Toggle Theme</button>
        {console.log(getItems)}
        <Child getItems={getItems}/>
        <div style={themeStyle}>{doubleValue}</div>
     </div>);

}
export default CallbackDemo