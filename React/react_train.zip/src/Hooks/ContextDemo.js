

import React from 'react'
import {useContext} from 'react'
import MyContext from '../MyContext'
export const ContextDemo = () => {
    const {value,setValue}=useContext(MyContext);
  return (
    <div ><div style={value.theme==="Light"?{backgroundColor:"white"}:{backgroundColor:"black"}}><p>{value.userName}</p><p>{value.theme}</p>
    </div><button onClick={()=>setValue({
        ...value,
        theme:"Dark"
    })}>Dark</button>
    <button onClick={()=>setValue({
        ...value,
        theme:"Light"
    })}>Light</button></div>
   
  )
}
