import React, { useEffect, useState } from "react";
const UseEffectDemo=()=>{
    const [count,setCount]=useState(0)
    const [val,setVAl]=useState("")
    useEffect(()=>{
        setTimeout(()=>{
            setCount(x=>x+1)
        },1000)
    },[val,count])
    return(
        <div>
            {/* <button onClick={()=>{setCount((x)=>x+1)}}>Increment</button> */}
            <input onChange={(e)=>{setVAl(e.target.value)}}>

            </input><p>{count}</p>
        </div>
    )
}
export  default UseEffectDemo