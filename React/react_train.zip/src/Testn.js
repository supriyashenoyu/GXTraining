
// export function Greet(){
//     return(<div>Hello, GoodMorning</div>);
//     }

const studentScores = [
    { name: "Alice", subject: "Math", score: 80 },
    { name: "Bob", subject: "Math", score: 55 },
    { name: "Charlie", subject: "Math", score: 75 },
    { name: "David", subject: "Math", score: 90 },
    { name: "Eva", subject: "Science", score: 70 },
    { name: "Frank", subject: "Science", score: 45 },
    { name: "Grace", subject: "Science", score: 85 },
    { name: "Hank", subject: "Science", score: 95 },
    { name: "Ivy", subject: "English", score: 60 },
    { name: "Jack", subject: "English", score: 50 },
    { name: "Kevin", subject: "English", score: 65 },
    { name: "Linda", subject: "English", score: 75 },
   ];

   const subjectScores = studentScores.reduce((acc, student) => {
    if (!acc[student.subject]) {
    acc[student.subject] = [];
    }
    acc[student.subject].push(student.score);
    return acc;
   }, {});

   const averageScores = {};
   for (const subject in subjectScores) {
    const scores = subjectScores[subject];
    const sum = scores.reduce((total, score) => total + score, 0);
    averageScores[subject] = sum / scores.length;
   }

   let arr = [3, 5, 1]; 
let arr2 = [8, 9, 15]; 
let merged = [0, ...arr, 2, ...arr2]; 
console.log(merged); 
 
let str = "Hello";
console.log( [...str] )

let language = "JavaScript";
for (let x of language) {
console.log(x)
}

const inventory = [
    { name: "apples", quantity: 2 },
    { name: "bananas", quantity: 0 },
    { name: "cherries", quantity: 5 },
    ];
    const result = inventory.find(({ name }) => name === "cherries");
    console.log(result)


    var data = [
        { id: "1", firstName: "Akshay", lastName: "Bhimraya" },
        { id: "2", firstName: "Ponnappa", lastName: "M" },
        { id: "3", firstName: "Yuvaraj", lastName: "Acharya" },
        { id: "4", firstName: "Mayur", lastName: "Pai" },
        ];
        let array = data.map(function (i) {
        return `${i.firstName}`;
        });
        console.log(array.length);
        console.log(array)

        const fruits = ["Banana", "Orange", "Apple"];
// fruits.fill("Kiwi", 2, 4)
// console.log(fruits)

const user = {
    id: 339,
    a: {
      b: 'Masters',
      c: 'sahyadri',
    }
  };
const {a: {b, c}} = user;
console.log(c)

const myNumbers = [4, 1, -20, -7, 5, 9, -6];

// Call removeNeg with a Callback
// const posNumbers = removeNeg(myNumbers);
//  function check(x){
//     if(x>=0){
//         return true;
//     }

// }
// console.log(posNumbers)
// function removeNeg(numbers, callback) {
//     const myArray = [];
//     for (const x of numbers) {
//       if (check(x)) {
//         myArray.push(x);
//       }
//     }
//     return myArray;}



    const posNumbers = removeNeg(myNumbers, (x) => x >= 0);
console.log(posNumbers)

// Display Result


// Remove negative numbers
function removeNeg(numbers, callback) {
  const myArray = [];
  for (const x of numbers) {
    if (callback(x)) {
      myArray.push(x);
    }
  }
  return myArray;
}