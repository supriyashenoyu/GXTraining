 import {Component} from 'react'
 import {Child2} from './BasicComponenet'
 import {  Functional2 } from './Functional2'
 import { ErrorHandling } from './ErrorHandling'
 class Class1 extends Component{
    constructor(){
    super()
    this.state = {
           count:0,
           data:{
            name:"suppi",
            address:"udupi"
           }
        }
        
    }
    updateVal(){
        console.log(this.state.count);
        this.setState({
            count:this.state.count+1
        });
    }
    render(){
        return(
            <div>
            <div>{this.props.name}</div>
            <div>{this.state.count}</div>
                <button onClick={()=>this.updateVal()}>Click</button>
                <Child2 count={this.state.count} updateVal={this.updateVal.bind(this)}/>
                <ErrorHandling><Functional2 name="Suppi"/></ErrorHandling>
                <Functional2 name="supriya"/>
            </div>
        )
    }
}
export default Class1