import React from 'react'

export const FragmentsEx = ({sampleData}) => {
  return (
    <>
      {sampleData.map((x,id)=>{return<React.Fragment key={id}><div><h3>{x.id}</h3>
      <h3>{x.nam}</h3></div></React.Fragment>})}
    </>
    // <React.Fragment>hey</React.Fragment>
  )
}
