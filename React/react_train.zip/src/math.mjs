export function AddNumbers(a,b){
    return a+b;
}