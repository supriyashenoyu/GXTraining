//import logo from './logo.svg';
import "./App.css";
import { HelloWorld } from "./HelloWorld";
import { GreetPersonWithCityy } from "./HelloWorld";
import { Element } from "./element";
import { Greet } from "./Testn";
import Welcome from "./Welcom";
import WelcomeClass from "./WelcomeClass";
import LoginController from "./LoginController";
import UseStateDemo, { BasicComponent } from "./BasicComponenet";
//import WelcomeClass from './WelcomeClass';
import HandleForm from "./Form";
import ReducerDemo from "./Reducer_demo";
import UseEffectDemo from "./UseEffectDemo";
import Hooks from "./EffectReal";
import { ClassPrac } from "./ClassPrac";
import Prac from "./ClassPrac";
import Class1 from './class1'
import { useState } from "react";
import MyContext from "./MyContext";
import {ContextDemo} from "./ContextDemo"
import {UseRefDemo} from './UseRefDemo'
import { RenderCount } from "./RenderCount";
import {StorePrev} from './RenderCount'
import MemoDemo from './MemoDemo'
import CallbackDemo from './CallbackDemo'
import {Style} from  './Style'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Unmounting from'./Unmounting'
import {Functional2} from './Functional2'
import  {Menu} from './Menu'
import { ULogin } from "./ULogin";
import { Usignin } from "./Usignin";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Home } from "./Home";
import { ClassExp } from "./ClassExp";
import AboutUs from "./AboutUs";
import { ServiceIntegration } from "./SIforPost";
import ProvideContext from "./ContextAPI/ProvideContext";
import ClassContext from "./ContextAPI/ClassContext";
import { FragmentsEx } from "./Fragments/FragmentsEx";
const sampleData=[
  {
  id:1,
  nam:"suppi"
},
{
  id:2,
  nam:"suppiy"
},
{
  id:3,
  nam:"suppiii"
},
{
  id:4,
  nam:"suprrrpi"
},
];

function App() {
  // const [value,setValue]=useSate({
  //   userName:"suppiya",
  //   theme:"Light"

  // })
  //console.log(Element);
  //const Eo = <h1>This is {5 + 5} times faster</h1>;
  return (
    <div className="App">
    <ProvideContext>
     <ClassContext/>
    </ProvideContext>
    <ServiceIntegration/> 
    
    {/* <FragmentsEx sampleData={sampleData}/> */}

    </div>
     );

    {/* <BrowserRouter>
      <Routes>
        <Route path='/' element={<Menu/>}/>
        <Route path='/home' element={<Home/>}/>
        <Route path='/signin' element={<Usignin/>}/>
        <Route path='/login' element={<ULogin/>}/>
        <Route path='/class' element={<ClassExp/>}/>
        <Route path='/aboutus' element={<AboutUs/>}/>
      </Routes>
    </BrowserRouter> */}
    {/* <ServiceIntegration/> */}
   

    
   
    {/* <MemoDemo/>
    <CallbackDemo/>
    <Style/>
    <Class1/>
    <Unmounting/>
    <Functional2/>
    <LoginController/>
    <UseRefDemo/>
  
     <MyContext.Provider value={{
      value:value,
      setValue:setValue}}>
      <ContextDemo/>
    </MyContext.Provider> */}
    {/* <UseRefDemo/>
      <Prac name="shanka" />
      <ClassPrac name="suppi" />
     
      <WelcomeClass/>
      <RenderCount/>
      <StorePrev/>
      <UseEffectDemo />
      <Hooks />  */}
   
 
  // return(
  //   {Element}

  //{Element}<WelcomeClass name="suppi"/><LoginController></LoginController>
  // );
}
//   return (
//     <div className="App">

//

//     <h1>Learn React</h1>
//     <Welcome name="suppi" age="22"/>

//     <Greet/>
//     <HelloWorld />
//     </div>
//   );
// }

{
  /* <GreetPersonWithCityy 
      name="soop"/>  */
}

export default App;
