
import "./App.css";


import UseEffectDemo from "./Hooks/UseEffectDemo";

import '../node_modules/bootstrap/dist/css/bootstrap.min.css'

import { ServiceIntegration } from "./SI/SIforPost";
import { Todo } from "./Practice/Todo";
import UserPosts from "./Practice/FetchId";
import LoginController from "./Program/LoginController";

const sampleData=[
  {
  id:1,
  nam:"suppi"
},
{
  id:2,
  nam:"suppiy"
},
{
  id:3,
  nam:"suppiii"
},
{
  id:4,
  nam:"suprrrpi"
},
];

function App() {
  // const [value,setValue]=useSate({
  //   userName:"suppiya",
  //   theme:"Light"

  // })
  //console.log(Element);
  //const Eo = <h1>This is {5 + 5} times faster</h1>;
  return (
    <div className="App">
    {/* <ProvideContext>
     <ClassContext/>
    </ProvideContext> */}
    {/* <UseEffectDemo/> */}
    <UserPosts userId={1} />
   
    <Todo/>
    <LoginController/>
    </div>
     );
    
    
    {/* <FragmentsEx sampleData={sampleData}/> */}

   

    {/* <BrowserRouter>
      <Routes>
        <Route path='/' element={<Menu/>}/>
        <Route path='/home' element={<Home/>}/>
        <Route path='/signin' element={<Usignin/>}/>
        <Route path='/login' element={<ULogin/>}/>
        <Route path='/class' element={<ClassExp/>}/>
        <Route path='/aboutus' element={<AboutUs/>}/>
      </Routes>
    </BrowserRouter> */}
    {/* <ServiceIntegration/> */}
   

    
   
    {/* <MemoDemo/>
    <CallbackDemo/>
    <Style/>
    <Class1/>
    <Unmounting/>
    <Functional2/>
    <LoginController/>
    <UseRefDemo/>
  
     <MyContext.Provider value={{
      value:value,
      setValue:setValue}}>
      <ContextDemo/>
    </MyContext.Provider> */}
    {/* <UseRefDemo/>
      <Prac name="shanka" />
      <ClassPrac name="suppi" />
     
      <WelcomeClass/>
      <RenderCount/>
      <StorePrev/>
      <UseEffectDemo />
      <Hooks />  */}
   
 
  // return(
  //   {Element}

  //{Element}<WelcomeClass name="suppi"/><LoginController></LoginController>
  // );
}
//   return (
//     <div className="App">

//

//     <h1>Learn React</h1>
//     <Welcome name="suppi" age="22"/>

//     <Greet/>
//     <HelloWorld />
//     </div>
//   );
// }

{
  /* <GreetPersonWithCityy 
      name="soop"/>  */
}

export default App;
