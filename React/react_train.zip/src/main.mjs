import {CalculateTotal} from './Shopping.mjs'
import { AddNumbers } from './math.mjs'
import { StudentInfo} from './Student.mjs'
const array=[25,20,40,78]
console.log("Total cost is "+CalculateTotal(array))
console.log("Sum of two numbers "+AddNumbers(5,10))

//Exercise3
let Agrade=StudentInfo.filter((stu)=>stu.grade==="A")
console.log( Agrade)

//Exercise4
const books=[
    {title:"abc",author:"jhkhj",publishedYear:"2001",},
    {title:"bag",author:"lnkjhh",publishedYear:"2013",},
]
function FindBookByTitle(books,title){
  let res=books.find(x=>x.title===title) 
  if(res){
    return res;
  }
  else{
    return 'book not found'
  }
}
console.log(FindBookByTitle(books,"abc"))

//Exercise5
let arr=[1,2,3,4,5]
let double=arr.map((item)=>item*2)
let square=double.map((item)=>item*item)
console.log(arr)
console.log(double)
console.log(square)

//Exercise6
const studentScores = [
    { name: "Alice", subject: "Math", score: 80 },
    { name: "Bob", subject: "Math", score: 55 },
    { name: "Charlie", subject: "Math", score: 75 },
    { name: "David", subject: "Math", score: 90 },
    { name: "Eva", subject: "Science", score: 70 },
    { name: "Frank", subject: "Science", score: 45 },
    { name: "Grace", subject: "Science", score: 85 },
    { name: "Hank", subject: "Science", score: 95 },
    { name: "Ivy", subject: "English", score: 60 },
    { name: "Jack", subject: "English", score: 50 },
    { name: "Kevin", subject: "English", score: 65 },
    { name: "Linda", subject: "English", score: 75 },
   ];

   let lessScore=studentScores.filter((x)=>x.score<60)
   console.log(lessScore)

   function AvgBySub(subject){
   let  GrpBySub=studentScores.filter(x=>x.subject==subject)
   var len=GrpBySub.length
   var total=0
   function sum(a){
    total+=a.score;
   }
   GrpBySub.map(sum)
   console.log("Avg of ",subject,total/len)
}
AvgBySub("Math")
AvgBySub("English")
AvgBySub("Science")
function HighestBySub(subject){
    let  GrpBySub=studentScores.filter(x=>x.subject==subject)
    var high=0
    function highest(a){
        if(a.score>high){
            high=a.score
        }
    }
    GrpBySub.map(highest)
    console.log("Highest Score in ",subject,high)
}
HighestBySub("Math")
HighestBySub("English")
HighestBySub("Science")













   
   let ScienceGrp=studentScores.find(x=>x.subject=="Science")
   let  EnglishGrp=studentScores.find(x=>x.subject=="English")



