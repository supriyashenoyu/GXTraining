import React, { useState,useEffect } from 'react'
import axios from 'axios'
import { UseRefDemo } from '../Hooks/UseRefDemo';


export const ServiceIntegration = () => {
    const [userList,setUserList] = useState('');

    useEffect(()=>{
        getUserData();

    },[])
  
  const getUserData=()=>{
    
    //let url='https://jsonplaceholder.typicode.com/users';
    let url='http://localhost:8080/amazon-service/get-id/1';
    axios.get(url,{
        headers:{
            "Content-Type":"application/json",
            "Access-Control-Allow-Headers":"Content-Type",
            "Access-Control-Allow-Origin":"*"
        }
    })
    .then((resData)=>{
        if(resData.status===200){
            // let uList=response.data.map(x=>{return <div>
            //     {x.name}
            // </div>});
            setUserList(resData.data)
            console.log("userdatas ....",userList);
            console.log("userdata ....",resData.data);
        }
    })
    .catch(error=>{
        alert("Caught an Unexpected error")
    })
  }
    return (
    <div>
        <h3>ServiceIntegration</h3>
       <ul>
        <li>
        {userList.id} 
        </li>
        <li>
        {userList.name} 
        </li>
       </ul> 
       


    </div>
   
  )
}
