import React from 'react'
import {Component} from 'react'
export class ErrorHandling extends Component{
    constructor(props){
        super(props);
        this.state={
            isError:false
        }
    }
 static getDerivedSateFromError(){
    console.log("getDerivedSateFromError");
    return{
        isError:true
 }
 }
 componentDidCatch(error,info){
    console.log(error);
    console.log(info);
    

 }
 render(){
    if(this.state.isError){
        return <div>Something Went Wrong</div>
    }
    return this.props.children
    }
}
