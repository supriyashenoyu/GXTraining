import {Component} from 'react'
import {Child2} from '../../BasicComponenet'
class Class1 extends Component{
   constructor(){
   super()
   this.state = {
          count:0,
          data:{
           name:"suppi",
           address:"udupi"
          }
       }
       console.log("Constructor");
       
   }
   updateVal(){
       console.log(this.state.count);
       this.setState({
           count:this.state.count+1
       });
   }
   static getDerivedStateFromProps(){
    console.log("getDerivedStateFromProps");
    return null;
   }
   componentDidMount(){
    console.log("componenet mounted")

   }
   shouldComponentUpdate(){
    console.log("ShouldComponentUpdate")
   }

   render(){
    console.log("render");
       return(
           <div>
           <div>{this.props.name}</div>
           <div>{this.state.count}</div>
               <button onClick={()=>this.updateVal()}>Click</button>
               <Child2 count={this.state.count} updateVal={this.updateVal.bind(this)}/>
           </div>
       )
    
   }
}
export default Class1