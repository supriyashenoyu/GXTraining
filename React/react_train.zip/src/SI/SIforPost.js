import React, { useState, useEffect } from "react";
import axios from "axios";


export const ServiceIntegration = () => {
  const initialState = {
    name:'',
    email:''
  };
  const [userList, setUserList] = useState('');
  const [clear1, setClear1] = useState();
  const [clear2, setClear2] = useState();
  const [input, setInput]=useState(initialState);

  useEffect(() => {
    getUserData();
    console.log("------Effect");
  }, []);

  const getUserData = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/get-details";

    axios
      .get(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          let uList=resData.data.map((item)=>{
            return (
              <tr>
               <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
              </tr>
            );
            
            
          })
         
          setUserList(uList)
         
         console.log(userList)
         
        }
      })
      .catch((error) => {
        alert("Caught an Unexpected ");
      });
      
  };

  const addUser = () => {
    console.log("vcalled")
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/save-details";
    const reqBody={
      "id": 0,
      "name": input.name,
      "email": input.email,
      "ph": "1223-1213133",
      "dob": "2001-01-01",
      "addressDTO": 
        {
          "id": 0,
          "addr1": "itp2",
          "addr2": "",
          "city": "banglore",
          "state": "karnataka",
          "zip": "574006"
        }
        
        
    }
    axios
      .post(url, reqBody,{
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
      // console.log("---",resData)
        if (resData.status === 200) {
          // alert("success");
          getUserData();
        }
        
      })
      .catch((error) => {
        console.log(error); 
        console.log('====================================');
        console.log("Catch Block");
        console.log('====================================');
        alert("Caught an Unexpected errorsss");
      });
      
  };
 





  const updateUser = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/modify-details";
    const reqBody={
      "id": 0,
      "name": input.name,
      "email": input.email,
      "ph": "1223-1213133",
      "dob": "2001-01-01",
      "addressDTO": 
        {
          "id": 0,
          "addr1": "itp2",
          "addr2": "",
          "city": "banglore",
          "state": "karnataka",
          "zip": "574006"
        }
    }
    axios
      .put(url, reqBody,{
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        console.log(resData)
        if (resData.status === 200) {
         getUserData();
        }
        
      })
      .catch((error) => {
        console.error(error); 
        alert("Caught an Unexpected error");
      });
      
  };


  const deleteUser = () => {
    //let url='https://jsonplaceholder.typicode.com/users';
    let url = "http://localhost:8080/amazon-service/del-cust/3";
    
    axios
      .delete(url, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Origin": "*",
        },
      })
      .then((resData) => {
        if (resData.status === 200) {
          alert("success");
         getUserData();}
      })
      .catch((error) => {
        console.error(error); 
        alert("Caught an Unexpected error");
      });
      
  };

  const handleInput1=(event)=>{
    setInput({...input,
       name:event.target.value})
       console.log('====================================');
       console.log(input);
       console.log('====================================');

    // setClear1(event.target.value)
    // console.log(clear1)
    // setInput({...input,
    // name:clear1})
  }

    const handleInput2=(event)=>{
      setInput({...input,
         email:event.target.value})
      // setClear2(event.target.value)
      // console.log(clear2)
      // setInput({...input,
      // email:clear2})
    }
    const clearInput=()=>{
      // setClear1("")
      // setClear2("")
      setInput(initialState);
    }
  // }
  // const handleInput2=(m)=>{
  //   ...input
  //   mail:event.target.value;

  // }
  return (
    <div>
        <table>
          <thead>
            <tr>
            <th>Id</th>
              <th>Name</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
        {userList}
            </tbody>
        </table>
        <input placeholder="enter name" type="text" value={input.name} onChange={(event)=>{handleInput1(event)}}/>
        <input placeholder="enter email"  type="text" value={input.email} onChange={handleInput2}/>
     
      <button type="button" onClick={()=>{clearInput();addUser();}}>
        Add user
      </button>
      <button type="button" onClick={()=>{updateUser();}}>
        update
      </button>
      <button type="button" onClick={()=>{deleteUser();}}>
        Delete
      </button>
   
    </div>
  );
}
